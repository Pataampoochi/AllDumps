import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;


public class CustomerTest {
	//Write the code for testing assertion using JUNIT
	
	
	@Test
	public void testCustomer(){
	    Customer c = new Customer("2345623457133471","rajendra","sreevatsa","blah",9959946676L,"rajendra@gmail.com");
	    assertTrue(c.isValidAadharNo("234562345622"));
	    //assertFalse(c.isValidAadharNo("0345623456234561"));
	    assertNotEquals(c.getFirstName(),c.getLastName());
	    assertNotNull(c.getEmailId());
	    
	}
}