package com.cts.test;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.Mockito;
import org.junit.After;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertEquals;
import com.cts.utility.Book;
import com.cts.utility.GenerateISBN;

//Provide necessary Annotation to class, attributes and test methods
@RunWith(MockitoJUnitRunner.class)
public class GenerateISBNTest {
	
		@Mock
        Book book;
		@InjectMocks
        GenerateISBN service;
        @Rule
        public ExpectedException exceptionRule = ExpectedException.none();
   
    @Before
	public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSuccess() {
	    assertEquals(book,service.assignISBN("ISBN0123"));
		verify(book,Mockito.times(1)).setIsbn("ISBN0123");


		
	}
	@Test(expected=RuntimeException.class)
	public void testFailed() {
		verify(service.assignISBN("somerandomISBN"),times(0) );
		

		
	}

	@Test(expected=RuntimeException.class)
	public void testException() {

		when(service.assignISBN("someISBN")).thenThrow(new RuntimeException("Invalid pin") );
	}
}
