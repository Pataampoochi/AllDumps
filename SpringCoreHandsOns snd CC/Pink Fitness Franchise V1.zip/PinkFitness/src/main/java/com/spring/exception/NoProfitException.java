package com.spring.exception;

public class NoProfitException extends Exception {

	public NoProfitException(String msg) {
		//fill the code
		super(msg);
	}
}
