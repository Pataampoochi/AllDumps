package com.cts.carstore.model;


public class ErrorResponse {
	
	private String errorMessage;
	private String requestedURI;
	
	//add code here
}
