package com.spring.model;

import java.util.Map;


//pojo class with required attributes,getters and setters 
//use appropriate annotation to make this class as component class
public class FeesDiscountDetails {
	

	//fill the code
	 private  Map<String,Integer> feesDiscount;

	public Map<String, Integer> getFeesDiscount() {
		return feesDiscount;
	}

	public void setFeesDiscount(Map<String, Integer> feesDiscount) {
		this.feesDiscount = feesDiscount;
	}

	
}
