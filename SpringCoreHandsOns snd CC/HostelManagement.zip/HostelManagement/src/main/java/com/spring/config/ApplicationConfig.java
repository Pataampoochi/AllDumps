package com.spring.config;


//Use appropriate annotation 
public class ApplicationConfig {

	
}
