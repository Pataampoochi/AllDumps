package com.spring.service;


import com.spring.bo.StudentBO ;

//use appropriate annotation to make this class as component class
public class StudentService {	

	public StudentBO getStudentBOObj() {
		return studentBOObj;
	}

	public void setStudentBOObj(StudentBO studentBOObj) {
		this.studentBOObj = studentBOObj;
	}

	private StudentBO studentBOObj;

	//fill the code
	public StudentService(StudentBO studentBOObj) {
		super();
		this.studentBOObj = studentBOObj;
	}

	public float calculateFee(String name,String admissionNo,char grade,String hostelName,float rent) {
		//fill the code
		return 0;
	}

}
