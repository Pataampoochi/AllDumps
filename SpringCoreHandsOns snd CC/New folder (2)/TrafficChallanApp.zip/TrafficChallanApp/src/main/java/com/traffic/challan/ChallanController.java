package com.traffic.challan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ChallanController {
	@Autowired
	ChallanService challanService;

	@RequestMapping(value = "/vehicleNumberForm", method = RequestMethod.GET)
	public String vehicleNumberForm(@ModelAttribute("vehicle") Vehicle vehicle) {
		return "vehicleNumberForm";
	}

	@RequestMapping(value = "/showChallanAmount", method = RequestMethod.POST)
	public String showChallanAmount(@RequestParam int vehicleNumber, Model model) {

		Vehicle obj = challanService.findVehicle(vehicleNumber);
		model.addAttribute("vehicle", obj);

		return "showChallanAmount";
	}

	@RequestMapping(value = "/payChallanAmount", method = RequestMethod.POST)
	public String payChallan(@ModelAttribute("vehicle") Vehicle vehicle) {
		return "payChallanAmount";
	}

}
