package com.traffic.challan;

import org.springframework.stereotype.Component;

@Component
public class Vehicle {

	private int vehicleNumber;
	private String vehicleName;
	private int challanAmount;

	public int getVehicleNumber() {
		return vehicleNumber;
	}

	public void setVehicleNumber(int vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public int getChallanAmount() {
		return challanAmount;
	}

	public void setChallanAmount(int challanAmount) {
		this.challanAmount = challanAmount;
	}
}
