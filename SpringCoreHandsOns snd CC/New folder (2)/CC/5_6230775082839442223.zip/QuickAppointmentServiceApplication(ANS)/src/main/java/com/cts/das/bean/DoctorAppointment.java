package com.cts.das.bean;



import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class DoctorAppointment {
	
	private static int  appointmentId=1000;
	
//Use validation annotations as per the requirement
// add constructor and increment appointmentId by 1
	@NotNull(message="Patient name is required")
	private String  patientName;
	@NotNull(message="Phone number is required")
	@Pattern(regexp="^//d{10}$",message="Phone number should be 10 digits.")
	private String phoneNumber;
	private LocalDateTime dateOfAappointment;
	@NotNull(message="Email is required")
	private String email;
	@NotNull(message="Age is required")
	private Integer age;
	@NotNull(message="Gender is required")
	private String gender;
	private String problemName;
	private String doctorName;
	private String appointmentStatus;
	
	public DoctorAppointment()
	{
		appointmentId++;
	}
	
	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public LocalDateTime getDateOfAappointment() {
		return dateOfAappointment;
	}
	public void setDateOfAappointment(LocalDateTime dateOfAappointment) {
		this.dateOfAappointment = dateOfAappointment;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getAppointmentStatus() {
		return appointmentStatus;
	}
	public void setAppointmentStatus(String appointmentStatus) {
		this.appointmentStatus = appointmentStatus;
	}
	@Override
	public String toString() {
		return "DoctorAppointment [appointmentId=" + appointmentId + ", patientName=" + patientName + ", phoneNumber="
				+ phoneNumber + ", dateOfAappointment=" + dateOfAappointment + ", email=" + email + ", age=" + age
				+ ", gender=" + gender + ", problemName=" + problemName + ", doctorName=" + doctorName
				+ ", appointmentStatus=" + appointmentStatus + "]";
	}

	
}
