package com.cts.das.controller;



import java.time.LocalDate;
import java.time.LocalDateTime;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.das.bean.DoctorAppointment;
import com.cts.das.service.DoctorAppointmentDaoService;

@Controller
public class DoctorAppointmentController {
	

	@Autowired
	private DoctorAppointmentDaoService doctorAppointmentDaoService;
	@Autowired
	private Validator validator;
	
	// add the mapping as per the requirement
	//@RequestMapping(value="/showAppointmentForm",method=RequestMethod.GET)
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String showAppointmentForm(@ModelAttribute("doctorAppointment") DoctorAppointment doctorAppointment) {
		return "doctorAppointment";
	}
	
	@RequestMapping(value="/getAppointment",method=RequestMethod.POST)
	public String getAppoinmentStatus(@ModelAttribute("doctorAppointment") DoctorAppointment doctorAppointment,ModelMap map,BindingResult result) {
		if(result.hasErrors())
		{
			return "doctorAppointment";
		}
		int appointmentId=0;
		if(doctorAppointmentDaoService.doctorList.keySet().contains(doctorAppointment.getProblemName()))
		{
			String doctorName =  doctorAppointmentDaoService.doctorList.get(doctorAppointment.getProblemName());
			doctorAppointment.setDoctorName(doctorName);
			doctorAppointment.setDateOfAappointment(LocalDateTime.now().plusDays(1));
			doctorAppointment.setAppointmentStatus("APPROVED");
			appointmentId=doctorAppointmentDaoService.addDoctorAppointmentDetails(doctorAppointment);
		}
		if(appointmentId>0)
		{
			map.addAttribute("doctorAppointment",doctorAppointment);
			return "appointmentStatus";
		}
		else
		{
				doctorAppointment.setAppointmentStatus("DISAPPROVED");
				map.addAttribute("message","Appointment not approved try again");
				return "doctorAppointment";
		}
	}	
	
	@ModelAttribute("problemList")
	public Set<String> populateProblemList(){
		
		return doctorAppointmentDaoService.doctorList.keySet();
	}
}












