package com.cts.das.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.cts.das.bean.DoctorAppointment;
@Service
public class DoctorAppointmentDaoServiceImpl implements DoctorAppointmentDaoService{

public static Map<Integer,DoctorAppointment> appointmentList=new HashMap<>();


public DoctorAppointmentDaoServiceImpl() {
	doctorList.put("Heart", "Dr. Brijesh Kumar");
	doctorList.put("Gynecology", "Dr. Sharda Singh");
	doctorList.put("Diabetes", "Dr. Uma Chandrashekar");
	doctorList.put("ENT", "Dr. Preethi raj");
	doctorList.put("Dermatology", "Dr. Renuka Kher");
	doctorList.put("Bone", "Dr. Kanika Kapoor");


}
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		
// add the code as per the requirement
		int id = doctorAppointment.getAppointmentId();
		appointmentList.put(id,doctorAppointment);
		return id;
	}



}
