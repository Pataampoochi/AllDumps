package com.cts.das;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.*")
public class QuickAppointmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickAppointmentServiceApplication.class, args);
	}
}
