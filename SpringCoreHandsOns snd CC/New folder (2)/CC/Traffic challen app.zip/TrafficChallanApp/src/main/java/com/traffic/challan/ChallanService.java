package com.traffic.challan;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

@Service
public class ChallanService {

	private ArrayList<Vehicle> vehicleList = new ArrayList<>();

	public ChallanService() {
		Vehicle vObj = new Vehicle();
		vObj.setVehicleName("Honda");
		vObj.setVehicleNumber(1111);
		vObj.setChallanAmount(100);
		
		vehicleList.add(vObj);
	}

	public Vehicle findVehicle(int vehicleNumber) {

		Vehicle obj = new Vehicle();

		for (Vehicle v : vehicleList) {
			if (v.getVehicleNumber() == vehicleNumber) {
				obj = v;
				break;
			}
		}

		return obj;
	}
}
