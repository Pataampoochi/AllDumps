/***********************************************************************************************************
 * This class LoanEligibilityController is control the views and model objects 
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * CHANGE THE RETURN TYPE FROM NULL OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 * ADD REQUEST MAPPING URI AND RETURN TYPE AS PER DESIGN DOCUMENT
 *
************************************************************************************************************/
package com.cts.loanbazaar.loaneligibility.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.loanbazaar.loaneligibility.exception.ApplicationException;
import com.cts.loanbazaar.loaneligibility.model.CustomerDetails;
import com.cts.loanbazaar.loaneligibility.model.LoanProduct;
import com.cts.loanbazaar.loaneligibility.service.LoanEligibilityService;

/**
 * Loan Eligibility Controller
 *
 */
@Controller
public class LoanEligibilityController {

	
	public List<String> cities;
	
	
	public List<String> employmentTypes;
	
	public List<String> genders;

	/**
	 * @param model
	 * @return String
	 */ 
	
	
	
	@Autowired
	LoanEligibilityService loanEligibilityService;
	
	@GetMapping({"/", "/home"})
	public String showHomePage(Model model) {
		model.addAttribute("customerDetails", new CustomerDetails());
		return "loanEligibility";
	}

	/**
	 * @param model
	 * @param request
	 * @param response
	 * @param customerDetails
	 * @param result
	 * @return String
	 * @throws ApplicationException
	 */
	@PostMapping("/eligibilityCheck")
	public String getLoanProducts(
			Model model,
			HttpServletRequest request,
			HttpServletResponse response,
			@Valid @ModelAttribute("customerDetails") CustomerDetails customerDetails,
			BindingResult result) throws ApplicationException {
		String page;
		if(result.hasErrors())
		{
			page =  "loanEligibility"; 
		}
		
		else 
		{
			List<LoanProduct> eligibleLoanProducts;
			eligibleLoanProducts = loanEligibilityService.checkEligibleLoanProducts(customerDetails);
			model.addAttribute("loanProducts", eligibleLoanProducts);
			page = "results";
		}
		return page;
	}

	/**
	 * @return List<String>
	 */
	@ModelAttribute("cities")
	public List<String> getCities() {
		cities = new ArrayList<>();
		cities.add("");
		cities.add("Chennai");
		cities.add("Mumbai");
		cities.add("Bangalore");
		cities.add("Delhi");
		cities.add("Kolkatta");
		cities.add("Pune");
		return cities;
	}

	/**
	 * @return List<String>
	 */
	@ModelAttribute("employmentTypes")
	public List<String> getEmploymentTypes() {
		employmentTypes = new ArrayList<>();
		employmentTypes.add("");
		employmentTypes.add("Salaried");
		employmentTypes.add("Self-Employed");
		employmentTypes.add("Contractual Employment");
		employmentTypes.add("Student");
		employmentTypes.add("Pensioner");
		return employmentTypes;
	}

	/**
	 * @return List<String>
	 */
	@ModelAttribute("genders")
	public List<String> getGenderOptions() {
		genders = new ArrayList<>();
		genders.add("Male");
		genders.add("Female");
		return genders;
	}

}
