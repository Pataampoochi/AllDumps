/***********************************************************************************************************
 * This class ExceptionHandlerControllerAdvice is used to handle different exceptions raised by Controller
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * CHANGE THE RETURN TYPE FROM NULL OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE 
 *
************************************************************************************************************/
package com.cts.loanbazaar.loaneligibility.exception;

import java.time.LocalDateTime;


import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cts.loanbazaar.loaneligibility.model.ErrorResponse;

@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	@ExceptionHandler(ApplicationException.class)
	public ModelAndView handleResourceNotFound(final ApplicationException exception,
			final HttpServletRequest request, final Model model) {
		 //TODO add your code here
		ErrorResponse errorResponse = new ErrorResponse(); 
		errorResponse.setErrorMessage("Customer Not Eligible For the Loan");
		model.addAttribute("errorResponse", errorResponse);
		model.addAttribute("responseCode", 500);
		model.addAttribute("time", LocalDateTime.now());
		return new ModelAndView("/error");  //TODO change the return type here
	}
}
