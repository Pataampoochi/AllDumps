package com.cts.carstore.exception;


public class ApplicationException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;
	
	public String errorMessage;
	public ApplicationException() {
		super();
	}

}
