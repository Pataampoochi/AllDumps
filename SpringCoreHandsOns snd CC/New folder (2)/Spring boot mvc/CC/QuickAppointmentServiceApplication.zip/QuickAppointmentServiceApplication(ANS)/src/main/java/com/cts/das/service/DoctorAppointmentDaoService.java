package com.cts.das.service;

import java.util.HashMap;
import java.util.Map;

import com.cts.das.bean.DoctorAppointment;


public interface DoctorAppointmentDaoService {
	public  Map<String,String> doctorList=new HashMap<>();
	
	
	int addDoctorAppointmentDetails (DoctorAppointment doctorAppointment); 
}
