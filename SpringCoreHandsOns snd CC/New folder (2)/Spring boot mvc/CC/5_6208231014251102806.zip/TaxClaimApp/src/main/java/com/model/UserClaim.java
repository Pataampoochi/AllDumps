package com.model;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;
import com.controller.IdPattern;
@SuppressWarnings("unused")
public class UserClaim 
{
	@NotBlank(message = "{employeeId.notEmpty}")
//	@Pattern(regexp = "^[\\w]{5,}$", message = "{employeeId.Length}")
	@IdPattern(message = "{employeeId.Length}")
	private String employeeId;
	private String expenseType;
	@PositiveOrZero(message = "{expenseAmount.Negative}")
	private double expenseAmt;
	public String getExpenseType() 
	{
		return expenseType;
	}
	public void setExpenseType(String expenseType) 
	{
		this.expenseType = expenseType;
	}
	public double getExpenseAmt() 
	{
		return expenseAmt;
	}
	public void setExpenseAmt(double expenseAmt) 
	{
		this.expenseAmt = expenseAmt;
	}
	public String getEmployeeId() 
	{
		return employeeId;
	}
	public void setEmployeeId(String employeeId) 
	{
		this.employeeId = employeeId;
	}
}