package com.service;
import org.springframework.stereotype.Service;
import com.model.UserClaim;
@Service
public class TaxServiceImpl implements TaxService 
{
	public double calculateTax(UserClaim userClaim) 
	{
		double taxAmount = 0.0;
		double expenseAmnt = userClaim.getExpenseAmt();
		String expenseType = userClaim.getExpenseType();
		if (expenseType.equals("Medical Expense")) 
		{
			if (expenseAmnt <= 1000) 
			{
				taxAmount = expenseAmnt * 0.15;
			} 
			else if (expenseAmnt > 1000 && expenseAmnt <= 10000) 
			{
				taxAmount = expenseAmnt * 0.20;
			} 
			else if (expenseAmnt > 10000) 
			{
				taxAmount = expenseAmnt * 0.25;
			}
		}
		if (expenseType.equals("Travel Expense")) 
		{
			if (expenseAmnt <= 1000) 
			{
				taxAmount = expenseAmnt * 0.10;
			} 
			else if (expenseAmnt > 1000 && expenseAmnt <= 10000) 
			{
				taxAmount = expenseAmnt * 0.15;
			} 
			else if (expenseAmnt > 10000) 
			{
				taxAmount = expenseAmnt * 0.20;
			}
		}
		if (expenseType.equals("Food Expense")) 
		{
			if (expenseAmnt <= 1000) 
			{
				taxAmount = expenseAmnt * 0.05;
			} 
			else if (expenseAmnt > 1000 && expenseAmnt <= 10000) 
			{
				taxAmount = expenseAmnt * 0.10;
			} 
			else if (expenseAmnt > 10000) 
			{
				taxAmount = expenseAmnt * 0.15;
			}
		}
		return taxAmount;
	}
}