package com.service;
import com.model.UserClaim;
public interface TaxService 
{	
	public double calculateTax(UserClaim userClaim);
}