package com.controller;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.model.UserClaim;
import com.service.TaxService;
@Controller
public class TaxController 
{
	@Autowired
	private TaxService taxService;
	@GetMapping("/getTaxClaimFormPage")
	public String claimPage(@ModelAttribute("userClaim") UserClaim userClaim) 
	{
		return "taxclaim";
	}
	@PostMapping("/calculateCost")
	public String calculateTax(@Valid @ModelAttribute("userClaim") UserClaim userClaim, BindingResult result,
			ModelMap model) 
	{
		if (result.hasErrors()) 
		{
			return "taxclaim";
		}
		double taxAmount = taxService.calculateTax(userClaim);
		model.addAttribute("expenseType", userClaim.getExpenseType());
		model.addAttribute("expenseAmt", userClaim.getExpenseAmt());
		model.addAttribute("totalTaxAmount", taxAmount);
		return "result";
	}
	@ModelAttribute("expenseList")
	public List<String> populateExpense() 
	{
		List<String> expenseTypeList = new ArrayList<String>();
		expenseTypeList.add("Medical Expense");
		expenseTypeList.add("Travel Expense");
		expenseTypeList.add("Food Expense");
		return expenseTypeList;
	}
}