package com.controller;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
public class IdConstraintValidator implements ConstraintValidator<IdPattern, String> 
{
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) 
	{
		// TODO Auto-generated method stub
		return value.length() == 0 || value.length() >= 5;
	}
}