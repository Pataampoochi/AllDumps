package com.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.ParcelBean;
import com.service.ParcelService;

//use appropriate annotation to configure BillController as Controller
@Controller
public class BillController {
	
	@Autowired
	private ParcelService parcelService;
	
	@ModelAttribute("serviceList")
	public Map<String,String> buildState(){
		Map<String,String> pairs = new HashMap<>();
		pairs.put("SpeedPost","SpeedPost");
		pairs.put("RegisteredPost","RegisteredPost");
		pairs.put("ParcelService","ParcelService");
		return pairs;
	}
	
	@RequestMapping(value="/showPage", method=RequestMethod.GET)
	public String showPage(@ModelAttribute("parcel") ParcelBean parcelBean) {
		return "showpage";
	
	}
	//invoke the service class - calculateTotalCost method.	
	@RequestMapping(value="/billDesk",method=RequestMethod.POST)
	public String calculateTotalCost(@ModelAttribute("parcel") ParcelBean parcelBean, 
			ModelMap model) {
		double totalCost = parcelService.calculateTotalCost(parcelBean);
		model.put("cost", totalCost);
		
		return "billdesk";
	}
	
	
}
	 	  	    	    	     	      	 	
