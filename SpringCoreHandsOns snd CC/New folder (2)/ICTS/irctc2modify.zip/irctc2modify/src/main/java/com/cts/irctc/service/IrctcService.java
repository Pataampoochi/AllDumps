package com.cts.irctc.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.irctc.exception.ApplicationException;
import com.cts.irctc.model.TicketBooking;
import com.cts.irctc.model.Traininfo;

@Service
public class IrctcService  {
	@Autowired
	TrainRepo trainRepo;
	 public List<Traininfo> findBytrain(String trainfrom , String trainto) {
		 List<Traininfo> train = trainRepo.findAll();
		 List<Traininfo> train1 = new ArrayList<Traininfo>();
		 for (Traininfo traininfo : train) {
			 if(traininfo.getTrainfrom().equalsIgnoreCase(trainfrom) && traininfo.getTrainto().equalsIgnoreCase(trainto)) {
				 train1.add(traininfo);
			 }
			
		}
		return train1;
		
	}
	
}
