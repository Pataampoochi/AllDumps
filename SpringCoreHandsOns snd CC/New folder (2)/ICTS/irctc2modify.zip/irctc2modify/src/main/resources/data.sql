insert into TrainInfo values (101,'Chennai','Delhi');
insert into TrainInfo values (102,'Chennai','Pune');
insert into TrainInfo values (103,'Bangalore','Delhi');
insert into TrainInfo values (104,'Chennai','Bangalore');
insert into TrainInfo values (105,'Delhi','Bangalore');