package project;

public class Employee {
	String employeeId;
	String employeeName;
	String emailId;
	String designation;
	
	public String getEmployeeId() {
		return employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public String getEmailId() {
		return emailId;
	}
	public String getDesignation() {
		return designation;
	}
	public Employee(String employeeId, String employeeName, String emailId, String designation) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.emailId = emailId;
		this.designation = designation;
	}
	

}
