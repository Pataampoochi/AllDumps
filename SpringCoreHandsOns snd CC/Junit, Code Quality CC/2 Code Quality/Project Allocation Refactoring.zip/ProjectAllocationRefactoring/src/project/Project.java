package project;

public class Project{
	 String projectId;
	 String projectName;
	 String projectManagerName;
	 int duration;
	 String startDate;
	 String endDate;
	
	/*public  Project(){
		
	}*/
	public Project(String projectId, String projectName, String projectManagerName, int duration, String startDate,String endDate) {
		super();
		
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectManagerName = projectManagerName;
		this.duration = duration;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public String getProjectId() {
		return projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public String getProjectManagerName() {
		return projectManagerName;
	}
	public int getDuration() {
		return duration;
	}
	public String getStartDate() {
		return startDate;
	}
	public String getEndDate$() {
		return endDate;
	}
	public String toString(){
		
		return projectId+" "+projectName;
	}
}
	


