package project;
import java.util.ArrayList;



public class ProjectDAO {
ArrayList<Project> projectList =  new ArrayList<Project>();
	
	public void addProject(Project obj){
		projectList.add(obj);
	}
	
	public void removeProject(Project obj)
	{
		projectList.remove(obj);
	}
	
	public void viewMember()
	{
		for(int i=0;i<projectList.size();i++)
		{
			System.out.println("Project Id:" + projectList.get(i).getProjectId());
			System.out.println("Project Name:" + projectList.get(i).getProjectName());
			System.out.println("Project Manager Name:" + projectList.get(i).getProjectManagerName());
			System.out.println("Duration:"+ projectList.get(i).getDuration());
			System.out.println("Start Date:" + projectList.get(i).getStartDate());
			System.out.println("End Date:" + projectList.get(i).getEndDate$());
			
			
		}
	}

}
