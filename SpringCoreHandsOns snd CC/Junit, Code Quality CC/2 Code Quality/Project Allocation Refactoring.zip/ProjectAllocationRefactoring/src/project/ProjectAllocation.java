package project;
import java.util.Date;


public class ProjectAllocation {
	 Employee employee;
	 Project project;
	 int projectAllocationId;
	 String moduleName;
	public static final int NO_OF_PROJECTS_WORKING_IN_PARALLEL=0;	
	 Date allocationDate;
	public static final int NOOFHOURSALLOCATED=160;
	
	
	
	public ProjectAllocation(Employee employee,Project project, int projectAllocationId, String moduleName, Date allocationDate){
		super();
		this.employee = employee;
		this.project = project;
		this.projectAllocationId = projectAllocationId;
		this.moduleName = moduleName;
		this.allocationDate = allocationDate;
	}
	
	public Employee getEmployee() {
		return employee;
	}
	
	public Project getProject() {
		return project;
	}
	
	public int getProjectAllocationId() {
		return projectAllocationId;
	}
	
	public String getModuleName() {
		return moduleName;
	}
	public static int getNoOfProjectsWorkingInParallel() {
		return NO_OF_PROJECTS_WORKING_IN_PARALLEL;
	}
	public Date getAllocationDate() {
		return allocationDate;
	}

}
