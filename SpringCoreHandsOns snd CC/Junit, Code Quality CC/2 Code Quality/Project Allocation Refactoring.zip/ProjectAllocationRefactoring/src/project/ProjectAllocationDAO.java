package project;

import java.util.ArrayList;


public class ProjectAllocationDAO {
	ArrayList<ProjectAllocation> projectAllocationList =  new ArrayList<ProjectAllocation>();

	public void addProjectAllocation(ProjectAllocation obj){
		projectAllocationList.add(obj);
		
	}
	
	/*public void removeProjectAllocation(ProjectAllocation obj)
	{
		
	}*/
	
	public void viewProjectAllocation(){
		
		if(projectAllocationList.isEmpty()){
			System.out.println("Project Allocation List is empty");
		}
		
		for (int i = 0; i < projectAllocationList.size(); i++) {
			System.out.println("Project Allocation Id:" + projectAllocationList.get(i).getProjectAllocationId());
			System.out.println("Project Id:"+projectAllocationList.get(i).getProject().getProjectId());
			System.out.println("Employee Id:"+projectAllocationList.get(i).getEmployee().getEmployeeId());
			System.out.println("Allocation Date:" + projectAllocationList.get(i).getAllocationDate());
			System.out.println("Module Name:"+projectAllocationList.get(i).getModuleName());
		}
		
	}
	


}
