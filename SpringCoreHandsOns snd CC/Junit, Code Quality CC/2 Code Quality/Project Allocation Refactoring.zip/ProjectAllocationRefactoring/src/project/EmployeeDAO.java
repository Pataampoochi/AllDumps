package project;
import java.util.ArrayList;



public class EmployeeDAO {

	ArrayList<Employee> l =  new ArrayList<Employee>();
	
	public void addEmployee(Employee obj){
		l.add(obj);
	}
	
	public void removeEmployee(Employee obj)
	{
		l.remove(obj);
	}
	
	
	public void viewEmployee()
	{
		for(int i=0;i<l.size();i++)
		{
			System.out.println("Employee Id:" + l.get(i).getEmployeeId());
			System.out.println("Employee Name:" + l.get(i).getEmployeeName());
			System.out.println("Email Id:" + l.get(i).getEmailId());
			System.out.println("Designation: "+ l.get(i).getDesignation());
			
		}
	}
}
