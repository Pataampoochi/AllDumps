package com.exception;

public class InvalidCourseException extends Exception {
	
	public InvalidCourseException(String msg){
		super(msg);
	}

}
