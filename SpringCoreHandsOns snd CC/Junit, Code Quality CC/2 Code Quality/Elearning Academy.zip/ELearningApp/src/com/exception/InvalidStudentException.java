package com.exception;

public class InvalidStudentException extends Exception {
	
	public InvalidStudentException(String msg){
		super(msg);
	}

}
