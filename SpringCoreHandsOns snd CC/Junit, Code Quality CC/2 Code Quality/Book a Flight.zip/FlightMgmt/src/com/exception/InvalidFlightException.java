package com.exception;

public class InvalidFlightException extends Exception {
	
	public InvalidFlightException(String msg){
		super(msg);
	}

}
