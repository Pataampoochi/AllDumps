package com.exception;

public class InvalidCustomerException extends Exception {
	
	public InvalidCustomerException(String msg){
		super(msg);
	}

}
