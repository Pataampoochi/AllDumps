package com.model;

public class Customer {
	
	private String customerId;
	private String customerName;
	private String emailId;
	private String userName;
	private String password="FH782";
	
	public Customer(String customerName, String emailId, String userName) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.userName = userName;		
	}
	
	public String getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getEmailId() {
		return emailId;
	}
	
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	
		
}
