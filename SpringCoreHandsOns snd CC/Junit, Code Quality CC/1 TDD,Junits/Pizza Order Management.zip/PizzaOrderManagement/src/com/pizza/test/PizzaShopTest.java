package com.pizza.test; 
 
import java.util.ArrayList; 
import java.util.List; 
 
 
import org.junit.BeforeClass; 
import org.junit.FixMethodOrder; 
import org.junit.runners.MethodSorters; 
import org.junit.Test; 
import org.junit.Assert; 
import static org.junit.Assert.assertTrue; 
 
import com.pizza.model.PizzaOrder; 
import com.pizza.util.PizzaShop; 
import com.pizza.exception.InvalidPizzaOrderException; 
 
@FixMethodOrder(MethodSorters.NAME_ASCENDING) 
public class PizzaShopTest { 
     
 private static PizzaShop psObj; 
    private static List<PizzaOrder> list = new ArrayList<PizzaOrder>(); 
 
 
 @BeforeClass 
 public static void setUp() throws Exception { 
   
  psObj = new PizzaShop(); 
   
  PizzaOrder order1 = new PizzaOrder(001,"Pepporoni","Amrutha","Cheese Burst","Small",1); 
  PizzaOrder order2 = new PizzaOrder(002,"Pepporoni","Ashish","Fresh Pan","Medium",1); 
  PizzaOrder order3= new PizzaOrder(003,"5 Peppers","Anil","Thin Crust","Large",2); 
   
  list.add(order1); 
  list.add(order2); 
  list.add(order3); 
   
  psObj.setPizzaOrderList(list); 
  //Create few  objects for PizzaOrder class and add to a list. 
  //Set that list to the pizzaOrderList using the setPizzaOrderList method in PizzaShop class   
 
 } 
 
 //Test the validateSize method when size is small 
 @Test 
 public void test11ValidateSizeWhenSmall() throws InvalidPizzaOrderException{ 
      
     assertTrue(psObj.validateSize("Small")); 
   
 } 
  
 
 //Test the validateSize method when size is medium 
 @Test 
 public void test12ValidateSizeWhenMedium()throws InvalidPizzaOrderException{ 
  assertTrue(psObj.validateSize("Medium")); 
 } 
  
 //Test the validateSize method when size is large 
 @Test 
 public void test13ValidateSizeWhenLarge() throws InvalidPizzaOrderException{ 
      
     assertTrue(psObj.validateSize("Large")); 
  
 } 
  
 //Test the validateSize method when size is invalid 
 @Test(expected = InvalidPizzaOrderException.class) 
 public void test14ValidateSizeWhenInvalid() throws InvalidPizzaOrderException{ 
   
  assertTrue(psObj.validateSize("regular")); 
   
 } 
  
 //Test viewPizzaOrderById method for an existing order id. 
 @Test 
 public void test15ViewPizzaOrderByIdWhenValid() throws InvalidPizzaOrderException{ 
      
     assertTrue(psObj.viewPizzaOrderById(001).getClass() == PizzaOrder.class); 
  
 } 
  
 //Test  viewPizzaOrderById method for a non existing order id. 
 @Test(expected = InvalidPizzaOrderException.class) 
 public void test16ViewPizzaOrderByIdWhenInvalid() throws InvalidPizzaOrderException{ 
      
     psObj.viewPizzaOrderById(100); 
   
 } 
  
 //Test the correctness of viewPizzaOrdersByType method 
 @Test 
 public void test17ViewPizzaOrdersByType() throws InvalidPizzaOrderException{ 
   
 assertTrue(psObj.viewPizzaOrdersByType("Cheese Burst").get(0).getPizzaType() == "Cheese Burst"); 
   
   
 } 
  
 //Test the correctness of  viewPizzaOrdersTypeWise  method 
 @Test 
 public void test18ViewPizzaOrdersTypeWise() throws InvalidPizzaOrderException{ 
      
     asssertFalse(psObj.viewPizzaOrdersTypeWise().isEmpty()); 
 
 } 
  
 private void asssertFalse(boolean empty) 
 { 
      
 } 
  
 //Test the correctness of countTotalQuantityForEachSize method 
 @Test 
 public void test19CountTotalQuantityForEachSize() throws InvalidPizzaOrderException{ 
      
     asssertFalse(psObj.countTotalQuantityForEachSize().isEmpty()); 
  
 } 
  
 //Test the correctness of viewPizzaOrdersByType method when the list is empty  
 @Test(expected = InvalidPizzaOrderException.class) 
 public void test20ViewPizzaOrdersByTypeForEmptyList() throws InvalidPizzaOrderException{ 
      
     List<PizzaOrder> list1 = new ArrayList<PizzaOrder>(); 
     psObj.setPizzaOrderList(list1); 
     psObj.viewPizzaOrdersByType("Thin Crust"); 
   
 } 
 
 //Test the correctness of viewPizzaOrdersTypeWise method when the list is empty  
 @Test(expected = InvalidPizzaOrderException.class) 
 public void test21ViewPizzaOrdersTypeWiseForEmptyList() throws InvalidPizzaOrderException{ 
      
     List<PizzaOrder> list1 = new ArrayList<PizzaOrder>();

psObj.setPizzaOrderList(list1); 
  psObj.viewPizzaOrdersTypeWise(); 
 } 
  
 //Test the correctness of countTotalQuantityForEachSize method when the list is empty 
 @Test(expected = InvalidPizzaOrderException.class) 
 public void test22CountTotalQuantityForEachSizeForEmptyList() throws InvalidPizzaOrderException{ 
      
     List<PizzaOrder> list1 = new ArrayList<PizzaOrder>(); 
     psObj.setPizzaOrderList(list1); 
  psObj.countTotalQuantityForEachSize(); 
 } 
}