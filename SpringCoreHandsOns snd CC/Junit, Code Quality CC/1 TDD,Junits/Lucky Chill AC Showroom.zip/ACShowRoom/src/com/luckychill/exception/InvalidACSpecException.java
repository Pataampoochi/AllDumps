package com.luckychill.exception;

public class InvalidACSpecException extends Exception{
	
	public InvalidACSpecException(String msg) {
		super(msg);
	}

}
