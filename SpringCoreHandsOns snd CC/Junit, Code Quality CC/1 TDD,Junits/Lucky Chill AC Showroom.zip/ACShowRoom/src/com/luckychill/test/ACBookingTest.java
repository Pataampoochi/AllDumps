package com.luckychill.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;




import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runners.MethodSorters;

import com.luckychill.exception.InvalidACSpecException;
import com.luckychill.model.ACSpecifications;
import com.luckychill.util.ACBooking;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ACBookingTest {

	private static List<ACSpecifications> acList = new ArrayList<ACSpecifications>();


  @Rule
   public ExpectedException exceptionRule=ExpectedException.none();
   private static List<ACSpecifications>acspecificationList=new ArrayList<ACSpecifications>();
   private static ACBooking bookingObj;
   private static ACSpecifications acs4;
   private static ACSpecifications acs2;
   private static ACSpecifications acs3;
   
   
	
	@BeforeClass
	public static void setUp() throws Exception {

		bookingObj=new ACBooking();
		//Create few  objects for ACSpecifications class and add to acList
		//Use this list to test all the methods in ACBooking class that requires a list of ACSpecifications 
		acs2=new ACSpecifications("LUCH00001","Central Air Conditioner","Lennox","Red",new SimpleDateFormat("dd/MM/yy").parse("12/03/1999"),6000.0);
        acs3=new ACSpecifications("LUCH00001","Central Air Conditioner","Lennox","Red",new SimpleDateFormat("dd/MM/yy").parse("12/03/1999"),6000.0);
        	acs4=new ACSpecifications("LUCH00003","Portable Air Conditioner","Samsung","White",new SimpleDateFormat("dd/MM/yy").parse("14/03/1999"),7000.0);
	}

	// Test validateModelNumber method with a Valid model number
	@Test
	public void test11ValidateModelNumber() throws InvalidACSpecException {
		// Fill the code
		assertTrue(bookingObj.validateModelNumber("LUCH00001"));
	}

	// Test validateModelNumber method with input String without LUCH
	@Test
	public void test12ValidateModelNumberWithoutStringLUCH() throws InvalidACSpecException {
		// Fill the code
		exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("Model Number is Invalid");
		assertTrue(bookingObj.validateModelNumber("AKAS00001"));
	}

	// Test validateModelNumber method with input String with more digits
	@Test
	public void test13ValidateModelNumberWithMoreDigits() throws InvalidACSpecException {
		// Fill the code
			exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("Model Number is Invalid");
		bookingObj.validateModelNumber("LUCH0000002");
		
	}

	// Test validateModelNumber method with input String with less digits
	@Test
	public void test14ValidateModelNumberWithLessDigits() throws InvalidACSpecException {
		// Fill the code
			exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("Model Number is Invalid");
		bookingObj.validateModelNumber("LUCH0001");
	}

	// Test viewACByModelNumber method with a valid model number
	@Test
	public void test15ViewACByValidModelNumber() throws InvalidACSpecException{
		// Fill the code
		List<ACSpecifications> l=new ArrayList<>();
		l.add(acs2);
		l.add(acs3);
		assertEquals(acs2,(bookingObj.viewACByModelNumber(l,"LUCH00001")));
    }

	// Test viewACByModelNumber method with an invalid model number
	@Test
	public void test16ViewACByInvalidModelNumber() throws InvalidACSpecException{
		// Fill the code
		
		List<ACSpecifications> l=new ArrayList<>();
		l.add(acs2);
		l.add(acs3);
		exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("Model number is invalid");
		assertEquals(acs2,(bookingObj.viewACByModelNumber(l,"LUCH0004")));
    
		
	}

	// Test viewACByItsType method
	@Test
	public void test17ViewACByItsType() throws InvalidACSpecException {
		// Fill the code
			List<ACSpecifications> l=new ArrayList<>();
		l.add(acs2);
		l.add(acs3);
		l.add(acs4);
			List<ACSpecifications> l2=new ArrayList<>();
		l2.add(acs2);
		l2.add(acs3);
			assertEquals(l2,bookingObj.viewACByItsType(l,"Central Air Conditioner"));
	}

	// Test viewACByItsType method for an empty list
	@Test
	public void test18ViewACByItsTypeForEmptyList() throws InvalidACSpecException {
		// Fill the code
		List<ACSpecifications> l=new ArrayList<>();
	
		exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("List is Empty");
		assertEquals(l,bookingObj.viewACByItsType(l,"Central Air Conditioner"));
	}

	// Test calculateTotalAmountByDateOfBooking method
	@Test
	public void test19CalculateTotalAmountByDateOfBooking() throws ParseException,InvalidACSpecException {
		// Fill the code
			List<ACSpecifications> l=new ArrayList<>();
		l.add(acs2);
		l.add(acs4);
		assertTrue(7000.0==bookingObj.calculateTotalAmountByDateOfBooking(l,new SimpleDateFormat("dd/MM/yyyy").parse("14/03/1999")));
	}

	// Test calculateTotalAmountByDateOfBooking method for an empty list
	@Test
	public void test20CalculateTotalAmountByDateOfBookingForEmptyList() throws ParseException,InvalidACSpecException {
		// Fill the code
		List<ACSpecifications> l=new ArrayList<>();
	
		exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("List is Empty");
			assertEquals(l,bookingObj.calculateTotalAmountByDateOfBooking(l,new SimpleDateFormat("dd/MM/yyyy").parse("12/03/1999")));
	}

	// Test viewACBrandNameWise method
	@Test
	public void test21ViewACBrandNameWise() throws InvalidACSpecException{
		// Fill the code
		Map<String,List<ACSpecifications>> result=new LinkedHashMap<>();
		List<ACSpecifications> l2=new ArrayList<>();
		l2.add(acs2);
		l2.add(acs3);
		l2.add(acs4);
		List<ACSpecifications> l=new ArrayList<>();
		l.add(acs2);
		l.add(acs3);
		List<ACSpecifications> l1=new ArrayList<>();
		l1.add(acs4);
		result.put("Lennox",l);
		result.put("Samsung",l1);
		assertEquals(result,bookingObj.viewACBrandNameWise(l2));

	}
	
	// Test viewACBrandNameWise method for an empty list
	@Test
	public void test22ViewACBrandNameWiseForEmptyList() throws InvalidACSpecException {
		// Fill the code
		Map<String,List<ACSpecifications>> result=new LinkedHashMap<>();
		List<ACSpecifications> l2=new ArrayList<>();
		exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("List is Empty");
		assertEquals(result,bookingObj.viewACBrandNameWise(l2));
	}

	// Test countOfACsByACColour method
	@Test
	public void test23CountOfACsByACColour() throws InvalidACSpecException{
		// Fill the code
			List<ACSpecifications> l2=new ArrayList<>();
		l2.add(acs2);
		l2.add(acs3);
		assertEquals(2,bookingObj.countOfACByACColour(l2,"Red"));
	}
	
	// Test countOfACsByACColour method for an empty list
	@Test
	public void test24CountOfACsByACColourForEmptyList() throws InvalidACSpecException {
		// Fill the code
			List<ACSpecifications> l2=new ArrayList<>();
			exceptionRule.expect(InvalidACSpecException.class);
		exceptionRule.expectMessage("List is Empty");
			assertEquals(l2,bookingObj.countOfACByACColour(l2,"White"));
	}

}
