package com.tour.test;
import static org.junit.Assert.assertTrue;
import com.tour.exception.InvalidTourPackageException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Test;

import com.tour.model.TourPackage;
import com.tour.util.ServiceProvider;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceProviderTest {
	
	private static List<TourPackage> packageList = new ArrayList<>();
	private static ServiceProvider serviceObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		serviceObj = new ServiceProvider();
		
		//Create few  objects for TourPackage class and add to packageList.
		//Use that list to test all the methods in ServiceProvider class that requires a list of TourPackage 
		packageList.add(new TourPackage("123","vij","gunt",5,"Independent",6000.0));
		packageList.add(new TourPackage("456","bza","nzb",2,"Escorted",60000.0));
		packageList.add(new TourPackage("789","vij","gunt",6,"Independent",5000.0));
		packageList.add(new TourPackage("321","xyz","lll",10,"Escorted",6500.0));
	}

	//Test the validatePackageType method when Independent
	@Test
	public void test11ValidatePackageTypeWhenIndependent() throws InvalidTourPackageException{
		
		//fill code
		assertTrue(serviceObj.validatePackageType("Independent"));
		
	}
	
	//Test the validatePackageType method when Escorted
	@Test
	public void test12ValidatePackageTypeWhenEscorted() throws InvalidTourPackageException{
		
		//fill code
		assertTrue(serviceObj.validatePackageType("Escorted"));
		
	}	
	
	//Test the validatePackageType method when invalid
	@Test(expected=InvalidTourPackageException.class)
	public void test13ValidatePackageTypeWhenInvalid() throws InvalidTourPackageException{
		
		//fill code
		serviceObj.validatePackageType("unknown");
		
	}
	
	//Test the viewTourPackage method for a valid packageId
	@Test
	public void test14ViewTourPackageForValidPackageId() throws InvalidTourPackageException{
		
		//fill code
		assertTrue(serviceObj.viewTourPackage(packageList,"123").getPackageId()=="123");

	}

	//Test the viewTourPackage method for an invalid packageId
	@Test(expected=InvalidTourPackageException.class)
	public void test15ViewTourPackageForInvalidPackageId() throws InvalidTourPackageException{
		
		//fill code
		serviceObj.viewTourPackage(packageList,"999");
		
	}

	//Test the viewTourPackagesByPackageType method 
	@Test
	public void test16ViewTourPackagesByPackageType() throws InvalidTourPackageException {
		
		//fill code
		List<TourPackage>m1=serviceObj.viewTourPackagesByPackageType(packageList,"Independent");
		assertTrue(m1.get(0).getPackageType()=="Independent");
		
	}

	//Test the viewTourPackagesByPackageType method for an empty list
	@Test(expected=InvalidTourPackageException.class)
	public void test17ViewTourPackagesByPackageTypeForEmptyList() throws InvalidTourPackageException {
	
		//fill code
		ArrayList<TourPackage>m=new ArrayList<>();
		serviceObj.viewTourPackagesByPackageType(m,"nnn");
		
	}
	
	//Test the viewTourPackagesTypeWise method
	@Test
	public void test18ViewTourPackagesTypeWise() throws InvalidTourPackageException{
	
		//fill code
		assertFalse(serviceObj.viewTourPackagesTypeWise(packageList).isEmpty());
		
	}
	private void assertFalse(boolean empty){
	    //for auto generating method stub
	}
	
	//Test the viewTourPackagesTypeWise method for empty list
	@Test(expected=InvalidTourPackageException.class)
	public void test19ViewTourPackagesTypeWiseForEmptyList() throws InvalidTourPackageException{
		
		//fill code
		ArrayList<TourPackage> m= new ArrayList<>();
		serviceObj.viewTourPackagesTypeWise(m);
		
	}
	
	//Test the countTotalTourPackagesForEachPackageType method
	@Test
	public void test20CountTotalTourPackagesForEachPackageType() throws InvalidTourPackageException{
		
		//fill code
		Map<String, Integer>m3=serviceObj.countTotalTourPackagesForEachPackageType(packageList,6000.0);
		assertFalse(serviceObj.countTotalTourPackagesForEachPackageType(packageList,6000.0).isEmpty());
		
	}

	//Test the countTotalTourPackagesForEachPackageType method for empty list
	@Test(expected=InvalidTourPackageException.class)
	public void test21CountTotalTourPackagesForEachPackageTypeForEmptyList() throws InvalidTourPackageException{
		
		//fill code
		ArrayList<TourPackage>m=new ArrayList<>();
		serviceObj.countTotalTourPackagesForEachPackageType(m,50.0);
		
	}	
}













