package com.aviva.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.aviva.exception.InvalidInsurancePolicyException;
import com.aviva.model.InsurancePolicy;

public class PolicyManagement {

	public boolean validatePolicyType(String policyType) throws InvalidInsurancePolicyException {
		boolean status = false;
		if (policyType.equalsIgnoreCase("Health Insurance") || policyType.equalsIgnoreCase("Vehicle Insurance")) {
			status = true;
		} else {
			status = false;
			throw new InvalidInsurancePolicyException("Valid Policies are - Health, Life, Vehicle Insurance");
		}

		return status;
	}

	public InsurancePolicy viewPolicyByInsurancePolicyId(List<InsurancePolicy> policyList, String policyId) throws InvalidInsurancePolicyException {

		if(policyList.size()==0){
			throw new InvalidInsurancePolicyException("Policy List is empty");
		}
		else {
			for(InsurancePolicy m : policyList){
				if(m.getPolicyId().equals(policyId))
					return m;
			}
			throw new InvalidInsurancePolicyException("Policy Type is invalid");	
		}
	}


	public List<InsurancePolicy> viewPolicyByExpiryDate(List<InsurancePolicy> policyList, Date expiryDate)
			throws InvalidInsurancePolicyException, ParseException {
		if(policyList.size()==0){
			throw new InvalidInsurancePolicyException("Policy List is empty");
		}
		else {
			List<InsurancePolicy> dateWiseList = new ArrayList<InsurancePolicy>();

			for (InsurancePolicy i:policyList) {
				if(i.getExpiryDate().compareTo(expiryDate)==0){
					dateWiseList.add(i);
				}
			}
			return dateWiseList; 
		}
	}

	public double calculatePremiumAmountByExpiryDate(List<InsurancePolicy> policyList, Date expiryDate)
			throws InvalidInsurancePolicyException, ParseException {
		if(policyList.size()==0){
			throw new InvalidInsurancePolicyException("Policy List is empty");
		}
		else {
			double sum=0;
			for (InsurancePolicy i:policyList) {
				if(i.getExpiryDate().compareTo(expiryDate)==0){
					sum=sum+i.getPremiumAmount();
				}
			}

			return sum; 
		}
	}


	public Map<String, List<InsurancePolicy>> countOfPolicyHoldersBasedOnPolicyType(List<InsurancePolicy> policyList) throws InvalidInsurancePolicyException {
		if(policyList.size()==0){
			throw new InvalidInsurancePolicyException("Policy List is empty");
		}
		else {
			Map<String,List<InsurancePolicy>> result = new LinkedHashMap<>();

			for(InsurancePolicy t : policyList){
				if(!result.containsKey(t.getPolicyType())){
					result.put(t.getPolicyType(),new ArrayList<InsurancePolicy>());
				}
				List<InsurancePolicy> temp=result.get(t.getPolicyType());
				temp.add(t);
				result.put(t.getPolicyType(), temp);			
			}
			return result;
		}		
	}

	public int countOfPolicyHoldersWithAdditonalBonus(List<InsurancePolicy> policyList, Date expiryDate) throws InvalidInsurancePolicyException {
		if(policyList.size()==0){
			throw new InvalidInsurancePolicyException("Policy List is empty");
		}
		else {
			int count=0;
			for (InsurancePolicy i: policyList) {

				if (i.getExpiryDate().compareTo(expiryDate)==1) {
					System.out.println(i.getPolicyDate());
					count++;
				}
			}

			return count;
		}
	}

}
