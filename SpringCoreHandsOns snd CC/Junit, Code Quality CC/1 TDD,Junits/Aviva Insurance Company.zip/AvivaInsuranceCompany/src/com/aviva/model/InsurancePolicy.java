package com.aviva.model;

import java.util.Date;

public class InsurancePolicy {
	
	private String policyId;
	private String policyType;
	private String policyName;
	private String customerName;
	private Date policyDate;
	private Date expiryDate;
	private double premiumAmount;
	
	public InsurancePolicy() {
		
	}

	public InsurancePolicy(String policyId, String policyType, String policyName, String customerName, Date policyDate,
			Date expiryDate, double premiumAmount) {
		super();
		this.policyId = policyId;
		this.policyType = policyType;
		this.policyName = policyName;
		this.customerName = customerName;
		this.policyDate = policyDate;
		this.expiryDate = expiryDate;
		this.premiumAmount = premiumAmount;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	@Override
	public String toString() {
		return "InsurancePolicy [policyId=" + policyId + ", policyType=" + policyType + ", policyName=" + policyName
				+ ", customerName=" + customerName + ", policyDate=" + policyDate + ", expiryDate=" + expiryDate
				+ ", premiumAmount=" + premiumAmount + "]";
	}
	
	

}
