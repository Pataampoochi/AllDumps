package com.mobile.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.mobile.exception.InvalidMobileException;
import com.mobile.model.Mobile;

public class MobileStore {

	public boolean validateMobileType (String mobileType) throws InvalidMobileException  {
	   if(mobileType.equalsIgnoreCase("smartphone") || mobileType.equalsIgnoreCase("basic"))
		   return true;
	   else
		   throw new InvalidMobileException("Mobile type invalid");
	}
	
	public Mobile viewMobile(List<Mobile> mobileList,String IMEINumber) throws InvalidMobileException {
		if(mobileList.size()==0){
			throw new InvalidMobileException("List is empty");
		}
		else {
			for(Mobile m : mobileList){
				if(m.getIMEINumber().equals(IMEINumber))
					return m;
			}
			throw new InvalidMobileException("IMEI Number is invalid");	
		}
	}
	
	public List<Mobile> viewMobilesByBrand (List<Mobile> mobileList ,String brand) throws InvalidMobileException {
		if(mobileList.size()==0){
			throw new InvalidMobileException("List is empty");
		}
		else {
			List<Mobile> result = new ArrayList<>();
			for(Mobile m : mobileList){
				if(m.getBrand().equals(brand))
					result.add(m);
			}
			return result;	
		}
	}
	
	public Map<String,List<Mobile>> viewMobilesBrandWise(List<Mobile> mobileList) throws InvalidMobileException {
		if(mobileList.size()==0){
			throw new InvalidMobileException("List is empty");
		}
		else {
			Map<String,List<Mobile>> result = new LinkedHashMap<>();
			
			for(Mobile m : mobileList){
				if(!result.containsKey(m.getBrand())){
					result.put(m.getBrand(),new ArrayList<Mobile>());
				}
				List<Mobile> temp=result.get(m.getBrand());
				temp.add(m);
				result.put(m.getBrand(), temp);			
			}
			return result;
		}
	}
	
	public  Map<String,Integer> countTotalModelsForEachBrand(List<Mobile> mobileList, double priceRange) throws InvalidMobileException {
		if(mobileList.size()==0){
			throw new InvalidMobileException("List is empty");
		}
		else {
			Map<String,Integer> result = new LinkedHashMap<>();
			
			for(Mobile m : mobileList){
				if(m.getMobilePrice()<=priceRange){
					if(!result.containsKey(m.getBrand())){
						result.put(m.getBrand(),1);
					}
					else
					{
						int temp=result.get(m.getBrand());					
						result.put(m.getBrand(), temp+1);
					}
				}
			}
			return result;
		}
	}

}