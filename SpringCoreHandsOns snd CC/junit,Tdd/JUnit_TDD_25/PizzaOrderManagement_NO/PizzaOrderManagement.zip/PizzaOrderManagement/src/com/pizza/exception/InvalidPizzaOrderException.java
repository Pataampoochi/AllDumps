package com.pizza.exception;
public class InvalidPizzaOrderException extends Exception {
	public InvalidPizzaOrderException(String message) {
		super(message);
	}
	
}
