package com.pizza.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.pizza.model.PizzaOrder;
import com.pizza.util.PizzaShop;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PizzaShopTest {

	private static PizzaShop psObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		psObj = new PizzaShop();
		//Create few  objects for PizzaOrder class and add to a list.
		//Set that list to the pizzaOrderList using the setPizzaOrderList method in PizzaShop class 	

	}

	//Test the validateSize method when size is small
	public void test11ValidateSizeWhenSmall(){
		
	}

	//Test the validateSize method when size is medium
	public void test12ValidateSizeWhenMedium(){
		
	}
	
	//Test the validateSize method when size is large
	public void test13ValidateSizeWhenLarge(){
	
	}
	
	//Test the validateSize method when size is invalid
	public void test14ValidateSizeWhenInvalid(){
		
	}
	
	//Test viewPizzaOrderById method for an existing order id.
	public void test15ViewPizzaOrderByIdWhenValid(){
	
	}
	
	//Test  viewPizzaOrderById method for a non existing order id.
	public void test16ViewPizzaOrderByIdWhenInvalid(){
		
	}
	
	//Test the correctness of viewPizzaOrdersByType method
	public void test17ViewPizzaOrdersByType(){
		
	}
	
	//Test the correctness of  viewPizzaOrdersTypeWise  method
	public void test18ViewPizzaOrdersTypeWise(){

	}
	
	//Test the correctness of countTotalQuantityForEachSize method
	public void test19CountTotalQuantityForEachSize(){
	
	}
	
	//Test the correctness of viewPizzaOrdersByType method when the list is empty	
	public void test20ViewPizzaOrdersByTypeForEmptyList(){
		
	}

	//Test the correctness of viewPizzaOrdersTypeWise method when the list is empty	
	public void test21ViewPizzaOrdersTypeWiseForEmptyList(){
		
	}
	
	//Test the correctness of countTotalQuantityForEachSize method when the list is empty	
	public void test22CountTotalQuantityForEachSizeForEmptyList(){
		
	}
}
