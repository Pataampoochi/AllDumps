package com.morrison.exception;

public class InvalidProjectInfoException extends Exception{

	public InvalidProjectInfoException(String s) {
		super();
	}
}
