package com.morrison.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.morrison.exception.InvalidProjectInfoException;
import com.morrison.model.ProjectInfo;
import com.morrison.util.BuildingContract;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BuildingContractTest {
	
	private static List<ProjectInfo> projectList = new ArrayList<ProjectInfo>();
	private static BuildingContract buildingContractObj ;
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		//Fill code here
		//Create few  objects for ProjectInfo class and add to a list.
		//Set that list to the projectList		
		buildingContractObj=new BuildingContract();
	}
	
	// Test vaildateConstructionType method with Construction type as Residential
	public void test11ValidateConstructionTypeForResidential() {
		//Fill code here
	}

	// Test vaildateConstructionType method with Construction type as Commercial
	public void test12ValidateConstructionTypeForCommercial() {
		//Fill code here
	}

	// Test vaildateConstructionType method with an invalid Construction type
	public void test13ValidateConstructionTypeForInvalidConstructionType() {
		//Fill code here
	}

	// Test viewProjectByProjectId method when Product Id is Valid
	public void test14ViewProjectByValidProjectId() {
		//Fill code here
	}
	
	// Test viewProjectByProjectId method when Product Id is Invalid
	public void test15ViewProjectByInvalidProjectId() {
		//Fill code here
	}
	
	// Test viewProjectsByConstructionType method
	public void test16ViewProjectsByConstructionType() {
		//Fill code here
	}
	
	// Test viewProjectsByConstructionType method for an empty list
	public void test17ViewProjectsByConstructionTypeForEmptyList() {
		//Fill code here
	}

	// Test countProjectsByAreaRange method
	public void test18CountProjectsByAreaRange() {
		//Fill code here
	}

	// Test countProjectsByAreaRange method for an empty list
	public void test19CountProjectsByAreaRangeForEmptyList() {
		//Fill code here
	}
	
	// Test viewProjectsByDateOfRegistration method
	public void test20ViewProjectsByDateOfRegistration() throws ParseException {
		//Fill code here
	}
	
	// Test viewProjectsByDateOfRegistration method for an empty list
	public void test21ViewProjectsByDateOfRegistrationForEmptyList() throws ParseException {
		//Fill code here
	}
	
	// Test calculateAmountDateOfCompletionWise method
	public void test22CalculateAmountDateOfCompletionWise() throws ParseException {
		//Fill code here
	}
	
	// Test calculateAmountDateOfCompletionWise method for an empty list
	public void test23CalculateAmountDateOfCompletionWiseForEmptyList() throws ParseException {
		//Fill code here
	}

}
