package com.morrison.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.morrison.exception.InvalidProjectInfoException;
import com.morrison.model.ProjectInfo;

public class BuildingContract {

	public boolean vaildateConstructionType(String constructionType) throws InvalidProjectInfoException {
		boolean status = false;
		if (constructionType.equalsIgnoreCase("Residential") || constructionType.equalsIgnoreCase("Commercial")) {
			status = true;
		} else {
			status = false;
			throw new InvalidProjectInfoException("Valid construction type should be given");
		}

		return status;
	}

	public ProjectInfo viewProjectByProjectId(List<ProjectInfo> projectList, String projectId) throws InvalidProjectInfoException{

		if(projectList.size()==0){
			throw new InvalidProjectInfoException("Project list is empty");
		}
		else{
			for(ProjectInfo p : projectList){
				if(p.getProjectId().equalsIgnoreCase(projectId)){
					return p;
				}
			}
			throw new InvalidProjectInfoException("Project ID is invalid");}
	}

	public List<ProjectInfo> viewProjectsByConstructionType(List<ProjectInfo> projectList, String constructionType) throws InvalidProjectInfoException {

		List<ProjectInfo> projectInfo=new ArrayList<ProjectInfo>();
		if (projectList.size() == 0) {
			throw new InvalidProjectInfoException("Project list is empty");
		}
		else{
			for (ProjectInfo i: projectList) {
				if (vaildateConstructionType(i.getConstructionType())) {
					if (i.getConstructionType().equalsIgnoreCase(constructionType)) {
						projectInfo.add(i);
					}
				}
			}
		}
		return projectInfo;
	}


	public int countProjectsByAreaRange(List<ProjectInfo> projectList, int fromArea,int toArea)
			throws InvalidProjectInfoException, ParseException {
		int count=0;
		if (projectList.size() == 0) {
			throw new InvalidProjectInfoException("Project list is empty");
		}
		else{
			for (ProjectInfo i:projectList) {
				if (i.getTotalSquareFeet()>=fromArea && i.getTotalSquareFeet()<=toArea) {
					count++;;
				}
			}
		}
		return count; 
	}


	public Map<Date, List<ProjectInfo>> viewProjectsByDateOfRegistration(List<ProjectInfo> projectList)throws InvalidProjectInfoException {
		Map<Date,List<ProjectInfo>> result = new LinkedHashMap<>();
		if (projectList.size() == 0) {
			throw new InvalidProjectInfoException("Project list is empty");}
		else{	
			for(ProjectInfo t : projectList){
				if(!result.containsKey(t.getDateOfRegistration())){
					result.put(t.getDateOfRegistration(),new ArrayList<ProjectInfo>());
				}
				List<ProjectInfo> temp=result.get(t.getDateOfRegistration());
				temp.add(t);
				result.put(t.getDateOfRegistration(), temp);			
			}

		}
		return result;
	}

	public Map<Date,Double> calculateAmountDateOfCompletionWise(List<ProjectInfo> projectList) throws InvalidProjectInfoException {
		Map<Date,Double> result = new LinkedHashMap<>();
		if (projectList.size() == 0) {
			throw new InvalidProjectInfoException("Project list is empty");}
		else {
			for(ProjectInfo m : projectList){
				if(!result.containsKey(m.getDateOfCompletion())){
					result.put(m.getDateOfCompletion(),m.getAmountQuoted());
				}
				else
				{
					double temp=result.get(m.getDateOfCompletion());					
					result.put(m.getDateOfCompletion(), temp+m.getAmountQuoted());
				}

			}
		}
		return result;
	}

}
