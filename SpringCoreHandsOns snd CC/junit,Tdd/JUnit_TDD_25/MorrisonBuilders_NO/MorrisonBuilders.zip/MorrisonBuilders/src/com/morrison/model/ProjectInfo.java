package com.morrison.model;

import java.util.Date;

public class ProjectInfo {
	
	private String projectId;
	private String constructionType;
	private int totalSquareFeet;
	private Date dateOfRegistration;
	private Date dateOfCompletion;
	private double amountQuoted;
	public ProjectInfo() {
		
	}
	public ProjectInfo(String projectId, String constructionType, int totalSquareFeet, Date dateOfRegistration,
			Date dateOfCompletion, double amountQuoted) {
		super();
		this.projectId = projectId;
		this.constructionType = constructionType;
		this.totalSquareFeet = totalSquareFeet;
		this.dateOfRegistration = dateOfRegistration;
		this.dateOfCompletion = dateOfCompletion;
		this.amountQuoted = amountQuoted;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getConstructionType() {
		return constructionType;
	}
	public void setConstructionType(String constructionType) {
		this.constructionType = constructionType;
	}
	public int getTotalSquareFeet() {
		return totalSquareFeet;
	}
	public void setTotalSquareFeet(int totalSquareFeet) {
		this.totalSquareFeet = totalSquareFeet;
	}
	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}
	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
	public Date getDateOfCompletion() {
		return dateOfCompletion;
	}
	public void setDateOfCompletion(Date dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}
	public double getAmountQuoted() {
		return amountQuoted;
	}
	public void setAmountQuoted(double amountQuoted) {
		this.amountQuoted = amountQuoted;
	}
	@Override
	public String toString() {
		return "ProjectInfo [projectId=" + projectId + ", constructionType=" + constructionType + ", totalSquareFeet="
				+ totalSquareFeet + ", dateOfRegistration=" + dateOfRegistration + ", dateOfCompletion="
				+ dateOfCompletion + ", amountQuoted=" + amountQuoted + "]";
	}
	
}
