package com.doctor.util;

import java.util.*;

import com.doctor.exception.InvalidDoctorInfoException;
import com.doctor.model.*;

public class DoctorUtility {
	public boolean validateSpecialization(String specialization) throws InvalidDoctorInfoException{
		boolean flag=false;
		if(specialization.equalsIgnoreCase("cardiologist") || specialization.equalsIgnoreCase("dentist") || specialization.equalsIgnoreCase("neurologist") || specialization.equalsIgnoreCase("gynecologist")){
			flag=true;
		}
		else {
			throw new InvalidDoctorInfoException("specialization is invalid");
		}
		return flag;
	}
	public DoctorInfo viewDoctorById(List<DoctorInfo> doctorList, String doctorId) throws InvalidDoctorInfoException{
		if(doctorList.isEmpty()){
			throw new InvalidDoctorInfoException("List is empty");
		}
		else{
			for(DoctorInfo num:doctorList){
				if(num.getDoctorId().equalsIgnoreCase(doctorId))
					return num;
			}
			throw new InvalidDoctorInfoException("Doctor Id is Invalid");
		}
		
	}
	public List<DoctorInfo> viewDoctorsAsSurgeon(List<DoctorInfo> doctorList) throws InvalidDoctorInfoException{
		if(doctorList.isEmpty()){
			throw new InvalidDoctorInfoException("List is empty");
		}
		else{
			List<DoctorInfo> result=new ArrayList<DoctorInfo>();
			for(DoctorInfo num:doctorList){
				if(num.isSurgeon())
					result.add(num);
			}
			return result;
		}
	}
	public Map<String,List<DoctorInfo>> viewDoctorsSpecializationWise(List<DoctorInfo> doctorList) throws InvalidDoctorInfoException{
		if(doctorList.isEmpty()){
			throw new InvalidDoctorInfoException("List is empty");
		}
		else{
			Map<String,List<DoctorInfo>> result=new HashMap<String,List<DoctorInfo>>();
			for(DoctorInfo num:doctorList){
				if(!result.containsKey(num.getSpecialization())){
					result.put(num.getSpecialization(),new ArrayList<DoctorInfo>());
				}
				List<DoctorInfo> temp=result.get(num.getSpecialization());
				temp.add(num);
				result.put(num.getSpecialization(), temp);	
			}
			return result;
		}
	}
	public Map<String,String> viewDoctorsAvailability(List<DoctorInfo> doctorList, String day) throws InvalidDoctorInfoException{
		if(doctorList.isEmpty()){
			throw new InvalidDoctorInfoException("List is empty");
		}
		else{
			Map<String,String> result=new HashMap<String,String>();
			for(DoctorInfo num:doctorList){
				if(num.getAvailableDays().contains(day)){
					result.put(num.getDoctorName(), num.getSpecialization());
				}
			}
			return result;
		}
	}
	public int viewDoctorsByYearsOfExperience(List<DoctorInfo> doctorList, int yearsOfExperience) throws InvalidDoctorInfoException{
		if(doctorList.isEmpty()){
			throw new InvalidDoctorInfoException("List is empty");
		}
		else{
			int count=0;
			for(DoctorInfo num:doctorList){
				if(num.getYearsOfExperience()==yearsOfExperience)
					count++;
			}
			return count;
		}
	}
}
