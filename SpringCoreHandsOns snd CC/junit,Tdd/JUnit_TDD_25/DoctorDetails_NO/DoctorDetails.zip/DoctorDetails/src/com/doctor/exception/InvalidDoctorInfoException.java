package com.doctor.exception;
public class InvalidDoctorInfoException extends Exception {
	public InvalidDoctorInfoException(String message) {
		super(message);
	}
}
