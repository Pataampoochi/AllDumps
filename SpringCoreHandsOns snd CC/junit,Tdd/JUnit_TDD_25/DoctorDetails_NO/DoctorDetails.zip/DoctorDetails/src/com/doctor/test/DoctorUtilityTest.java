package com.doctor.test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.doctor.exception.InvalidDoctorInfoException;
import com.doctor.model.DoctorInfo;
import com.doctor.util.DoctorUtility;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DoctorUtilityTest {
	private static List<DoctorInfo> doctorList = new ArrayList<>();
	private static DoctorUtility psObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		//Fill code here
		//Create few  objects for DoctorInfo class and add to a list.
		//Set that list to the doctorList
		psObj = new DoctorUtility();
		
	}

	// Test validateSpecialization method with Cardiologist
	public void test11ValidateSpecializationWhenCardiologist(){
		//Fill code here
	}
	
	// Test validateSpecialization method with Dentist
	public void test12ValidateSpecializationWhenDentist(){
		//Fill code here
	}
	
	// Test validateSpecialization method with Neurologist
	public void test13ValidateSpecializationWhenNeurologist(){
		//Fill code here
	}
	
	// Test validateSpecialization method with Gynecologist
	public void test14ValidateSpecializationWhenGynecologist(){
		//Fill code here
	}
	
	// Test validateSpecialization method with an invalid value
	public void test15ValidateSpecializationWhenInvalid(){
		//Fill code here
	}
	
	// Test viewDoctorById method with a valid Doctor Id
	public void test16ViewDoctorByIdWhenValid(){
		//Fill code here
	}
	
	// Test viewDoctorById method with an invalid Doctor Id
	public void test17ViewDoctorByIdWhenInvalid(){
		//Fill code here
	}
	
	// Test viewDoctorsAsSurgeon method
	public void test18ViewDoctorsAsSurgeon(){
		//Fill code here
	}
	
	// Test viewDoctorsSpecializationWise method
	public void test19ViewDoctorsSpecializationWise(){
		//Fill code here
	}
	
	// Test viewDoctorsAvailability method
	public void test20ViewDoctorsAvailability(){
		//Fill code here
	}
	
	// Test viewDoctorsByYearsOfExperience method
	public void test21ViewDoctorsByYearsOfExperience(){
		//Fill code here
	}
	
	// Test viewDoctorsAsSurgeon method for an empty list
	public void test22ViewDoctorsAsSurgeonForEmptyList(){
		//Fill code here
	}
	
	// Test viewDoctorsSpecializationWise method for an empty list
	public void test23ViewDoctorsSpecializationWiseForEmptyList(){
		//Fill code here
	}
	
	// Test viewDoctorsAvailability method for an empty list
	public void test24ViewDoctorsAvailabilityForEmptyList(){
		//Fill code here
	}
	
	// Test viewDoctorsByYearsOfExperience method for an empty list
	public void test25ViewDoctorsByYearsOfExperienceForEmptyList(){
		//Fill code here
	}
}
