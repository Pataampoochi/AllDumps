package com.doctor.model;

import java.util.Date;

public class DoctorInfo {
	private String doctorId;
	private String doctorName;
	private boolean isSurgeon;
	private String specialization;
	private String availableDays;
	private int yearsOfExperience;
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public boolean isSurgeon() {
		return isSurgeon;
	}
	public void setSurgeon(boolean isSurgeon) {
		this.isSurgeon = isSurgeon;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getAvailableDays() {
		return availableDays;
	}
	public void setAvailableDays(String availableDays) {
		this.availableDays = availableDays;
	}
	public int getYearsOfExperience() {
		return yearsOfExperience;
	}
	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}
	public DoctorInfo(String doctorId, String doctorName, boolean isSurgeon, String specialization,String availableDays, int yearsOfExperience) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.isSurgeon = isSurgeon;
		this.specialization = specialization;
		this.availableDays = availableDays;
		this.yearsOfExperience = yearsOfExperience;
	}
	public DoctorInfo() {
		super();
	}
	
}
