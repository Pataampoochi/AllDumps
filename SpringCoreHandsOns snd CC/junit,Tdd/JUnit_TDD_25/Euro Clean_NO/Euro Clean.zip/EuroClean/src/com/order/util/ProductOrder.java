package com.order.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.order.exception.InvalidOrderDetailsException;
import com.order.model.OrderDetails;

public class ProductOrder {

	public boolean validateOrderId(String orderId) throws InvalidOrderDetailsException {
		boolean status = false;
		int count =0;
		char[] ch=orderId.toCharArray();
		for(int i=0;i<=3;i++){
			if(Character.isDigit(ch[i]))
				count++;
		}
		if (count==4 && orderId.contains("Order") && orderId.length()==9) {
			status = true;
		} else {
			status = false;
			throw new InvalidOrderDetailsException("Valid Order Id should be given");
		}

		return status;
	}

	public OrderDetails viewOrderDetailsByOrderId(List<OrderDetails> orderList, String orderId) throws InvalidOrderDetailsException{

		if(orderList.size()==0){
			throw new InvalidOrderDetailsException("Order list is empty");
		}
		else{
			for(OrderDetails p : orderList){
				if(p.getOrderId().equalsIgnoreCase(orderId)){
					return p;
				}
			}
			throw new InvalidOrderDetailsException("Order ID is invalid");
		    
		}
	}

	public List<OrderDetails> viewOrderDetailsByOrderType(List<OrderDetails> orderList, String type) throws InvalidOrderDetailsException {

		List<OrderDetails> OrderDetails=new ArrayList<OrderDetails>();
		if (orderList.size() == 0) {
			throw new InvalidOrderDetailsException("Order list is empty");
		}
		else{
			for (OrderDetails i: orderList) {
				if (validateOrderId(i.getOrderId())) {
					if (i.getOrderType().equalsIgnoreCase(type)) {
						OrderDetails.add(i);
					}
				}
			}
		}
		return OrderDetails;
	}


	public int countOrdersByDateOfOrder(List<OrderDetails> orderList, Date date)
			throws InvalidOrderDetailsException, ParseException {
		int count=0;
		if (orderList.size() == 0) {
			throw new InvalidOrderDetailsException("Order list is empty");
		}
		else{
			for (OrderDetails i:orderList) {
				if (i.getDateOfOrder().compareTo(date)==0) {
					count++;;
				}
			}
		}
		return count; 
	}


	public Map<Date, List<OrderDetails>> viewOrdersByDateOfDelivery (List<OrderDetails> orderList)throws InvalidOrderDetailsException {
		Map<Date,List<OrderDetails>> result = new LinkedHashMap<>();
		if (orderList.size() == 0) {
			throw new InvalidOrderDetailsException("Order list is empty");}
		else{	
			for(OrderDetails t : orderList){
				if(!result.containsKey(t.getDateOfdelivery())){
					result.put(t.getDateOfdelivery(),new ArrayList<OrderDetails>());
				}
				List<OrderDetails> temp=result.get(t.getDateOfdelivery());
				temp.add(t);
				result.put(t.getDateOfdelivery(), temp);			
			}

		}
		return result;
	}

	public double calculateAmountByDateOfDelivery(List<OrderDetails> orderList, Date date) throws InvalidOrderDetailsException {
		double amount=0;
		if (orderList.size() == 0) {
			throw new InvalidOrderDetailsException("Order list is empty");
		}
		else{
			for (OrderDetails i: orderList) {
				if(i.getDateOfdelivery().compareTo(date)==0)
					amount=amount+i.getTotalAmount();
			} 
		}
		return amount;
	}

}
