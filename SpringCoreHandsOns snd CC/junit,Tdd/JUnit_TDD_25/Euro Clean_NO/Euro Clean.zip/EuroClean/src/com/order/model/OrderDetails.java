package com.order.model;

import java.util.Date;

public class OrderDetails {
	
	private String orderId;
	private String orderType;
	private String productId;
	private Date dateOfOrder;
	private Date dateOfdelivery;
	private double totalAmount;
	public OrderDetails() {
		
	}
	public OrderDetails(String orderId, String orderType, String productId, Date dateOfOrder, Date dateOfdelivery,
			double totalAmount) {
		super();
		this.orderId = orderId;
		this.orderType = orderType;
		this.productId = productId;
		this.dateOfOrder = dateOfOrder;
		this.dateOfdelivery = dateOfdelivery;
		this.totalAmount = totalAmount;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Date getDateOfOrder() {
		return dateOfOrder;
	}
	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}
	public Date getDateOfdelivery() {
		return dateOfdelivery;
	}
	public void setDateOfdelivery(Date dateOfdelivery) {
		this.dateOfdelivery = dateOfdelivery;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderType=" + orderType + ", productId=" + productId
				+ ", dateOfOrder=" + dateOfOrder + ", dateOfdelivery=" + dateOfdelivery + ", totalAmount="
				+ totalAmount + "]";
	}


}
