package com.order.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.order.exception.InvalidOrderDetailsException;
import com.order.model.OrderDetails;
import com.order.util.ProductOrder;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProductOrderTest {
	
	private static List<OrderDetails> orderList = new ArrayList<OrderDetails>();
	private static ProductOrder productOrderObj ;
	
	@BeforeClass
	public static void setUp() throws Exception {

		productOrderObj=new ProductOrder();
		// Fill the code
	}
	
	// Test validateOrderId method with a valid order Id
	public void test11ValidateOrderIdForValidOrderId() {
		// Fill the code
	}

	// Test validateOrderId method with an invalid order Id
	public void test12ValidateOrderIdForInvalidOrderId() {
		// Fill the code
	}

	// Test validateOrderId method when order Id is without the String Order
	public void test13ValidateOrderIdWithoutStringOrder() {
		// Fill the code
	}

	// Test validateOrderId method when order Id is without digits
	public void test14ValidateOrderIdWithoutDigits() {
		// Fill the code
	}
	
	// Test viewOrderDetailsByProductId method when Product Id is Valid
	public void test15ViewOrderDetailsByValidOrderId() {
		// Fill the code
	}
	
	// Test viewOrderDetailsByProductId method when Product Id is Invalid
	public void test16ViewOrderDetailsByInvalidOrderId() {
		// Fill the code
	}
	
	// Test viewOrderDetailsByOrderType method
	public void test17ViewOrderDetailsByOrderType() throws ParseException {
		// Fill the code
	}
	
	// Test viewOrderDetailsByOrderType method for an empty list
	public void test18ViewOrderDetailsByOrderTypeForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test countOrdersByDateOfOrder method
	public void test19CountOrdersByDateOfOrder() throws ParseException {
		// Fill the code
	}

	// Test countOrdersByDateOfOrder method for an empty list
	public void test20CountOrdersByDateOfOrderForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test viewOrdersByDateOfDelivery method
	public void test21ViewOrdersByDateOfDelivery() throws ParseException {
		// Fill the code
	}
	
	// Test viewOrdersByDateOfDelivery method for an empty list
	public void test22ViewOrdersByDateOfDeliveryForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfDelivery method
	public void test23CalculateAmountByDateOfDelivery() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfDelivery method for an empty list
	public void test24CalculateAmountByDateOfDeliveryForEmptyList() throws ParseException {
		// Fill the code
	}

}
