package com.order.exception;

public class InvalidOrderDetailsException extends Exception{
	
	public InvalidOrderDetailsException(String msg) {
		super(msg);
	}

}
