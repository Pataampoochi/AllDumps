package com.bank.util;

import java.util.*;

import com.bank.exception.InvalidTransactionException;
import com.bank.model.Transaction;

public class Bank {

	public boolean validateTransactionType(String transactionType) throws InvalidTransactionException {
		if(transactionType.equals("Debit") || transactionType.equals("Credit"))
			return true;
		else
			throw new InvalidTransactionException("Transaction type is invalid");
	}
	
	public Transaction viewTransaction(List<Transaction> transactionList,int transactionId) throws InvalidTransactionException{
		if(transactionList.size()==0){
			throw new InvalidTransactionException("Transaction list is empty");
		}
		else{
			for(Transaction t : transactionList){
				if(t.getTransactionId()==transactionId){
					return t;
				}
			}
			throw new InvalidTransactionException("Transaction ID is invalid");
		}
	}
	
	public List<Transaction> viewTransactionForAccount(List<Transaction> transactionList ,String accountNumber) throws InvalidTransactionException  {
		if(transactionList.size()==0){
			throw new InvalidTransactionException("Transaction list is empty");
		}
		else{
			List<Transaction> result = new ArrayList<>();
			for(Transaction t : transactionList){
				if(t.getAccountNumber().equals(accountNumber)){
					result.add(t);
				}
			}
			return result;
		}
		
	}
	
	
	public Map<String,List<Transaction>>  viewTransactionAccountwise(List<Transaction> transactionList) throws InvalidTransactionException  {
		if(transactionList.size()==0){
			throw new InvalidTransactionException("Transaction list is empty");
		}
		else {
			Map<String,List<Transaction>> result = new LinkedHashMap<>();
			
			for(Transaction t : transactionList){
				if(!result.containsKey(t.getAccountNumber())){
					result.put(t.getAccountNumber(),new ArrayList<Transaction>());
				}
				List<Transaction> temp=result.get(t.getAccountNumber());
				temp.add(t);
				result.put(t.getAccountNumber(), temp);			
			}
			return result;
		}		
	}

	public  Map<String,Integer> countTransactionsAccountwise(List<Transaction> transactionList , Date fromDate,Date toDate) throws InvalidTransactionException {
		if(transactionList.size()==0){
			throw new InvalidTransactionException("Transaction list is empty");
		}
		else {
			Map<String,Integer> result = new LinkedHashMap<>();
			
			for(Transaction t : transactionList){
				if(t.getTransactionDate().after(fromDate) && t.getTransactionDate().before(toDate)){
					if(!result.containsKey(t.getAccountNumber())){
						result.put(t.getAccountNumber(),1);
					}
					else
					result.put(t.getAccountNumber(), result.get(t.getAccountNumber())+1);
				}
							
			}
			return result;
		}		
	}
}