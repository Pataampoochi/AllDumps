package com.bank.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.bank.exception.InvalidTransactionException;
import com.bank.model.Transaction;
import com.bank.util.Bank;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BankTest {
	
	private static List<Transaction> transactionList = new ArrayList<Transaction>();
	private static Bank bankObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {

		bankObj = new Bank();
		
		//Create few Transaction objects and add to transactionList.
		//Use that list to test all the methods in Bank class that requires a list of transaction 
		
	}
	
	//Test the validateTransactionType method when the value is Credit
	public void test11ValidateTransactionTypeWhenCredit(){
		//fill code here		
	}
	
	//Test the validateTransactionType method when the value is Debit
	public void test12ValidateTransactionTypeWhenDebit() {
		//fill code here
	}
	
	//Test the validateTransactionType method when the value is invalid
	public void test13ValidateTransactionTypeWhenInvalid() {
		//fill code here		
	}
	
	//Test the viewTransaction method For Valid Id
	public void test14ViewTransactionForValidId() {
		//fill code here				
	}
	
	//Test the viewTransaction method For Invalid Id
	public void test15ViewTransactionForInvalidId() {
		//fill code here		
	}
	
	//Test the viewTransactionForAccount method 
	public void test16ViewTransactionForAccount() {
		//fill code here	
	}
	
	//Test the viewTransactionForAccount method when list is empty
	public void test17ViewTransactionForAccountForEmptyList() {
		//fill code here	
	}

	//Test the viewTransactionAccountwise method 
	public void test18ViewTransactionAccountwise() {
		//fill code here	
	}
	
	//Test the viewTransactionAccountwise method when list is empty
	public void test19ViewTransactionAccountwiseForEmptyList() {
		//fill code here
	}
	
	//Test the countTransactionsAccountwise method 
	public void test20CountTransactionsAccountwise(){
		//fill code here	
	}
	
	//Test the countTransactionsAccountwise method when list is empty
	public void test21CountTransactionsAccountwiseForEmptyList() {
		//fill code here
	}
}
