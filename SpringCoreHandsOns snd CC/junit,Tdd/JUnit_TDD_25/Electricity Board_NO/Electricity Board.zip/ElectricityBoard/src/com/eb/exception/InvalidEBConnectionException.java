package com.eb.exception;

public class InvalidEBConnectionException extends Exception {

	public InvalidEBConnectionException(String message) {
		super(message);
	}
}

