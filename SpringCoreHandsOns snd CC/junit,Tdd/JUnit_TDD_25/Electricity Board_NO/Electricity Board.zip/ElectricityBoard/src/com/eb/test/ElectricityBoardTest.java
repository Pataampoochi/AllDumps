package com.eb.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.eb.model.EBConnection;
import com.eb.util.ElectricityBoard;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ElectricityBoardTest {

	private static ElectricityBoard ebObj;


	@BeforeClass
	public static void setUp() throws Exception {

		ebObj = new ElectricityBoard();
	
		//Create few  objects for EBConnection class and add to a list.
		//Set that list to the ebConnectionList using the setEbConnectionList method in ElectricityBoard class 
	}


	//Test the validateConnectionType method when the value is domestic
	public void test11ValidateConnectionTypeWhenDomestic(){
		// Fill the code
	}

	//Test the validateConnectionType method when the value is commertial
	public void test12ValidateConnectionTypeWhenCommercial() {
		// Fill the code
	}

	//Test the validateConnectionType method when the value is industrial
	public void test13ValidateConnectionTypeWhenIndustrial() {
		// Fill the code
	}

	//Test the validateConnectionType method when the value is invalid
	public void test14ValidateConnectionTypeWhenInvalid() {

	}

	//Test the viewEBConnectionById method when the value is valid
	public void test15ViewEBConnectionByIdWhenValid() {
		// Fill the code
	}

	//Test the viewEBConnectionById method when the value is invalid
	public void test16ViewEBConnectionByIdWhenInvalid() {
		// Fill the code
	}

	//Test the viewEBConnectionsByConnectionType method
	public void test17ViewEBConnectionsByConnectionType() {
		// Fill the code
	}

	//Test the viewEBConnectionsConnectionTypeWise method
	public void test18ViewEBConnectionsConnectionTypeWise() {
		// Fill the code
	}

	//Test the countTotalConnectionForEachPhase method
	public void test19CountTotalConnectionForEachPhase(){
		// Fill the code
	}

	//Test the viewEBConnectionsByConnectionType method when the list is empty
	public void test20ViewEBConnectionsByConnectionTypeForEmptyList() {
		// Fill the code
	}

	//Test the viewEBConnectionsConnectionTypeWise method when the list is empty
	public void test21ViewEBConnectionsConnectionTypeWiseForEmptyList() {
		// Fill the code
	}
	//Test the countTotalConnectionForEachPhase method when the list is empty
	public void test22CountTotalConnectionForEachPhaseForEmptyList() {
		// Fill the code
	}
}

