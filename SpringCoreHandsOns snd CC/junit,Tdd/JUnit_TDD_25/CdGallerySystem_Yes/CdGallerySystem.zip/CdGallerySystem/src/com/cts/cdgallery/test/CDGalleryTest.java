package com.cts.cdgallery.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.cts.cdgallery.model.CDInfo;
import com.cts.cdgallery.util.CDGallery;
import com.cts.cdgallery.exception.InvalidCDInfoException;

public class CDGalleryTest {

	private static List<CDInfo> cdList = new ArrayList<CDInfo>();
	private static CDGallery cdGalleryObj=null;
	;


	@BeforeClass
	public static void setUp() throws Exception {
		cdGalleryObj=new CDGallery();	
		//Create few CDInfo objects and add to cdList.
		//Use that list to test all the methods in CDGallery class that requires a list of CDInfo

	}

	@AfterClass
	public static void tearDown() throws Exception {

	}

	// test the validateCDWorkingStatus method when a valid Status Yes is passed as parameter to this method. 
	public void test11ValidateCDWorkingStatusWhenYes() {

		// Code here..
	}

	//test the validateCDWorkingStatus  method when a valid Status No is passed as parameter to this method.
	public void test12ValidateCDWorkingStatusWhenNo() {
		// Code here..
	}

	//test the validateCDWorkingStatus method when an invalid Status is passed to this method.
	public void test13ValidateCDWorkingStatusWhenInvalid() {
		// Code here..
	}

	//test the validateCDReleaseYear method when valid Year is provided
	public void test14ValidateCDReleaseYearForValidYear() {
		// Code here..
	}

	//test the validateCDReleaseYear method when invalid Year is provided
	public void test15ValidateCDReleaseYearForInvalidYear() {
		// Code here..
	}

	//test the countNoOfWorkingCDs method when a CD List is passed as parameter.
	public void test16CountNoOfWorkingCDs() {
		// Code here..

	}

	//test the viewCDInfoBetweenReleaseYear method when from release date and to release date is passed as parameter exists in the cdList.
	public void test17ViewCDInfoBetweenReleaseYear() {
		// Code here..

	}

	//test the countNoOfMoviesOfProducer method when a CD List is passed as parameter.
	public void test18CountNoOfMoviesOfProducer() {
		// Code here...
	}

}
