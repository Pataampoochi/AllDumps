package com.cts.cdgallery.exception;

public class InvalidCDInfoException extends Exception {

	public InvalidCDInfoException(String msg) {
		super(msg);
	}
}
