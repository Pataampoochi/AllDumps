package com.cts.cdgallery.model;

//model class
public class CDInfo {
	private String cdId;
	private String movieName;
	private String producerName;
	private long releaseYear;
	private String cdWorkingStatus; // YES, NO

	public CDInfo() {
		// TODO Auto-generated constructor stub
	}

	public CDInfo(String cdId, String movieName, String producerName, long releaseYear, String cdWorkingStatus) {
		super();
		this.cdId = cdId;
		this.movieName = movieName;
		this.producerName = producerName;
		this.releaseYear = releaseYear;
		this.cdWorkingStatus = cdWorkingStatus;
	}

	public String getCdId() {
		return cdId;
	}

	public void setCdId(String cdId) {
		this.cdId = cdId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getProducerName() {
		return producerName;
	}

	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}

	public long getReleaseYear() {
		return releaseYear;
	}

	public void setReleaseYear(long releaseYear) {
		this.releaseYear = releaseYear;
	}

	public String getCdWorkingStatus() {
		return cdWorkingStatus;
	}

	public void setCdWorkingStatus(String cdWorkingStatus) {
		this.cdWorkingStatus = cdWorkingStatus;
	}

	@Override
	public String toString() {
		return "CDInfo [cdId=" + cdId + ", movieName=" + movieName + ", producerName=" + producerName + ", releaseYear="
				+ releaseYear + ", cdWorkingStatus=" + cdWorkingStatus + "]";
	}

}
