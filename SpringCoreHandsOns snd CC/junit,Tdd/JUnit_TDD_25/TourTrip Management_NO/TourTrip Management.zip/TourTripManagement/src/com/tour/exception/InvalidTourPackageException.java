package com.tour.exception;

public class InvalidTourPackageException extends Exception {

	public InvalidTourPackageException(String message) {
		super(message);
	}
}

