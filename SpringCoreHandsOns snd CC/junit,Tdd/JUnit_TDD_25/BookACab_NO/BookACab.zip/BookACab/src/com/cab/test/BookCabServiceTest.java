package com.cab.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.cab.model.BookCab;
import com.cab.util.BookCabService;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BookCabServiceTest {
	
	private static BookCabService serviceObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		serviceObj = new BookCabService();	
		//fill code here
		//Create few  objects for BookCab class and add to a list.
		//Set that list to the bookCabList using the setBookCabList method in BookCabService class 
	}
	
	//Test validateChaufferId method when the value is valid
	public void test11ValidateChaufferId(){
		//fill code here
	}
	
	//Test validateChaufferId method when the value is invalid
	public void test12ValidateChaufferIdWhenInvalid() {
		//fill code here		
	}
	
	
	//Test viewBookingById method for an existing bookingId
	public void test13ViewBookingByIdWhenValid() {
		//fill code here		
	}
	
	//Test viewBookingById method when the bookingId does not exist
	public void test14ViewBookingByIdWhenInvalid() {
		//fill code here
	}

    //Test viewBookingByBookDate method
	public void test15ViewBookingByBookDate() {
		//fill code here
	}
	
	//Test viewTotalIncomeChaufferwise method
	public void test16ViewTotalIncomeChaufferwise() {
		//fill code here		
	}
		
    //Test the viewBookingPickupPlacewise method
	public void test17ViewBookingPickupPlacewise(){
		//fill code here	
	}
	

	//Test countBookingByChauffer method 
	public void test18CountBookingByChauffer() {
		//fill code here
	}

	
	//Test viewBookingByBookDate method when the list is empty
	public void test19ViewBookingByBookDateForEmptyList() {
		//fill code here		
	}

	//Test the viewTotalIncomeChaufferwise method when the list is empty
	public void test20ViewTotalIncomeChaufferwiseForEmptyList() {
		//fill code here
	}
	
	//Test the viewBookingPickupPlacewise method when the list is empty
	public void test21ViewBookingPickupPlacewiseForEmptyList(){
		//fill code here	
	}
		
	//Test countBookingByChauffer method when the list is empty
	public void test22CountBookingByChaufferForEmptyList() {
		//fill code here
	}	
}

