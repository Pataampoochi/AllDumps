package com.cab.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

import com.cab.skeleton.SkeletonValidator;

public class Main {

	public static void main(String[] args) {

		SkeletonValidator validator = new SkeletonValidator();

		Result result = JUnitCore.runClasses(BookCabServiceTest.class);
		if (result.getFailureCount() == 0) {
			System.out.println("All Test cases Cleared");
		} else {
			System.out.println("One or more test case(s) failed");
			System.out.println("===============================");
			result.getFailures().forEach(x -> System.out.println(x.getMessage()));
		}
		
	}

}
