package com.cab.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.cab.exception.InvalidBookCabException;
import com.cab.model.BookCab;



public class BookCabService {	
	
	List<BookCab> bookCabList = new ArrayList<>();
	
	public boolean validateChaufferId(String chaufferId) throws InvalidBookCabException {
		if(chaufferId.matches("(FLY)[/][0-9]{3}[/][0-9]{4}")){
			return true;
		}
		else	
			throw new InvalidBookCabException("Chauffer Id is invalid");
	}
	
	public BookCab viewBookingById(int bookingId) throws InvalidBookCabException {
		
		if(bookCabList.size()==0){
			throw new InvalidBookCabException("List is empty");
		}
		else {
			for(BookCab cab : bookCabList){
				if(cab.getBookingId()==bookingId)
					return cab;
			}
			throw new InvalidBookCabException("Booking ID is invalid");	
		}
	}
	
	public List<BookCab> viewBookingByBookDate(Date bookDate) throws InvalidBookCabException{

		if(bookCabList.size()==0){
			throw new InvalidBookCabException("List is empty");
		}
		else {
			
			List<BookCab> result = new ArrayList<>();
			
			for(BookCab cab : bookCabList){
				if(cab.getBookDate().compareTo(bookDate)==0)
					result.add(cab);
			}
			return result;
		}	
	}

	public Map<String,Double> viewTotalIncomeChaufferwise() throws InvalidBookCabException
	{
		if(bookCabList.size()==0){
			throw new InvalidBookCabException("List is empty");
		}
		else {
			
			Map<String,Double> result = new LinkedHashMap<>();

			for(BookCab cab : bookCabList){
			if(!result.containsKey(cab.getChaufferId())){
				result.put(cab.getChaufferId(),cab.getTotalFare());
			}
			else
			{
				double temp=result.get(cab.getChaufferId());
				temp=temp+cab.getTotalFare();
				result.put(cab.getChaufferId(), temp);
			}
						
		}
		return result;

		}
		
	}
	
	public Map<String,List<BookCab>> viewBookingPickupPlacewise() throws InvalidBookCabException {
		
		if(bookCabList.size()==0){
			throw new InvalidBookCabException("List is empty");
		}
		else {
			Map<String,List<BookCab>> result=new LinkedHashMap<>();
			for(BookCab cab : bookCabList){
				if(!result.containsKey(cab.getPickupPlace())){
					result.put(cab.getPickupPlace(),new ArrayList<BookCab>());
				}
				List<BookCab> temp=result.get(cab.getPickupPlace());
				temp.add(cab);
				result.put(cab.getPickupPlace(), temp);			
			}
			return result;

		}
		
	}


	public int countBookingByChauffer(String chaufferId) throws InvalidBookCabException {
		if(bookCabList.size()==0){
			throw new InvalidBookCabException("List is empty");
		}
		else {
			int count=0;
			for(BookCab cab : bookCabList){
				if(cab.getChaufferId().equals(chaufferId))
					count++;
			}
			return count;
		}
	}

}

