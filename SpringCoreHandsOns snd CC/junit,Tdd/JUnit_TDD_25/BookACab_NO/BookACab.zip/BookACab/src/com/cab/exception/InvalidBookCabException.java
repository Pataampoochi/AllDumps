package com.cab.exception;

public class InvalidBookCabException extends Exception {

	public InvalidBookCabException(String message) {
		super(message);
	}
}

