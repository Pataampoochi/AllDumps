package com.cab.model;

import java.util.Date;

public class BookCab {
	
	private int bookingId;
	private Date bookDate;
	private String cabType;
	private String chaufferId;
	private String pickupPlace;
	private String dropPlace;
	private int distanceTravelled;
	private double totalFare;

	public BookCab(){
		
	}

	public BookCab(int bookingId, Date bookDate, String cabType, String chaufferId, String pickupPlace,
			String dropPlace, int distanceTravelled, double totalFare) {
		
		this.bookingId = bookingId;
		this.bookDate = bookDate;
		this.cabType = cabType;
		this.chaufferId = chaufferId;
		this.pickupPlace = pickupPlace;
		this.dropPlace = dropPlace;
		this.distanceTravelled = distanceTravelled;
		this.totalFare = totalFare;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Date getBookDate() {
		return bookDate;
	}

	public void setBookDate(Date bookDate) {
		this.bookDate = bookDate;
	}

	public String getCabType() {
		return cabType;
	}

	public void setCabType(String cabType) {
		this.cabType = cabType;
	}

	public String getChaufferId() {
		return chaufferId;
	}

	public void setChaufferId(String chaufferId) {
		this.chaufferId = chaufferId;
	}

	public String getPickupPlace() {
		return pickupPlace;
	}

	public void setPickupPlace(String pickupPlace) {
		this.pickupPlace = pickupPlace;
	}

	public String getDropPlace() {
		return dropPlace;
	}

	public void setDropPlace(String dropPlace) {
		this.dropPlace = dropPlace;
	}

	public int getDistanceTravelled() {
		return distanceTravelled;
	}

	public void setDistanceTravelled(int distanceTravelled) {
		this.distanceTravelled = distanceTravelled;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}	
	
}
