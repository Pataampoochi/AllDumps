package com.cts.test;

import java.util.List;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.model.DailyAttendance;
import com.cts.utility.MarkAttendance;
import com.cts.exception.InvalidAttendanceMarkingException;


public class MarkAttendanceTest {

	MarkAttendance markAttendanceObj;
	List<DailyAttendance> attendanceList=new ArrayList<>();

	@Before
	public void setUp() {
		markAttendanceObj = new MarkAttendance();
		
		// code here
		//Create few objects of DailyAttendance and add those objects to attendanceList
		//Set this list to the attendanceList in MarkAttendance class using setAttendanceList method
		
		
	}

	@After
	public void tearDown(){

		//code here
	}

	// test the validateSchedule method when a valid Schedule Yes is passed as parameter to this method. 	
	public void test11ValidateAsPerScheduleWhenYes()
	{

		//code here
	}
	//test the validateSchedule  method when a valid Schedule No is passed as parameter to this method. 
	public void test12ValidateAsPerScheduleWhenNo()
	{

		//code here
	}

	//test the validateSchedule method when an invalid Schedule is passed to this method.
	public void test13ValidateAsPerScheduleWhenInvalid()
	{

		//code here
	}

	//test the addAttendance method when valid Schedule is provided for the DailyAttendance success
	public void test14AddAttendanceForValidSchedule()
	{

		//code here
	}

	// test the addAttendance  method when invalid Schedule is provided for the DailyAttendance. In this case, addAttendance method is expected to throw InvalidAttendanceMarkingException.
	public void test15AddAttendanceForInValidSchedule()
	{


		//code here
	}

	//test the viewEmployeeAttendanceById method when a EmployeeID is passed as parameter exists in the attendanceList.
	public void test16viewEmployeeAttendanceByIdForValidId()
	{
		//code here
	}

	//test the viewEmployeeAttendanceById method when a EmployeeID is passed as parameter does not exist in the attendanceList.
	public void test17viewEmployeeAttendanceByIdForInValidId()
	{
		//code here
	}

	// test the correctness of the  viewAttendanceByDate method. Perform testing for the correctness of the list returned. 
	public void test18viewAttendanceByDate()
	{
		//code here
	}

	// test the correctness of the  viewAttendanceByDate method. Perform testing for the not existing date and handle the exception 
	public void test19viewNotMarkedAttendanceParticularDate()
	{
		//code here
	}


	// test the correctness of viewSubjectExpertWise method. Perform testing for the correctness of the map returned.
	public void test20viewSubjectExpertWise()
	{
		//code here
	}

}
