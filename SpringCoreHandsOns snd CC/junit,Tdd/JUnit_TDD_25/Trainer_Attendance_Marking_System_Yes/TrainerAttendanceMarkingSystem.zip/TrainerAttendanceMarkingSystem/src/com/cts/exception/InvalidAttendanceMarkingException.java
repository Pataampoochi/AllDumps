package com.cts.exception;

public class InvalidAttendanceMarkingException extends Exception
{
	public InvalidAttendanceMarkingException(String message)
	{
		super(message);
	}
}
