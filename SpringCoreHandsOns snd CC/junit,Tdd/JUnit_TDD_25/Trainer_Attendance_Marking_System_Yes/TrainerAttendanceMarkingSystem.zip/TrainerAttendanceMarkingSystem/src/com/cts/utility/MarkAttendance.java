package com.cts.utility;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.cts.exception.InvalidAttendanceMarkingException;
import com.cts.model.DailyAttendance;

public class MarkAttendance {

	private List<DailyAttendance> attendanceList;

	public MarkAttendance() {
		attendanceList = new ArrayList<DailyAttendance>();
	}

	public List<DailyAttendance> getAttendanceList() {
		return attendanceList;
	}

	public void setAttendanceList(List<DailyAttendance> attendanceList) {
		this.attendanceList = attendanceList;
	}

	public boolean validateSchedule(String asPerSchedule) throws InvalidAttendanceMarkingException {
		boolean isValid = false;
		if (asPerSchedule.equalsIgnoreCase("yes") || asPerSchedule.equalsIgnoreCase("no")) {
			isValid = true;
		} else {
			throw new InvalidAttendanceMarkingException("Invalid AsPerSchedule");
		}
		return isValid;
	}

	public boolean addAttendance(int employeeID, String subjectExpert, String topicsHandled, String asPerSchedule,
			LocalDateTime inDateTime, LocalDateTime outDateTime) throws InvalidAttendanceMarkingException {
		boolean isAdded = false;
		if (validateSchedule(asPerSchedule)) {
			DailyAttendance dailyAttendance = new DailyAttendance(employeeID, subjectExpert, topicsHandled,
					asPerSchedule, inDateTime, outDateTime);
			attendanceList.add(dailyAttendance);
			isAdded = true;
		} else {
			throw new InvalidAttendanceMarkingException("Invalid AsPerSchedule");
		}
		return isAdded;
	}

	public DailyAttendance viewEmployeeAttendanceById(int employeeID) throws InvalidAttendanceMarkingException {
		DailyAttendance dailyAttendanceObj = null;
		for (DailyAttendance dailyAttendance : attendanceList) {
			if (dailyAttendance.getEmployeeID() == employeeID) {
				dailyAttendanceObj = dailyAttendance;
				break;
			}
		}
		if (dailyAttendanceObj == null) {
			throw new InvalidAttendanceMarkingException("Invalid Employee id");
		}
		return dailyAttendanceObj;
	}

	public List<DailyAttendance> viewAttendanceByDate(LocalDateTime inDateTime, LocalDateTime outDateTime) throws InvalidAttendanceMarkingException {
		List<DailyAttendance> resultList = new ArrayList<DailyAttendance>();
		for (DailyAttendance dailyAttendance : attendanceList) {
			if (inDateTime.equals(dailyAttendance.getInDatetime())
					&& outDateTime.equals(dailyAttendance.getOutDatetime())) {
				resultList.add(dailyAttendance);
			}
		}
		if (resultList.isEmpty()) {
			throw new InvalidAttendanceMarkingException("No Matching Found");
		}

		return resultList;
	}

	public Map<String, List<DailyAttendance>> viewSubjectExpertWise() {
		Map<String, List<DailyAttendance>> myMaps = new HashMap<String, List<DailyAttendance>>();
		for (DailyAttendance item : attendanceList) {
			if (myMaps.containsKey(item.getSubjectExpert()) == false) {
				myMaps.put(item.getSubjectExpert(), new ArrayList<DailyAttendance>());
			}
			myMaps.get(item.getSubjectExpert()).add(item);
		}
		return myMaps;
	}

}
