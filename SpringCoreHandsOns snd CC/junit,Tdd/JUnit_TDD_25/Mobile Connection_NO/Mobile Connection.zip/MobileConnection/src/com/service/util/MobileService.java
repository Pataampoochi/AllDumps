package com.service.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.service.exception.InvalidMobileServiceException;
import com.service.model.Mobile;



public class MobileService {
	
	
	public boolean validateConnectionType(String connectionType) throws InvalidMobileServiceException  {
	   if(connectionType.equalsIgnoreCase("prepaid") || connectionType.equalsIgnoreCase("postpaid")  || connectionType.equalsIgnoreCase("dth"))
		   return true;
	   else
		   throw new InvalidMobileServiceException("Connection type invalid");
	}
	
	public Mobile viewMobileByMobileNumber(List<Mobile> mobileList,String mobileNumber) throws InvalidMobileServiceException {
		if(mobileList.size()==0){
			throw new InvalidMobileServiceException("List is empty");
		}
		else {
			for(Mobile m : mobileList){
				if(m.getMobileNumber().equals(mobileNumber))
					return m;
			}
			throw new InvalidMobileServiceException("Mobile number does not exist");	
		}
	}
	
	public List<Mobile> viewMobilesByConnectionType(List<Mobile> mobileList,String connectionType) throws InvalidMobileServiceException {
		if(mobileList.size()==0){
			throw new InvalidMobileServiceException("List is empty");
		}
		else {
			List<Mobile> result = new ArrayList<>();
			for(Mobile m : mobileList){
				if(m.getConnectionType().equals(connectionType))
					result.add(m);
			}
			return result;	
		}
	}
	
	public Map<String,List<Mobile>> viewMobilesServiceProviderWise(List<Mobile> mobileList) throws InvalidMobileServiceException {
		if(mobileList.size()==0){
			throw new InvalidMobileServiceException("List is empty");
		}
		else {
			Map<String,List<Mobile>> result = new LinkedHashMap<>();
			
			for(Mobile m : mobileList){
				if(!result.containsKey(m.getServiceProvider())){
					result.put(m.getServiceProvider(),new ArrayList<Mobile>());
				}
				List<Mobile> temp=result.get(m.getServiceProvider());
				temp.add(m);
				result.put(m.getServiceProvider(), temp);			
			}
			return result;
		}
	}
	
	public  Map<String,Integer> countTotalConnectionForEachPlan(List<Mobile> mobileList) throws InvalidMobileServiceException {
		if(mobileList.size()==0){
			throw new InvalidMobileServiceException("List is empty");
		}
		else {
			Map<String,Integer> result = new LinkedHashMap<>();
			
			for(Mobile m : mobileList){
				if(!result.containsKey(m.getPlan())){
					result.put(m.getPlan(),1);
				}
				else
				{
					int temp=result.get(m.getPlan());					
					result.put(m.getPlan(), temp+1);
				}				
			}
			return result;
		}
	}	
}

