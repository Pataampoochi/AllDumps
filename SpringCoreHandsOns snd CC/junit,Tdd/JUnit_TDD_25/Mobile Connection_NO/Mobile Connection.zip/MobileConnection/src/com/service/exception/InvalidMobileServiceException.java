package com.service.exception;

public class InvalidMobileServiceException extends Exception {

	public InvalidMobileServiceException(String message) {
		super(message);
	}
}

