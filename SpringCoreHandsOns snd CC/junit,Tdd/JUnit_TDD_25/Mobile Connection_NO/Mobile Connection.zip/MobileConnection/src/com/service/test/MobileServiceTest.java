package com.service.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.service.model.Mobile;
import com.service.util.MobileService;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MobileServiceTest {
	
	private static List<Mobile> mobileList = new ArrayList<>();
	private static MobileService serviceObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		serviceObj = new MobileService();	
		//Create few  objects for Mobile class and add to mobileList.
		//Use this list to test all the methods in MobileService class that requires a list of Mobile 
				
	}
	
	//Test the validateConnectionType method when the value is prepaid
	public void test11ValidateConnectionTypeWhenPrepaid(){
		//fill code here
	}
	
	//Test the validateConnectionType method when the value is postpaid
	public void test12ValidateConnectionTypeWhenPostpaid() {
		//fill code here		
	}
	
	//Test the validateConnectionType method when the value is DTH
	public void test13ValidateConnectionTypeWhenDTH() {
		//fill code here		
	}
	
	//Test the validateConnectionType method when the value is invalid
	public void test14ValidateConnectionTypeWhenInvalid() {
		//fill code here
	}
	
	//Test the viewMobileByMobileNumber method when the value is valid
	public void test15ViewMobileByMobileNumberWhenValid() {
		//fill code here		
	}
	
	//Test the viewMobileByMobileNumber method when the value is invalid
	public void test16ViewMobileByMobileNumberWhenInvalid() {
		//fill code here
	}

    //Test the viewMobilesByConnectionType method
	public void test17ViewMobilesByConnectionType() {
		//fill code here
	}		
	
	//Test the viewMobilesByConnectionType method when the list is empty
	public void test18ViewMobilesByConnectionTypeForEmptyList() {
		//fill code here		
	}
	
	//Test the viewMobilesServiceProviderWise method
	public void test19ViewMobilesServiceProviderWise() {
		//fill code here		
	}
		
	//Test the viewMobilesServiceProviderWise method when the list is empty
	public void test20ViewMobilesServiceProviderWiseForEmptyList() {
		//fill code here
	}

    //Test the countTotalConnectionForEachPlan method
	public void test21CountTotalConnectionForEachPlan(){
		//fill code here	
	}
	
	//Test the countTotalConnectionForEachPlan method when the list is empty
	public void test22CountTotalConnectionForEachPlanForEmptyList() {
		//fill code here
	}
	
}

