package com.ac.skeleton;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *		   This class is used to verify if the Code Skeleton is intact
 *         and not modified by participants thereby ensuring smooth auto
 *         evaluation
 */

public class SkeletonValidator {
	public SkeletonValidator() {
		validateClassName("com.ac.util.ServiceCenter");
		validateClassName("com.ac.model.ServiceDetails");
		validateClassName("com.ac.exception.InvalidServiceDetailsException");
		validateClassName("com.ac.test.ServiceCenterTest");

		validateMethodSignature(
				"getServiceCode:java.lang.String,setServiceCode:void,getAcType:java.lang.String,setAcType:void,getServiceType:java.lang.String,setServiceType:void,getCustomerName:java.lang.String,setCustomerName:void,getPhoneNumber:java.lang.String,setPhoneNumber:void,getAppointmentDate:java.util.Date,setAppointmentDate:void",
				"com.ac.model.ServiceDetails");
		validateMethodSignature(
				"viewServiceDetailsByServiceType:java.util.List,viewServiceDetailsAppointmentDateWise:java.util.Map,countTotalCountForEachAcType:java.util.Map,viewServiceDetailsByCode:com.ac.model.ServiceDetails,getServiceDetailsList:java.util.List,validateAcType:boolean,setServiceDetailsList:void",
				"com.ac.util.ServiceCenter");
		validateMethodSignature(
				"test11ValidateAcTypeWhenSplit:void,test12ValidateAcTypeWhenWindow:void,test13ValidateAcTypeWhenCentralized:void,test14ValidateAcTypeWhenPortable:void,test15ValidateAcTypeWhenInvalid:void,test16ViewServiceDetailsByCodeWhenValid:void,test17ViewServiceDetailsByCodeWhenInvalid:void,test18ViewServiceDetailsByServiceType:void,test19ViewServiceDetailsAppointmentDateWise:void,test20CountTotalCountForEachAcType:void,test21ViewServiceDetailsByServiceTypeForEmptyList:void,test22ViewServiceDetailsAppointmentDateWiseForEmptyList:void,test23CountTotalCountForEachAcTypeForEmptyList:void",
				"com.ac.test.ServiceCenterTest");

	}

	private static final Logger LOG = Logger.getLogger("SkeletonValidator");

	protected final boolean validateClassName(String className) {

		boolean iscorrect = false;
		try {
			Class.forName(className);
			iscorrect = true;
			LOG.info("Class Name " + className + " is correct");

		} catch (ClassNotFoundException e) {
			LOG.log(Level.SEVERE, "You have changed either the " + "class name/package. Use the correct package "
					+ "and class name as provided in the skeleton - "+className);

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					"There is an error in validating the " + "Class Name. Please manually verify that the "
							+ "Class name is same as skeleton before uploading");
		}
		return iscorrect;
	}

	protected final void validateMethodSignature(String methodWithExcptn, String className) {
		Class cls = null;
		String methodName = null;
		try {

			String[] actualmethods = methodWithExcptn.split(",");
			boolean errorFlag = false;
			String[] methodSignature;
			
			String returnType = null;

			for (String singleMethod : actualmethods) {
				boolean foundMethod = false;
				methodSignature = singleMethod.split(":");

				methodName = methodSignature[0];
				returnType = methodSignature[1];
				cls = Class.forName(className);
				Method[] methods = cls.getMethods();
				for (Method findMethod : methods) {
					if (methodName.equals(findMethod.getName())) {
						foundMethod = true;
						if (!(findMethod.getReturnType().getName().equals(returnType))) {
							errorFlag = true;
							LOG.log(Level.SEVERE, " You have changed the " + "return type in '" + methodName
									+ "' method. Please stick to the " + "skeleton provided");

						} else {
							LOG.info("Method signature of " + methodName + " is valid");
						}

					}
				}
				if (!foundMethod) {
					errorFlag = true;
					LOG.log(Level.SEVERE, " Unable to find the given public method " + methodName
							+ ". Do not change the " + "given public method name. " + "Verify it with the skeleton");
				}

			}
			if (!errorFlag) {
				LOG.info("Method signature is valid");
			}

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					" There is an error in validating the " + "method structure. Please manually verify that the "
							+ "Method signature is same as the skeleton before uploading. Class Name : "+className+", method name : "+methodName);
		}
	}

}
