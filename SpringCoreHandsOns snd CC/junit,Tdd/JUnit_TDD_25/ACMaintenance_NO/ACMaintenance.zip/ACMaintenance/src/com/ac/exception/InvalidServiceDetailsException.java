package com.ac.exception;
public class InvalidServiceDetailsException extends Exception {
	public InvalidServiceDetailsException(String message) {
		super(message);
	}
}
