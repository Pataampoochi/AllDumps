package com.ac.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.ac.exception.InvalidServiceDetailsException;
import com.ac.model.ServiceDetails;
import com.ac.util.ServiceCenter;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceCenterTest {
	private static List<ServiceDetails> ServiceDetailsList = new ArrayList<>();
	private static ServiceCenter psObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		//Fill code here
		//Create few  objects for ServiceDetails class and add to a list.
		//Set that list to the serviceDetailsList using the setServiceDetailsList method in ServiceCenter class 
		psObj = new ServiceCenter();
		
	}

	// Test validateAcType method when the value is Split
	public void test11ValidateAcTypeWhenSplit(){
		//Fill code here
	}
	
	// Test validateAcType method when the value is Window
	public void test12ValidateAcTypeWhenWindow(){
		//Fill code here
	}
	
	// Test validateAcType method when the value is Centralized
	public void test13ValidateAcTypeWhenCentralized(){
		//Fill code here
	}
	
	// Test validateAcType method when the value is Portable
	public void test14ValidateAcTypeWhenPortable(){
		//Fill code here
	}
	
	// Test validateAcType method when the value is Invalid
	public void test15ValidateAcTypeWhenInvalid(){
		//Fill code here
	}
	
	// Test viewServiceDetailsByCode method when the value is valid
	public void test16ViewServiceDetailsByCodeWhenValid(){
		//Fill code here
	}
	
	// Test viewServiceDetailsByCode method when the value is Invalid
	public void test17ViewServiceDetailsByCodeWhenInvalid(){
		//Fill code here
	}
	
	// Test viewServiceDetailsByServiceType method
	public void test18ViewServiceDetailsByServiceType(){
		//Fill code here
	}
	
	// Test viewServiceDetailsAppointmentDateWise method
	public void test19ViewServiceDetailsAppointmentDateWise(){
		//Fill code here
	}
	
	// Test countTotalCountForEachAcType method
	public void test20CountTotalCountForEachAcType(){
		//Fill code here
	}
	
	// Test viewServiceDetailsByServiceType method for an empty list
	public void test21ViewServiceDetailsByServiceTypeForEmptyList(){
		//Fill code here
	}
	
	// Test viewServiceDetailsAppointmentDateWise method for an empty list
	public void test22ViewServiceDetailsAppointmentDateWiseForEmptyList(){
		//Fill code here
	}
	
	// Test countTotalCountForEachAcType method for an empty list
	public void test23CountTotalCountForEachAcTypeForEmptyList(){
		//Fill code here
	}
}
