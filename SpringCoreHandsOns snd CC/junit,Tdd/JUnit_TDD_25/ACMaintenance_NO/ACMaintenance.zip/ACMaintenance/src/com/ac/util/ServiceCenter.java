package com.ac.util;

import java.util.*;

import com.ac.exception.InvalidServiceDetailsException;
import com.ac.model.*;

public class ServiceCenter {
	private List<ServiceDetails> serviceDetailsList=new ArrayList<ServiceDetails>();
	
	public List<ServiceDetails> getServiceDetailsList() {
		return serviceDetailsList;
	}

	public void setServiceDetailsList(List<ServiceDetails> ServiceDetailsList) {
		this.serviceDetailsList = ServiceDetailsList;
	}

	public boolean validateAcType(String acType) throws InvalidServiceDetailsException{
		boolean flag=false;
		if(acType.equalsIgnoreCase("Split") || acType.equalsIgnoreCase("Window") || acType.equalsIgnoreCase("Centralized") || acType.equalsIgnoreCase("Portable")){
			flag=true;
		}
		else {
			throw new InvalidServiceDetailsException("ac type is invalid");
		}
		return flag;
	}
	public ServiceDetails viewServiceDetailsByCode(String serviceCode) throws InvalidServiceDetailsException{
		if(serviceDetailsList.isEmpty()){
			throw new InvalidServiceDetailsException("List is empty");
		}
		else{
			for(ServiceDetails num:serviceDetailsList){
				if(num.getServiceCode().equalsIgnoreCase(serviceCode))
					return num;
			}
			throw new InvalidServiceDetailsException("Service Code is Invalid");
		}
		
	}
	public List<ServiceDetails> viewServiceDetailsByServiceType(String serviceType) throws InvalidServiceDetailsException{
		if(serviceDetailsList.isEmpty()){
			throw new InvalidServiceDetailsException("List is empty");
		}
		else{
			List<ServiceDetails> result=new ArrayList<ServiceDetails>();
			for(ServiceDetails num:serviceDetailsList){
				if(num.getServiceType().equalsIgnoreCase(serviceType))
					result.add(num);
			}
			return result;
		}
	}
	public Map<Date,List<ServiceDetails>> viewServiceDetailsAppointmentDateWise() throws InvalidServiceDetailsException{
		if(serviceDetailsList.isEmpty()){
			throw new InvalidServiceDetailsException("List is empty");
		}
		else{
			Map<Date,List<ServiceDetails>> result=new HashMap<Date,List<ServiceDetails>>();
			for(ServiceDetails num:serviceDetailsList){
				if(!result.containsKey(num.getAppointmentDate())){
					result.put(num.getAppointmentDate(),new ArrayList<ServiceDetails>());
				}
				List<ServiceDetails> temp=result.get(num.getAppointmentDate());
				temp.add(num);
				result.put(num.getAppointmentDate(), temp);	
			}
			return result;
		}
	}
	public Map<String,Integer> countTotalCountForEachAcType() throws InvalidServiceDetailsException{
		if(serviceDetailsList.isEmpty()){
			throw new InvalidServiceDetailsException("List is empty");
		}
		else{
			Map<String,Integer> result=new HashMap<String,Integer>();
			int splitCount=0;
			int windowCount=0;
			int centralizedCount=0;
			int portableCount=0;
			for(ServiceDetails num:serviceDetailsList){
				if(num.getAcType().equalsIgnoreCase("Split")){	
					splitCount++;
				}
				else if(num.getAcType().equalsIgnoreCase("Window")){	
					windowCount++;
				}
				else if(num.getAcType().equalsIgnoreCase("Centralized")){	
					centralizedCount++;
				}
				else if(num.getAcType().equalsIgnoreCase("Portable")){
					portableCount++;
				}
			}
			result.put("Split", splitCount);
			result.put("Window", windowCount);
			result.put("Centralized", centralizedCount);
			result.put("Portable", portableCount);
			return result;
		}
	}
}
