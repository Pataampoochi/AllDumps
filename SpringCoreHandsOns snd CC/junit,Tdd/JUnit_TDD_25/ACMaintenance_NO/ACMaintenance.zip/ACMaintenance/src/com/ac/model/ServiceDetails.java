package com.ac.model;

import java.util.Date;

public class ServiceDetails {
	private String serviceCode;
	private String acType;
	private String serviceType;
	private String customerName;
	private String phoneNumber;
	private Date appointmentDate;
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getAcType() {
		return acType;
	}
	public void setAcType(String acType) {
		this.acType = acType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public ServiceDetails(String serviceCode, String acType, String serviceType, String customerName,String phoneNumber, Date appointmentDate) {
		super();
		this.serviceCode = serviceCode;
		this.acType = acType;
		this.serviceType = serviceType;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.appointmentDate = appointmentDate;
	}
	public ServiceDetails() {
		super();
	}
}
