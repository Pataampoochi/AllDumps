package com.mobile.model;


public class Mobile {
	private String IMEINumber;
	private String mobileType;
	private String brand;
	private String model;
	private double mobilePrice;


	public Mobile(){
		
	}


	public Mobile(String IMEINumber, String mobileType, String brand, String model, double mobilePrice) {
		super();
		this.IMEINumber = IMEINumber;
		this.mobileType = mobileType;
		this.brand = brand;
		this.model = model;
		this.mobilePrice = mobilePrice;
	}

	public String getIMEINumber() {
		return IMEINumber;
	}
	public void setIMEINumber(String iMEINumber) {
		IMEINumber = iMEINumber;
	}

	public String getMobileType() {
		return mobileType;
	}
	public void setMobileType(String mobileType) {
		this.mobileType = mobileType;
	}

	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}

	public double getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	
}
