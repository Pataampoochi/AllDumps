package com.mobile.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.mobile.model.Mobile;
import com.mobile.util.MobileStore;
import com.mobile.exception.InvalidMobileException;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MobileStoreTest {
	
	private static List<Mobile> mobileList = new ArrayList<Mobile>();
	private static MobileStore mobileStoreObj;

	
	@BeforeClass
	public static void setUp() throws Exception {
		
		mobileStoreObj = new MobileStore();
		
		//Create few  objects for Mobile class and add to mobileList.
		//Use that list to test all the methods in MobileTest class that requires a list of Mobile 
		
	}
		
	//Test the validateMobileType method when the value is SmartPhone
	public void test11ValidateMobileTypeWhenSmartPhone(){
			
		//fill code	
	
	}
	
	//Test the validateMobileType method when the value is Basic
	public void test12ValidateMobileTypeWhenBasic() {
		
		//fill code	
	
	}
	
	//Test the validateMobileType method when the value is Invalid
	public void test13ValidateMobileTypeWhenInvalid() {
		
		//fill code	
	
	}
	
	//Test the viewMobile method for a valid IMEINumber
	public void test14ViewMobileForValidIMEINumber() {
		
		//fill code	
	
	}
	
	//Test the viewMobile method for invalid IMEINumber
	public void test15ViewMobileForInvalidIMEINumber() {
		
		//fill code	
	
	}
	
	//Test the viewMobilesByBrand method 	
	public void test16ViewMobilesByBrand() {
		
		//fill code	
	
	}
	
	//Test the viewMobilesByBrand method for empty list
	public void test17ViewMobilesByBrandForEmptyList() {
		
		//fill code	
	
	}
	
	//Test the viewMobilesBrandWise method 
	public void test18ViewMobilesBrandWise() {
		
		//fill code	
	
	}
		
	//Test the viewMobilesBrandWise method for empty list
	public void test19ViewMobilesBrandWiseForEmptyList() {
		
		//fill code	
	
	}
	
	//Test the countTotalModelsForEachBrand method
	public void test20CountTotalModelsForEachBrand(){
		
		//fill code	
	
	}
	
	//Test the countTotalModelsForEachBrand method for empty list
	public void test21CountTotalModelsForEachBrandForEmptyList() {
		
		//fill code	
	
	}
}
