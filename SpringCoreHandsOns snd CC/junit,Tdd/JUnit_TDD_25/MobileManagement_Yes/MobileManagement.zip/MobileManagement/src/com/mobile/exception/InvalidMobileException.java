package com.mobile.exception;

public class InvalidMobileException extends Exception {

	public InvalidMobileException(String message) {
		super(message);
	}
}

