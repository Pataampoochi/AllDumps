package com.movie.exception;
public class InvalidMovieDetailsException extends Exception {
	public InvalidMovieDetailsException(String message) {
		super(message);
	}
}
