package com.movie.model;

import java.util.Date;

public class MovieDetails {
	private String movieCode;
	private String movieName;
	private String actorName;
	private String directorName;
	private String genre;
	private int yearOfRelease;
	public String getMovieCode() {
		return movieCode;
	}
	public void setMovieCode(String movieCode) {
		this.movieCode = movieCode;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getActorName() {
		return actorName;
	}
	public void setActorName(String actorName) {
		this.actorName = actorName;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getYearOfRelease() {
		return yearOfRelease;
	}
	public void setYearOfRelease(int yearOfRelease) {
		this.yearOfRelease = yearOfRelease;
	}
	public MovieDetails(String movieCode, String movieName, String actorName, String directorName, String genre, int yearOfRelease) {
		super();
		this.movieCode = movieCode;
		this.movieName = movieName;
		this.actorName = actorName;
		this.directorName = directorName;
		this.genre = genre;
		this.yearOfRelease = yearOfRelease;
	}
	public MovieDetails() {
		super();
	}
}
