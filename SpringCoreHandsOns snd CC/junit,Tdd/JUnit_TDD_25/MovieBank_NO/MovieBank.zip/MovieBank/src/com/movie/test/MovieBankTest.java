package com.movie.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.movie.exception.InvalidMovieDetailsException;
import com.movie.model.MovieDetails;
import com.movie.util.MovieBank;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MovieBankTest {
	private static List<MovieDetails> movieDetailsList = new ArrayList<>();
	private static MovieBank psObj;
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		// Fill the code	
		//Create few  objects for MovieDetails class and add to a list.
		//Set that list to the movieDetailsList
		psObj = new MovieBank();
		
	}

    //Test validateGenre method when the value is Historical
	public void test11ValidateGenreWhenHistorical(){
		// Fill the code
	}
	
	//Test validateGenre method when the value is CrimeThriller
	public void test12ValidateGenreWhenCrimeThriller(){
		// Fill the code
	}
	
	//Test validateGenre method when the value is Comedy
	public void test13ValidateGenreWhenComedy(){
		// Fill the code
	}
	
	//Test validateGenre method when the value is Action
	public void test14ValidateGenreWhenAction(){
		// Fill the code
	}
	
	//Test validateGenre method when the value is invalid
	public void test15ValidateGenreWhenInvalid(){
		// Fill the code
	}
	
	//Test viewMovieDetailsByMovieName method when the value is valid
	public void test16ViewMovieDetailsByMovieNameWhenValid(){
		// Fill the code
	}
	
	//Test viewMovieDetailsByMovieName method when the value is invalid
	public void test17ViewMovieDetailsByMovieNameWhenInvalid(){
		// Fill the code
	}
	
	//Test viewMovieDetailsByDirectorName method
	public void test18ViewMovieDetailsByDirectorName(){
		// Fill the code
	}
	
	//Test viewMovieDetailsReleasedYearWise method
	public void test19ViewMovieDetailsReleasedYearWise(){
		// Fill the code
	}
	
	//Test countTotalMovieForEachGenre method
	public void test20CountTotalMovieForEachGenre(){
		// Fill the code
	}
	
	//Test viewMovieDetailsByDirectorName method for an empty list
	public void test21ViewMovieDetailsByDirectorNameForEmptyList(){
		// Fill the code
	}
	
	//Test viewMovieDetailsReleasedYearWise method for an empty list
	public void test22ViewMovieDetailsReleasedYearWiseForEmptyList(){
		// Fill the code
	}
	
	//Test countTotalMovieForEachGenre method for an empty list
	public void test23CountTotalMovieForEachGenreForEmptyList(){
		// Fill the code
	}
}
