package com.movie.util;

import java.util.*;

import com.movie.exception.InvalidMovieDetailsException;
import com.movie.model.*;

public class MovieBank {
	private List<MovieDetails> movieDetailsList=new ArrayList<MovieDetails>();
	
	public List<MovieDetails> getMovieDetailsList() {
		return movieDetailsList;
	}

	public void setMovieDetailsList(List<MovieDetails> movieDetailsList) {
		this.movieDetailsList = movieDetailsList;
	}

	public boolean validateGenre(String genre) throws InvalidMovieDetailsException{
		boolean flag=false;
		if(genre.equalsIgnoreCase("Historical") || genre.equalsIgnoreCase("Crime-Thriller") || genre.equalsIgnoreCase("Comedy") || genre.equalsIgnoreCase("Action")){
			flag=true;
		}
		else {
			throw new InvalidMovieDetailsException("genre is invalid");
		}
		return flag;
	}
	public MovieDetails viewMovieDetailsByMovieName(String movieName) throws InvalidMovieDetailsException{
		if(movieDetailsList.isEmpty()){
			throw new InvalidMovieDetailsException("List is empty");
		}
		else{
			for(MovieDetails num:movieDetailsList){
				if(num.getMovieName().equalsIgnoreCase(movieName))
					return num;
			}
			throw new InvalidMovieDetailsException("Movie Name is Invalid");
		}
		
	}
	public List<MovieDetails> viewMovieDetailsByDirectorName(String directorName) throws InvalidMovieDetailsException{
		if(movieDetailsList.isEmpty()){
			throw new InvalidMovieDetailsException("List is empty");
		}
		else{
			List<MovieDetails> result=new ArrayList<MovieDetails>();
			for(MovieDetails num:movieDetailsList){
				if(num.getDirectorName().equalsIgnoreCase(directorName))
					result.add(num);
			}
			return result;
		}
	}
	public Map<Integer,List<MovieDetails>> viewMovieDetailsReleasedYearWise() throws InvalidMovieDetailsException{
		if(movieDetailsList.isEmpty()){
			throw new InvalidMovieDetailsException("List is empty");
		}
		else{
			Map<Integer,List<MovieDetails>> result=new HashMap<Integer,List<MovieDetails>>();
			for(MovieDetails num:movieDetailsList){
				if(!result.containsKey(num.getYearOfRelease())){
					result.put(num.getYearOfRelease(),new ArrayList<MovieDetails>());
				}
				List<MovieDetails> temp=result.get(num.getYearOfRelease());
				temp.add(num);
				result.put(num.getYearOfRelease(), temp);	
			}
			return result;
		}
	}
	public Map<String,Integer> countTotalMovieForEachGenre() throws InvalidMovieDetailsException{
		if(movieDetailsList.isEmpty()){
			throw new InvalidMovieDetailsException("List is empty");
		}
		else{
			Map<String,Integer> result=new HashMap<String,Integer>();
			int hCount=0;
			int ctCount=0;
			int comedyCount=0;
			int actionCount=0;
			for(MovieDetails num:movieDetailsList){
				if(num.getGenre().equalsIgnoreCase("Historical")){	
					hCount++;
				}
				else if(num.getGenre().equalsIgnoreCase("Crime-Thriller")){	
					ctCount++;
				}
				else if(num.getGenre().equalsIgnoreCase("Comedy")){	
					comedyCount++;
				}
				else if(num.getGenre().equalsIgnoreCase("Action")){
					actionCount++;
				}
			}
			result.put("Historical", hCount);
			result.put("Crime-Thriller", ctCount);
			result.put("Comedy", comedyCount);
			result.put("Action", actionCount);
			return result;
		}
	}
}
