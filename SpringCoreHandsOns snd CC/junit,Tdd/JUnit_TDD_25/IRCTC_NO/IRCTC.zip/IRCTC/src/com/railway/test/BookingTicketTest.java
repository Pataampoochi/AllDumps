package com.railway.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.railway.exception.InvalidTicketException;
import com.railway.model.RailwayTicket;
import com.railway.util.BookingTicket;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BookingTicketTest {
	
	private static List<RailwayTicket> ticketList = new ArrayList<RailwayTicket>();
	private static BookingTicket bookingObj =new BookingTicket();
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		// Fill the code

	}
		
	// Test validateTicketId method with a valid ticket Id
	public void test11ValidateTicketIdForValidTicketId() {
		// Fill the code
	}
	
	// Test validateTicketId method with an invalid ticket Id with more letters than specified
	public void test12ValidateTicketIdForInvalidTicketIdWithMoreLetters() {
		// Fill the code
	}
	
	// Test validateTicketId method with an invalid ticket Id with less letters than specified
	public void test13ValidateTicketIdForInvalidTicketIdWithLessLetters() {
		// Fill the code
		
	}
	
	// Test validateTicketId method with an invalid ticket Id with more digits than specified
	public void test14ValidateTicketIdForInvalidTicketIdWithMoreDigits() {
		// Fill the code
	}
	
	// Test validateTicketId method with an invalid ticket Id with less digits than specified
	public void test15ValidateTicketIdForInvalidTicketIdWithLessDigits() {
		// Fill the code
	}
	
	// Test viewTicketDetails method with a valid ticket Id
	public void test16ViewTicketDetailsByValidTicketId() {
		// Fill the code
	}
	
	// Test viewTicketDetails method with an invalid ticket Id
	public void test17ViewTicketDetailsByInvalidTicketId() {
		// Fill the code
	}
	
	// Test viewTicketByTrainId method
	public void test18ViewTicketByCoachId() throws ParseException {
		// Fill the code
	}
	
	// Test viewTicketByTrainId method for an empty list
	public void test19ViewTicketByCoachIdForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test countTicketsByTrainName method
	public void test20CountTicketsByTrainName() throws ParseException {
		// Fill the code
	}

	// Test countTicketsByTrainName method for an empty list
	public void test21CountTicketsByTrainNameForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test viewPassengersBySeatType method
	public void test22ViewPassengersBySeatType() throws ParseException {
		// Fill the code
	}
	
	// Test viewPassengersBySeatType method for an empty list
	public void test23ViewPassengersBySeatTypeForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfDeparture method
	public void test24CalculateAmountByDateOfDeparture() throws ParseException {
		// Fill the code
	}

	// Test calculateAmountByDateOfDeparture method for an empty list
	public void test25CalculateAmountByDateOfDepartureForEmptyList() throws ParseException {
		// Fill the code
	}

}
