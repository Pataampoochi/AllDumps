package com.railway.model;

import java.util.Date;

public class RailwayTicket {
	
	private String ticketId;
	private String coachId;
	private String trainName;
	private Date dateOfDeparture;
	private String seatType;
	private double amount;
	public RailwayTicket() {
	}
	public RailwayTicket(String ticketId, String coachId, String trainName, Date dateOfDeparture, String seatType,
			double amount) {
		super();
		this.ticketId = ticketId;
		this.coachId = coachId;
		this.trainName = trainName;
		this.dateOfDeparture = dateOfDeparture;
		this.seatType = seatType;
		this.amount = amount;
	}
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getCoachId() {
		return coachId;
	}
	public void setCoachId(String coachId) {
		this.coachId = coachId;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public Date getDateOfDeparture() {
		return dateOfDeparture;
	}
	public void setDateOfDeparture(Date dateOfDeparture) {
		this.dateOfDeparture = dateOfDeparture;
	}
	public String getSeatType() {
		return seatType;
	}
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "RailwayTicket [ticketId=" + ticketId + ", coachId=" + coachId + ", trainName=" + trainName
				+ ", dateOfDeparture=" + dateOfDeparture + ", seatType=" + seatType + ", amount=" + amount + "]";
	}


}
