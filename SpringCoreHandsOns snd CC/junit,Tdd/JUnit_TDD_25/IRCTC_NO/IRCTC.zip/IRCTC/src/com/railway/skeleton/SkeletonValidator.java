package com.railway.skeleton;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author t-aarti3 This class is used to verify if the Code Skeleton is intact
 *         and not modified by participants thereby ensuring smooth auto
 *         evaluation
 */

public class SkeletonValidator {
	public SkeletonValidator() {
		validateClassName("com.railway.util.BookingTicket");
		validateClassName("com.railway.model.RailwayTicket");
		validateClassName("com.railway.exception.InvalidTicketException");
		validateClassName("com.railway.test.BookingTicketTest");

		validateMethodSignature(
				"validateTicketId:boolean,viewTicketDetailsByTicketId:com.railway.model.RailwayTicket,viewTicketByCoachId:java.util.List,countTicketsByTrainName:int,viewPassengersBySeatType:java.util.Map,calculateAmountByDateOfDeparture:double",
				"com.railway.util.BookingTicket");
		validateMethodSignature(
				"test11ValidateTicketIdForValidTicketId:void,test12ValidateTicketIdForInvalidTicketIdWithMoreLetters:void,test13ValidateTicketIdForInvalidTicketIdWithLessLetters:void,test14ValidateTicketIdForInvalidTicketIdWithMoreDigits:void,test15ValidateTicketIdForInvalidTicketIdWithLessDigits:void,test16ViewTicketDetailsByValidTicketId:void,test17ViewTicketDetailsByInvalidTicketId:void,"
						+ "test18ViewTicketByCoachId:void,test19ViewTicketByCoachIdForEmptyList:void,test20CountTicketsByTrainName:void,test21CountTicketsByTrainNameForEmptyList:void,test22ViewPassengersBySeatType:void,test23ViewPassengersBySeatTypeForEmptyList:void,test24CalculateAmountByDateOfDeparture:void,test25CalculateAmountByDateOfDepartureForEmptyList:void",
				"com.railway.test.BookingTicketTest");

	}

	private static final Logger LOG = Logger.getLogger("SkeletonValidator");

	protected final boolean validateClassName(String className) {

		boolean iscorrect = false;
		try {
			Class.forName(className);
			iscorrect = true;
			LOG.info("Class Name " + className + " is correct");

		} catch (ClassNotFoundException e) {
			LOG.log(Level.SEVERE, "You have changed either the " + "class name/package. Use the correct package "
					+ "and class name as provided in the skeleton");

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					"There is an error in validating the " + "Class Name. Please manually verify that the "
							+ "Class name is same as skeleton before uploading");
		}
		return iscorrect;
	}

	protected final void validateMethodSignature(String methodWithExcptn, String className) {
		Class cls = null;
		try {

			String[] actualmethods = methodWithExcptn.split(",");
			boolean errorFlag = false;
			String[] methodSignature;
			String methodName = null;
			String returnType = null;

			for (String singleMethod : actualmethods) {
				boolean foundMethod = false;
				methodSignature = singleMethod.split(":");

				methodName = methodSignature[0];
				returnType = methodSignature[1];
				cls = Class.forName(className);
				Method[] methods = cls.getMethods();
				for (Method findMethod : methods) {
					if (methodName.equals(findMethod.getName())) {
						foundMethod = true;
						if (!(findMethod.getReturnType().getName().equals(returnType))) {
							errorFlag = true;
							LOG.log(Level.SEVERE, " You have changed the " + "return type in '" + methodName
									+ "' method. Please stick to the " + "skeleton provided");

						} else {
							LOG.info("Method signature of " + methodName + " is valid");
						}

					}
				}
				if (!foundMethod) {
					errorFlag = true;
					LOG.log(Level.SEVERE, " Unable to find the given public method " + methodName
							+ ". Do not change the " + "given public method name. " + "Verify it with the skeleton");
				}

			}
			if (!errorFlag) {
				LOG.info("Method signature is valid");
			}

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					" There is an error in validating the " + "method structure. Please manually verify that the "
							+ "Method signature is same as the skeleton before uploading");
		}
	}

}
