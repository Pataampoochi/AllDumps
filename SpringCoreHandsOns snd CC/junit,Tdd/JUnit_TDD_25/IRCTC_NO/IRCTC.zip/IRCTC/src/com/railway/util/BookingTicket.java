package com.railway.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.railway.exception.InvalidTicketException;
import com.railway.model.RailwayTicket;



public class BookingTicket {
	
	public boolean validateTicketId(String ticketId) throws InvalidTicketException {
		boolean status = false;
		char[] ch=ticketId.toCharArray();
		int count=0;
		for(int i=0;i<4;i++){
			if(Character.isAlphabetic(ch[i]))
				count++;
		}
		for(int i=4;i<8;i++){
			if(Character.isDigit(ch[i]))
				count++;
		}
		if (count==8 && ticketId.length()==8) {
			status = true;
		} 
		else {
			status = false;
			throw new InvalidTicketException("Check for valid Ticket Id");
		}
		return status;
	}

	public RailwayTicket viewTicketDetailsByTicketId(List<RailwayTicket> ticketList, String ticketId) throws InvalidTicketException{

		if(ticketList.size()==0) {
			throw new InvalidTicketException("Ticket list is empty");
		}
		else{
			for(RailwayTicket p : ticketList){
				if(p.getTicketId().equals(ticketId)){
					return p;
				}
			}
			throw new InvalidTicketException("Ticket ID is invalid");
		}
	}

	public List<RailwayTicket> viewTicketByCoachId(List<RailwayTicket> ticketList, String coachId) throws InvalidTicketException {

		List<RailwayTicket> details=new ArrayList<RailwayTicket>();
		System.out.println(ticketList.size());
		if (ticketList.size() > 0) {
			for (RailwayTicket i: ticketList) {
				try {
					if (validateTicketId(i.getTicketId())) {
						if (i.getCoachId().equals(coachId)) {
							details.add(i);
						}
					}
				} catch (InvalidTicketException e) {
					
				}
			}
		} else {
			throw new InvalidTicketException("Ticket list is empty");
		}
		System.out.println(details.size());
		return details;
	}


	public int countTicketsByTrainName(List<RailwayTicket> ticketList, String trainName)
			throws InvalidTicketException, ParseException {
		int count=0;
		if (ticketList.size() == 0) {
			throw new InvalidTicketException("Ticket list is empty");
		}
		else{
			for (RailwayTicket i:ticketList) {
				if (i.getTrainName().equals(trainName)) {
					count++;;
				}
			}
		}
		return count; 
	}


	public Map<String, List<RailwayTicket>> viewPassengersBySeatType(List<RailwayTicket> ticketList)throws InvalidTicketException {
		Map<String,List<RailwayTicket>> result = new LinkedHashMap<>();
		if (ticketList.size() > 0) {

			for(RailwayTicket t : ticketList){
				if(!result.containsKey(t.getSeatType())){
					result.put(t.getSeatType(),new ArrayList<RailwayTicket>());
				}
				List<RailwayTicket> temp=result.get(t.getSeatType());
				temp.add(t);
				result.put(t.getSeatType(), temp);			
			}

		}else {
			throw new InvalidTicketException("Ticket list is empty");
		}
		return result;
	}

	public double calculateAmountByDateOfDeparture(List<RailwayTicket> ticketList, Date dateOfDeparture) throws InvalidTicketException {
		double amount=0;
		if (ticketList.size() > 0) {

			for (RailwayTicket i: ticketList) {
				if(i.getDateOfDeparture().compareTo(dateOfDeparture)==0)
					amount=amount+i.getAmount();

			} }else {
				throw new InvalidTicketException("Ticket list is empty");
			}
		return amount;
	}

}
