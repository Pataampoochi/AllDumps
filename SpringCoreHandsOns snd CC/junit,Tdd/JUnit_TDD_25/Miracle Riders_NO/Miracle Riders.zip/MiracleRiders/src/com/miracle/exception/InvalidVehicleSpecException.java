package com.miracle.exception;

public class InvalidVehicleSpecException extends Exception{

	public InvalidVehicleSpecException(String msg) {
		super(msg);
	}
}
