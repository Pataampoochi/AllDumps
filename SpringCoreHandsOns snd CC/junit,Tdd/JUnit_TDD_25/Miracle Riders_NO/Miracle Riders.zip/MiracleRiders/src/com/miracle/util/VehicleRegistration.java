package com.miracle.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.miracle.exception.InvalidVehicleSpecException;
import com.miracle.model.VehicleSpecifications;

public class VehicleRegistration {
	
	public boolean validateVehicleCode(String vehicleCode) throws InvalidVehicleSpecException {
		boolean status = false;
		int count =0;
		char[] ch=vehicleCode.toCharArray();
		for(int i=0;i<=3;i++){
			if(Character.isAlphabetic(ch[i]))
				count++;
		}
		for(int i=4;i<=7;i++){
			if(Character.isDigit(ch[i]))
				count++;
		}
		if (count==8 && ch[8]=='M' && ch[9]=='M' && ch.length==10) {
			status = true;
		} else {
			status = false;
			throw new InvalidVehicleSpecException("Valid vehicle code should be given");
		}

		return status;
	}

	public VehicleSpecifications viewVehicleByModelNumber(List<VehicleSpecifications> vehicleList, String modelNumber) throws InvalidVehicleSpecException{
		
		if(vehicleList.size()==0){
			throw new InvalidVehicleSpecException("Vehicle list is empty");
		}
		else{
			for(VehicleSpecifications p : vehicleList){
				if(p.getModelNumber().equals(modelNumber)){
					return p;
				}
			}
			throw new InvalidVehicleSpecException("Model number is invalid");}
	}

	public List<VehicleSpecifications> viewVehicleByRegistrationDate(List<VehicleSpecifications> vehicleList, Date date) throws InvalidVehicleSpecException {
		
		List<VehicleSpecifications> vehicleDetails=new ArrayList<VehicleSpecifications>();
		System.out.println(vehicleList.size());
		if (vehicleList.size() > 0) {
			for (VehicleSpecifications i: vehicleList) {
				try {
					if (validateVehicleCode(i.getVehicleCode())) {
						if (i.getRegistrationDate().compareTo(date)==0) {
							vehicleDetails.add(i);
						}
					}
				} catch (InvalidVehicleSpecException e) {
					
				}
			}
		} else {
			throw new InvalidVehicleSpecException("Vehicle list is empty");
		}
		return vehicleDetails;
	}


	public double calculateInsuranceAmountByInsuranceDate(List<VehicleSpecifications> vehicleList, Date date)
			throws InvalidVehicleSpecException, ParseException {
		double amount=0;
		if (vehicleList.size() == 0) {
			throw new InvalidVehicleSpecException("Vehicle list is empty");
		}
		else{
			for (VehicleSpecifications i: vehicleList) {
				if(i.getInsuranceDate().compareTo(date)==0)
					amount=amount+i.getInsuranceAmount();
			} 
		}
		return amount;
	}

	
	public Map<Date, List<VehicleSpecifications>> viewVehiclesByDeliveryDate(List<VehicleSpecifications> vehicleList)throws InvalidVehicleSpecException {
		Map<Date,List<VehicleSpecifications>> result = new LinkedHashMap<>();
		if (vehicleList.size() > 0) {
			
			for(VehicleSpecifications t : vehicleList){
				if(!result.containsKey(t.getDateOfDelievery())){
					result.put(t.getDateOfDelievery(),new ArrayList<VehicleSpecifications>());
				}
				List<VehicleSpecifications> temp=result.get(t.getDateOfDelievery());
				temp.add(t);
				result.put(t.getDateOfDelievery(), temp);			
			}
			
			}else {
			throw new InvalidVehicleSpecException("Vehicle list is empty");
		}
		return result;
	}

	public int countOfVehiclesByModelNumber(List<VehicleSpecifications> vehicleList, String modelNumber) throws InvalidVehicleSpecException {
		int count=0;
		if(vehicleList.size()==0){
		throw new InvalidVehicleSpecException("Vehicle list is empty");
	    }
	    else{
		for(VehicleSpecifications p : vehicleList){
			if(p.getModelNumber().equals(modelNumber)){
				count++;
			}
		}
		return count;
		
	}
	}

}
