package com.miracle.model;

import java.util.Date;

public class VehicleSpecifications {
	
	private String vehicleCode;
	private String modelNumber;
	private String modelColour;
	private Date registrationDate;
	private Date dateOfDelievery;
	private double insuranceAmount;
	private Date insuranceDate;
	private double vehiclePrice;
	public VehicleSpecifications() {
		
	}
	public VehicleSpecifications(String vehicleCode, String modelNumber, String modelColour, Date registrationDate,
			Date dateOfDelievery, double insuranceAmount, Date insuranceDate, double vehiclePrice) {
		super();
		this.vehicleCode = vehicleCode;
		this.modelNumber = modelNumber;
		this.modelColour = modelColour;
		this.registrationDate = registrationDate;
		this.dateOfDelievery = dateOfDelievery;
		this.insuranceAmount = insuranceAmount;
		this.insuranceDate = insuranceDate;
		this.vehiclePrice = vehiclePrice;
	}
	public String getVehicleCode() {
		return vehicleCode;
	}
	public void setVehicleCode(String vehicleCode) {
		this.vehicleCode = vehicleCode;
	}
	public String getModelNumber() {
		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}
	public String getModelColour() {
		return modelColour;
	}
	public void setModelColour(String modelColour) {
		this.modelColour = modelColour;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public Date getDateOfDelievery() {
		return dateOfDelievery;
	}
	public void setDateOfDelievery(Date dateOfDelievery) {
		this.dateOfDelievery = dateOfDelievery;
	}
	public double getInsuranceAmount() {
		return insuranceAmount;
	}
	public void setInsuranceAmount(double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}
	public Date getInsuranceDate() {
		return insuranceDate;
	}
	public void setInsuranceDate(Date insuranceDate) {
		this.insuranceDate = insuranceDate;
	}
	public double getVehiclePrice() {
		return vehiclePrice;
	}
	public void setVehiclePrice(double vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}
	@Override
	public String toString() {
		return "VehicleRegistration [vehicleCode=" + vehicleCode + ", modelNumber=" + modelNumber + ", modelColour="
				+ modelColour + ", registrationDate=" + registrationDate + ", dateOfDelievery=" + dateOfDelievery
				+ ", insuranceAmount=" + insuranceAmount + ", insuranceDate=" + insuranceDate + ", vehiclePrice="
				+ vehiclePrice + "]";
	}

}
