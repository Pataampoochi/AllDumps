package com.miracle.test;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.miracle.exception.InvalidVehicleSpecException;
import com.miracle.model.VehicleSpecifications;
import com.miracle.util.VehicleRegistration;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class VehicleRegistrationTest {

	private static List<VehicleSpecifications> vehicleList = new ArrayList<VehicleSpecifications>();
	private static VehicleRegistration vehicle =new VehicleRegistration();

	@BeforeClass
	public static void setUp() throws Exception {

		// Fill the code	
	}

    // Test validateVehicleCode method with a valid Vehicle Code
	public void test11ValidateVehicleCodeForValidVehicleCode() {
		// Fill the code
	}

	// Test validateVehicleCode method with an invalid Vehicle Code
	public void test12ValidateVehicleCodeForInvalidVehicleCode() {
		// Fill the code
	}

	// Test validateVehicleCode method with an invalid Vehicle Code without the letter M
	public void test13ValidateVehicleCodeForInvalidVehicleCodeWithoutMM() {
		// Fill the code
	}

	// Test validateVehicleCode method with an invalid Vehicle Code with String length greater than 10
	public void test14ValidateVehicleCodeForInvalidVehicleCodeWithLengthGreaterThan10() {
		// Fill the code
	}

	// Test viewVehicleByValidModelNumber method with a valid model number
	public void test15ViewVehicleByValidModelNumber() {
		// Fill the code
	}

	// Test viewVehicleByValidModelNumber method with an invalid model number
	public void test16ViewVehicleByInvalidModelNumber() {
		// Fill the code
	}

	// Test viewVehicleByRegistrationDate method
	public void test17ViewVehicleByRegistrationDate() throws ParseException {
		// Fill the code
	}

	// Test viewVehicleByRegistrationDate method for an empty list
	public void test18ViewVehicleByRegistrationDateForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test calculateInsuranceAmountByInsuranceDate method
	public void test19CalculateInsuranceAmountByInsuranceDate() throws ParseException {
		// Fill the code
	}

	// Test calculateInsuranceAmountByInsuranceDate method for an empty list
	public void test20CalculateInsuranceAmountByInsuranceDateForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test viewVehiclesByDeliveryDate method
	public void test21ViewVehiclesByDeliveryDate() throws ParseException {
		// Fill the code
	}

	// Test viewVehiclesByDeliveryDate method for an empty list
	public void test22ViewVehiclesByDeliveryDateForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test countOfVehiclesByModelNumber method
	public void test23CountOfVehiclesByModelNumber() throws ParseException {
		// Fill the code
	}

	// Test countOfVehiclesByModelNumber method for an empty list
	public void test24CountOfVehiclesByModelNumberForEmptyList() throws ParseException {
		// Fill the code
	}

}
