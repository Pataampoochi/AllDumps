package com.miracle.skeleton;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author t-aarti3 This class is used to verify if the Code Skeleton is intact
 *         and not modified by participants thereby ensuring smooth auto
 *         evaluation
 */

public class SkeletonValidator {
	public SkeletonValidator() {
		validateClassName("com.miracle.util.VehicleRegistration");
		validateClassName("com.miracle.model.VehicleSpecifications");
		validateClassName("com.miracle.exception.InvalidVehicleSpecException");
		validateClassName("com.miracle.test.VehicleRegistrationTest");

		validateMethodSignature(
				"validateVehicleCode:boolean,viewVehicleByModelNumber:com.miracle.model.VehicleSpecifications,viewVehicleByRegistrationDate:java.util.List,calculateInsuranceAmountByInsuranceDate:double,viewVehiclesByDeliveryDate:java.util.Map,countOfVehiclesByModelNumber:int",
				"com.miracle.util.VehicleRegistration");
		validateMethodSignature(
				"test11ValidateVehicleCodeForValidVehicleCode:void,test12ValidateVehicleCodeForInvalidVehicleCode:void,test13ValidateVehicleCodeForInvalidVehicleCodeWithoutMM:void,test14ValidateVehicleCodeForInvalidVehicleCodeWithLengthGreaterThan10:void,test15ViewVehicleByValidModelNumber:void,test16ViewVehicleByInvalidModelNumber:void,test17ViewVehicleByRegistrationDate:void,"
						+ "test18ViewVehicleByRegistrationDateForEmptyList:void,test19CalculateInsuranceAmountByInsuranceDate:void,test20CalculateInsuranceAmountByInsuranceDateForEmptyList:void,test21ViewVehiclesByDeliveryDate:void,test22ViewVehiclesByDeliveryDateForEmptyList:void,test23CountOfVehiclesByModelNumber:void,test24CountOfVehiclesByModelNumberForEmptyList:void",
				"com.miracle.test.VehicleRegistrationTest");

	}

	private static final Logger LOG = Logger.getLogger("SkeletonValidator");

	protected final boolean validateClassName(String className) {

		boolean iscorrect = false;
		try {
			Class.forName(className);
			iscorrect = true;
			LOG.info("Class Name " + className + " is correct");

		} catch (ClassNotFoundException e) {
			LOG.log(Level.SEVERE, "You have changed either the " + "class name/package. Use the correct package "
					+ "and class name as provided in the skeleton");

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					"There is an error in validating the " + "Class Name. Please manually verify that the "
							+ "Class name is same as skeleton before uploading");
		}
		return iscorrect;
	}

	protected final void validateMethodSignature(String methodWithExcptn, String className) {
		Class cls = null;
		try {

			String[] actualmethods = methodWithExcptn.split(",");
			boolean errorFlag = false;
			String[] methodSignature;
			String methodName = null;
			String returnType = null;

			for (String singleMethod : actualmethods) {
				boolean foundMethod = false;
				methodSignature = singleMethod.split(":");

				methodName = methodSignature[0];
				returnType = methodSignature[1];
				cls = Class.forName(className);
				Method[] methods = cls.getMethods();
				for (Method findMethod : methods) {
					if (methodName.equals(findMethod.getName())) {
						foundMethod = true;
						if (!(findMethod.getReturnType().getName().equals(returnType))) {
							errorFlag = true;
							LOG.log(Level.SEVERE, " You have changed the " + "return type in '" + methodName
									+ "' method. Please stick to the " + "skeleton provided");

						} else {
							LOG.info("Method signature of " + methodName + " is valid");
						}

					}
				}
				if (!foundMethod) {
					errorFlag = true;
					LOG.log(Level.SEVERE, " Unable to find the given public method " + methodName
							+ ". Do not change the " + "given public method name. " + "Verify it with the skeleton");
				}

			}
			if (!errorFlag) {
				LOG.info("Method signature is valid");
			}

		} catch (Exception e) {
			LOG.log(Level.SEVERE,
					" There is an error in validating the " + "method structure. Please manually verify that the "
							+ "Method signature is same as the skeleton before uploading");
		}
	}

}
