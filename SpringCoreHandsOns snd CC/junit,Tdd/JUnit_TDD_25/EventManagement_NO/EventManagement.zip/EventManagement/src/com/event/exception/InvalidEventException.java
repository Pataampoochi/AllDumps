package com.event.exception;

public class InvalidEventException extends Exception{
	
	public InvalidEventException(String s) {
		super();
	}

}
