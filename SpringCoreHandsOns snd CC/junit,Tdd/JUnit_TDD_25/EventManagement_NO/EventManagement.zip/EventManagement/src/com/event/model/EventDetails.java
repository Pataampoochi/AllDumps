package com.event.model;

import java.util.Date;

public class EventDetails {
	
	private String eventId;
	private String eventType;
	private Date dateOfRegistration;
	private Date dateOfEvent;
	private long pointOfContact;
	private double payment;
	public EventDetails() {
		
	}
	public EventDetails(String eventId, String eventType, Date dateOfRegistration, Date dateOfEvent,
			long pointOfContact, double payment) {
		super();
		this.eventId = eventId;
		this.eventType = eventType;
		this.dateOfRegistration = dateOfRegistration;
		this.dateOfEvent = dateOfEvent;
		this.pointOfContact = pointOfContact;
		this.payment = payment;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}
	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
	public Date getDateOfEvent() {
		return dateOfEvent;
	}
	public void setDateOfEvent(Date dateOfEvent) {
		this.dateOfEvent = dateOfEvent;
	}
	public long getPointOfContact() {
		return pointOfContact;
	}
	public void setPointOfContact(long pointOfContact) {
		this.pointOfContact = pointOfContact;
	}
	public double getPayment() {
		return payment;
	}
	public void setPayment(double payment) {
		this.payment = payment;
	}
	@Override
	public String toString() {
		return "EventDetails [eventId=" + eventId + ", eventType=" + eventType + ", dateOfRegistration="
				+ dateOfRegistration + ", dateOfEvent=" + dateOfEvent + ", pointOfContact=" + pointOfContact
				+ ", payment=" + payment + "]";
	}
	
	

}
