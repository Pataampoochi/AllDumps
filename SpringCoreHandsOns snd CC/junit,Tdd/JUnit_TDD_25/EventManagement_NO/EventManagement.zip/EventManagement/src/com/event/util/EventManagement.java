package com.event.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.event.exception.InvalidEventException;
import com.event.model.EventDetails;

public class EventManagement {
	
	public boolean validateEventType(String eventType) throws InvalidEventException {
		boolean status = false;
		
		if (eventType.equalsIgnoreCase("Wedding") || eventType.equalsIgnoreCase("Birthday") || eventType.equalsIgnoreCase("Conference") || eventType.equalsIgnoreCase("Product Launch") || eventType.equalsIgnoreCase("Corporate Hospitality")) {
			status = true;
		} else {
			status = false;
			throw new InvalidEventException("Valid event type should be given");
		}

		return status;
	}

	public EventDetails viewEventDetailsByEventId(List<EventDetails> eventList, String eventId) throws InvalidEventException{

		if(eventList.size()==0){
			throw new InvalidEventException("Event list is empty");
		}
		else{
			for(EventDetails p : eventList){
				if(p.getEventId().equalsIgnoreCase(eventId)){
					return p;
				}
			}
			throw new InvalidEventException("Event ID is invalid");}
	}

	public List<EventDetails> viewEventDetailsByEventType(List<EventDetails> eventList, String type) throws InvalidEventException {

		List<EventDetails> eventDetails=new ArrayList<EventDetails>();
		if (eventList.size() == 0) {
			throw new InvalidEventException("Event list is empty");
		}
		else{
			for (EventDetails i: eventList) {
				if (validateEventType(i.getEventType())) {
					if (i.getEventType().equalsIgnoreCase(type)) {
						eventDetails.add(i);
					}
				}
			}
		}
		return eventDetails;
	}


	public int countEventsByDateOfRegistration(List<EventDetails> eventList, Date date)
			throws InvalidEventException, ParseException {
		int count=0;
		if (eventList.size() == 0) {
			throw new InvalidEventException("Event list is empty");
		}
		else{
			for (EventDetails i:eventList) {
				if (i.getDateOfRegistration().compareTo(date)==0) {
					count++;;
				}
			}
		}
		return count; 
	}


	public Map<Date, List<EventDetails>> viewEventsByDateOfEvent (List<EventDetails> eventList)throws InvalidEventException {
		Map<Date,List<EventDetails>> result = new LinkedHashMap<>();
		if (eventList.size() == 0) {
			throw new InvalidEventException("Event list is empty");}
		else{	
			for(EventDetails t : eventList){
				if(!result.containsKey(t.getDateOfEvent())){
					result.put(t.getDateOfEvent(),new ArrayList<EventDetails>());
				}
				List<EventDetails> temp=result.get(t.getDateOfEvent());
				temp.add(t);
				result.put(t.getDateOfEvent(), temp);			
			}

		}
		return result;
	}

	public double calculateAmountByDateOfEvent(List<EventDetails> eventList, Date date) throws InvalidEventException {
		double amount=0;
		if (eventList.size() == 0) {
			throw new InvalidEventException("Event list is empty");
		}
		else{
			for (EventDetails i: eventList) {
				if(i.getDateOfEvent().compareTo(date)==0)
					amount=amount+i.getPayment();
			} 
		}
		return amount;
	}

}
