package com.event.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.event.exception.InvalidEventException;
import com.event.model.EventDetails;
import com.event.util.EventManagement;

public class EventManagementTest {
	
	private static List<EventDetails> eventList = new ArrayList<EventDetails>();
	private static EventManagement eventManagementObj ;
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		// Fill the code
		//Create few  objects for EventDetails class and add to a list.
		//Set that list to the eventList	
		eventManagementObj=new EventManagement();
	}
	
	// Test validateEventType method with Product Launch
	public void test11ValidateEventTypeForProductLaunch() {
		// Fill the code
	}
	
	// Test validateEventType method with Corporate Hospitality
	public void test12ValidateEventTypeForCorporateHospitality() {
		// Fill the code
	}

	// Test validateEventType method with an invalid Event Type
	public void test13ValidateEventTypeForInvalidEventType() {
		// Fill the code
	}

	// Test viewEventDetailsByEventId method when Event Id is Valid
	public void test14ViewEventDetailsByValidEventId() {
		// Fill the code
	}
	
	// Test viewEventDetailsByEventId method when Event Id is Invalid
	public void test15ViewEventDetailsByInvalidEventId() {
		// Fill the code
	}
	
	// Test viewEventDetailsByEventType method
	public void test16ViewEventDetailsByEventType() throws ParseException {
		// Fill the code
	}
	
	// Test viewEventDetailsByEventType method for an empty list
	public void test17ViewEventDetailsByEventTypeForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test countEventsByDateOfRegistration method
	public void test18CountEventsByDateOfRegistration() throws ParseException {
		// Fill the code
	}

	// Test countEventsByDateOfRegistration method for an empty list
	public void test19CountEventsByDateOfRegistrationForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test viewEventsByDateOfEvent method
	public void test20ViewEventsByDateOfEvent() throws ParseException {
		// Fill the code
	}
	
	// Test viewEventsByDateOfEvent method for an empty list
	public void test21ViewEventsByDateOfEventForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfEvent method
	public void test22CalculateAmountByDateOfEvent() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfEvent method for an empty list
	public void test23CalculateAmountByDateOfEventForEmptyList() throws ParseException {
		// Fill the code
	}

}
