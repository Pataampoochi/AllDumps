package com.assessment.model;

public class AssessmentReport {
	private int  rollNo;
	private String studentName;
	private int  totalMarks;
	private int standard;
	private char section;
	private String classTeacherName;
	
	public AssessmentReport() {
		
	}

	public AssessmentReport(int rollNo, String studentName, int totalMarks, int standard, char section,
			String classTeacherName) {
		super();
		this.rollNo = rollNo;
		this.studentName = studentName;
		this.totalMarks = totalMarks;
		this.standard = standard;
		this.section = section;
		this.classTeacherName = classTeacherName;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}
	public int getStandard() {
		return standard;
	}
	public void setStandard(int standard) {
		this.standard = standard;
	}
	public char getSection() {
		return section;
	}
	public void setSection(char section) {
		this.section = section;
	}
	public String getClassTeacherName() {
		return classTeacherName;
	}
	public void setClassTeacherName(String classTeacherName) {
		this.classTeacherName = classTeacherName;
	}
	
}
