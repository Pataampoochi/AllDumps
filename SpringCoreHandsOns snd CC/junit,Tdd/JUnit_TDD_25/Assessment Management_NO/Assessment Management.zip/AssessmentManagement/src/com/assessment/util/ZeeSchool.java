package com.assessment.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.assessment.exception.InvalidAssessmentException;
import com.assessment.model.AssessmentReport;

public class ZeeSchool {

	
	public boolean validateSection (char section) throws InvalidAssessmentException {
		
	if(section=='A' ||section=='a' || section=='B'|| section =='b')
		   return true;
	   else
		   throw new InvalidAssessmentException("Section invalid");
	}
	
	
	public AssessmentReport viewAssessment(List<AssessmentReport> assessmentReportList,int rollNo)  throws InvalidAssessmentException{
		if(assessmentReportList.size()==0){
			throw new InvalidAssessmentException("List is empty");
		}
		else {
			for(AssessmentReport m : assessmentReportList){
				if(m.getRollNo()==rollNo)
					return m;
			}
			throw new InvalidAssessmentException("RollNo  is invalid");	
		}
	}
	
	public List<AssessmentReport> viewAssessmentReportForTheGivenClass (List<AssessmentReport> assessmentReportList ,int standard) throws InvalidAssessmentException{
		
		if(assessmentReportList.size()==0){
			throw new InvalidAssessmentException("List is empty");
		}
		else {
			List<AssessmentReport> result = new ArrayList<>();
			for(AssessmentReport m : assessmentReportList){
				if(m.getStandard()==standard)
					result.add(m);
			}
			return result;	
		}
		
		
	}
	
	
	
	public Map<Integer,List<AssessmentReport>> viewAssessmentReportClassWise(List<AssessmentReport> assessmentReportList) throws InvalidAssessmentException{
		
		if(assessmentReportList.size()==0){
			throw new InvalidAssessmentException("List is empty");
		}
		else {
			Map<Integer,List<AssessmentReport>> result = new LinkedHashMap<>();
			
			for(AssessmentReport m : assessmentReportList){
				if(!result.containsKey(m.getStandard())){
					result.put(m.getStandard(),new ArrayList<AssessmentReport>());
				}
				List<AssessmentReport> temp=result.get(m.getStandard());
				temp.add(m);
				result.put(m.getStandard(), temp);			
			}
			return result;
		}
		
		
	}
	
	
	public  Map<Integer,Integer> countHighPerformersClassWise(List<AssessmentReport> assessmentReportList)throws InvalidAssessmentException{
		
		if(assessmentReportList.size()==0){
			throw new InvalidAssessmentException("List is empty");
		}
		else {
			Map<Integer,Integer> result = new LinkedHashMap<>();
			
			for(AssessmentReport m : assessmentReportList){
				if(m.getTotalMarks()>=450){
					if(!result.containsKey(m.getStandard())){
						result.put(m.getStandard(),1);
					}
					else
					{
						int temp=result.get(m.getStandard());					
						result.put(m.getStandard(), temp+1);
					}
				}
			}
			return result;
		}
	}
		
		
}














