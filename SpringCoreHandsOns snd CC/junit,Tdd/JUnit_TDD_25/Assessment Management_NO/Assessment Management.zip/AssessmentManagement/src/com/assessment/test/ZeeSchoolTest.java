package com.assessment.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;

import com.assessment.model.AssessmentReport;
import com.assessment.util.ZeeSchool;
public class ZeeSchoolTest {
	
	private static List<AssessmentReport> assessmentReportList = new ArrayList<AssessmentReport>();
	private static ZeeSchool zeeSchoolObj;
	
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		zeeSchoolObj = new ZeeSchool();
		
		//Create few  objects for AssessmentReport class and add to assessmentReportList.
		//Use that list to test all the methods in ZeeSchool class that requires a list of AssessmentReport 
		
	}
	
	// Test the validateSection when section is 'A'
	public void test11ValidateSectionWithA(){
		//fill code here
		
	}
	
	
	// Test the validateSection when section is 'B'
	public void test12ValidateSectionWithB(){
		//fill code here
	}

	
	// Test the validateSection when section is invalid	
	public void test13ValidateSectionWhenInvalid() {
		
		//fill code here
	}
	
	
	//Test the viewAssessment for valid roll no
	public void test14ViewAssessmentForValidRollNo() {
		
	    //fill code here	
	}
	
	
	//Test the viewAssessment for invalid roll no
	public void test15ViewAssessmentForInvalidRollNo() {
		 //fill code here
	}
	
	
	
	//Test the viewAssessmentReportForTheGivenClass method
	public void test16ViewAssessmentReportForTheGivenClass() {
		
	 //fill code here
	}
	
	
	
	//Test the viewAssessmentReportForTheGivenClass method when the list is empty
	public void test17ViewAssessmentReportForTheGivenClassForEmptyList() {
		 //fill code here
	}
	
	//Test the viewAssessmentReportClassWise method
	public void test18ViewAssessmentReportClassWise() {
		 //fill code here
	}
	
	
	//Test the viewAssessmentReportClassWise method when the list is empty	
	public void test19ViewAssessmentReportClassWiseForEmptyList() {
		 //fill code here
	}
	
	
	
	//Test the countHighPerformersClassWise method
	public void test20CountHighPerformersClassWise(){
		 //fill code here
		
	}
	
    //Test the countHighPerformersClassWise method when the list is empty
	public void test21CountTotalModelsForEachBrandForEmptyList() {
		
	 //fill code here
	}
	
	
}

	
	
	
	

