package com.assessment.exception;

public class InvalidAssessmentException extends Exception {
	
	public InvalidAssessmentException(String message) {
		super(message);
	}


}
