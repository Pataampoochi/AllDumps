package com.aviva.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.aviva.skeleton.SkeletonValidator;

public class Main {

	public static void main(String args[])
	{
		SkeletonValidator s=new SkeletonValidator();

		//Uncomment these lines after completing the JUnit Code

		Result result=JUnitCore.runClasses(PolicyManagementTest.class);

		if(result.getFailureCount()==0)
		{
			System.out.println("No Failures");
		}
		else
		{
			for(Failure failure: result.getFailures())

			{
				System.out.println(failure.toString());
			}
		}
		System.out.println("Result "+result.wasSuccessful());

	}

}
