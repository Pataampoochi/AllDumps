package com.aviva.exception;

public class InvalidInsurancePolicyException extends Exception{
	
	public InvalidInsurancePolicyException(String msg) {
		super(msg);
	}

}
