package com.aviva.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Arrays;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.aviva.exception.InvalidInsurancePolicyException;
import com.aviva.model.InsurancePolicy;
import com.aviva.util.PolicyManagement;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PolicyManagementTest {

	private static List<InsurancePolicy> policyList = new ArrayList<InsurancePolicy>();;
	private static PolicyManagement policy;
	private static SimpleDateFormat s=new SimpleDateFormat("yyyy-dd-MM");
	
	@BeforeClass
	public static void setUp() throws Exception {
        //Create few  objects for InsurancePolicy class and add to policyList.
		//Use that list to test all the methods in PolicyManagementTest class that requires a list of InsurancePolicy 
	}

	// Test validatePolicyType method when the Insurance type is Health Insurance
	public void test11ValidatePolicyTypeWhenHealthInsurance() {
		// Fill the code
	}

	// Test validatePolicyType method when the Insurance type is Vehicle Insurance
	public void test12ValidatePolicyTypeWhenVehicleInsurance() {
		// Fill the code
	}

	// Test validatePolicyType method when the Insurance type is Invalid
	public void test13ValidatePolicyTypeWhenInvalid() {
		// Fill the code
	}

	// Test viewPolicyByInsurancePolicyId method for a valid Policy Id
	public void test14ViewPolicyForValidInsurancePolicyId() {
		// Fill the code
	}

	// Test viewPolicyByInsurancePolicyId method for an invalid Policy Id
	public void test15ViewPolicyForInvalidInsurancePolicyId() {
		// Fill the code
    }

	// Test the viewPolicyByExpiryDate method
	public void test16ViewPolicyByExpiryDate() throws ParseException{
		// Fill the code
	}

	// Test the viewPolicyByExpiryDate method for an Empty List
	public void test17ViewPolicyByExpiryDateForEmptyList() throws ParseException{
		// Fill the code
	}

	// Test the calculatePremiumAmountByExpiryDate method
	public void test18CalculatePremiumAmountByExpiryDate() throws ParseException{
		// Fill the code
	}
	
	// Test the calculatePremiumAmountByExpiryDate method for an Empty List
	public void test19CalculatePremiumAmountByExpiryDateForEmptyList() throws ParseException{
		// Fill the code
	}

	// Test the countOfPolicyHoldersBasedOnThePolicyType method
	public void test20CountOfPolicyHoldersBasedOnThePolicyType() {
		// Fill the code
	}

	// Test the countOfPolicyHoldersBasedOnThePolicyType method for an Empty List
	public void test21CountOfPolicyHoldersBasedOnThePolicyTypeForEmptyList() {
		// Fill the code
	}

	// Test the countOfPolicyHoldersWithAdditonalBonus method
	public void test22CountOfPolicyHoldersWithAdditonalBonus() throws ParseException{
		// Fill the code
	}

	// Test the countOfPolicyHoldersWithAdditonalBonus method for an empty List
	public void test23CountOfPolicyHoldersWithAdditonalBonusForEmptyList() throws ParseException {
		// Fill the code
	}

}
