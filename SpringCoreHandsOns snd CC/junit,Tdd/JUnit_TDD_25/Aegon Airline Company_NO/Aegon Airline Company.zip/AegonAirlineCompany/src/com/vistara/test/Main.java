package com.vistara.test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import com.vistara.skeleton.SkeletonValidator;
import com.vistara.test.ProcessingTicketTest;

public class Main {

	public static void main(String args[])
	{
		SkeletonValidator s=new SkeletonValidator();

		//Uncomment these lines after completing the JUnit Code

		Result result=JUnitCore.runClasses(ProcessingTicketTest.class);

		if(result.getFailureCount()==0)
		{
			System.out.println("No Failures");
		}
		else
		{
			for(Failure failure: result.getFailures())

			{
				System.out.println(failure.toString());
			}
		}
		System.out.println("Result "+result.wasSuccessful());

	}

}
