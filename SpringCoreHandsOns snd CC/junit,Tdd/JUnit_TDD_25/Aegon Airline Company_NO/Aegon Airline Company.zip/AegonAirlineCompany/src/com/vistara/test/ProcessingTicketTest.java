package com.vistara.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.vistara.exception.InvalidSeatTypeException;
import com.vistara.model.AirlineTicket;
import com.vistara.util.ProcessingTicket;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProcessingTicketTest {

	private static List<AirlineTicket> ticketList = new ArrayList<AirlineTicket>();
	private static SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
	private static ProcessingTicket ticket;

	@BeforeClass
	public static void setUp() throws Exception {

	//Create few  objects for Mobile class and add to mobileList.
	//Use that list to test all the methods in MobileTest class that requires a list of Mobile 
		
	}

	// Test validateSeatType method when the Seat type is Economy
	public void test11ValidateSeatTypeWhenEconomy() {
		// Fill the code
	}

	// Test validateSeatType method when the Seat type is Premium
	public void test12ValidateSeatTypeWhenPremium() {
		// Fill the code
	}

	// Test validateSeatType method when the Seat type is invalid
	public void test13ValidateTicketIdWhenInvalid() {
		// Fill the code
	}

	// Test viewTicketDetailsByTicketId method for a valid Ticket Id
	public void test14ViewTicketDetailsByValidTicketId() {
		// Fill the code
	}

	// Test viewTicketDetailsByTicketId method for an invalid Ticket Id
	public void test15ViewTicketDetailsByInvalidTicketId() {
		// Fill the code
	}
	
	// Test the viewFlightTicketByDateOfJourney method
	public void test16ViewFlightTicketByDateOfJourney() throws ParseException {
		// Fill the code
	}

	// Test the viewFlightTicketByDateOfJourney method for an empty list
	public void test17ViewFlightTicketByDateOfJourneyForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test the countTicketsByAirlineCode method
	public void test18CountTicketsByAirlineCode() throws ParseException {
		// Fill the code
	}

	// Test the countTicketsByAirlineCode method for an empty list
	public void test19CountTicketsByAirlineCodeForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test the countOfPassengersBySeatType method
	public void test20CountOfPassengersBySeatType() {
		// Fill the code
	}
	
	// Test the countOfPassengersBySeatType method for an empty list
	public void test21CountOfPassengersBySeatTypeForEmptyList() {
		// Fill the code
	}

	// Test the calculateAmountByDateOfJourney method
	public void test22CalculateAmountByDateOfJourney() throws ParseException {
		// Fill the code
	}

	// Test the calculateAmountByDateOfJourney method for an empty list
	public void test23CalculateAmountByDateOfJourneyForEmptyList() throws ParseException {
		// Fill the code
	}

}
