package com.vistara.exception;

public class InvalidSeatTypeException extends Exception{
	
	public InvalidSeatTypeException(String msg) {
		super(msg);
	}

}
