package com.vistara.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vistara.exception.InvalidSeatTypeException;
import com.vistara.model.AirlineTicket;

public class ProcessingTicket {

	public boolean validateSeatType(String seatType) throws InvalidSeatTypeException {
		boolean status = false;
		if (seatType.equalsIgnoreCase("Economy") || seatType.equalsIgnoreCase("Premium")) {
			status = true;
		} else {
			status = false;
			throw new InvalidSeatTypeException("Valid seat type should be Economy or Premium");
		}

		return status;
	}

	public AirlineTicket viewTicketDetailsByTicketId(List<AirlineTicket> ticketList, String ticketId) throws InvalidSeatTypeException{

		if(ticketList.size()==0){
			throw new InvalidSeatTypeException("Ticket List is empty");
		}
		else {
			for(AirlineTicket m : ticketList){
				if(m.getTicketId().equals(ticketId))
					return m;
			}
			throw new InvalidSeatTypeException("Ticket Id is invalid");	
		}
	}

	public List<AirlineTicket> viewFlightTicketByDateOfJourney(List<AirlineTicket> ticketList, Date journeyDate) throws InvalidSeatTypeException {

		if(ticketList.size()==0){
			throw new InvalidSeatTypeException("Ticket List is empty");
		}
		else {
			List<AirlineTicket> passengers=new ArrayList<AirlineTicket>();

			for (AirlineTicket i: ticketList) {

				if (i.getDateOfJourney().compareTo(journeyDate)==0) {
					passengers.add(i);
				}
			}
			return passengers;
		}
	}


	public int countTicketsByAirlineCode(List<AirlineTicket> ticketList, String airlineCode)
			throws InvalidSeatTypeException, ParseException {
		if(ticketList.size()==0){
			throw new InvalidSeatTypeException("Ticket List is empty");
		}
		else{
			int count=0;
			for (AirlineTicket i:ticketList) {
				if(i.getAirlineCode().equalsIgnoreCase(airlineCode)){
					count++;
				}
			}
			return count; 
		}
	}


	public Map<String, List<AirlineTicket>> countOfPassengersBySeatType(List<AirlineTicket> ticketList)throws InvalidSeatTypeException {

		if(ticketList.size()==0){
			throw new InvalidSeatTypeException("Ticket List is empty");
		}
		else{
			Map<String,List<AirlineTicket>> result = new LinkedHashMap<>();
			for(AirlineTicket t : ticketList){
				if(!result.containsKey(t.getSeatType())){
					result.put(t.getSeatType(),new ArrayList<AirlineTicket>());
				}
				List<AirlineTicket> temp=result.get(t.getSeatType());
				temp.add(t);
				result.put(t.getSeatType(), temp);			
			}
			return result;
		}

	}

	public double calculateAmountByDateOfJourney(List<AirlineTicket> ticketList, Date journeyDate) throws InvalidSeatTypeException {
		double amount=0;
		if(ticketList.size()==0){
			throw new InvalidSeatTypeException("Ticket List is empty");
		}
		else{
			for (AirlineTicket i: ticketList) {
				if(journeyDate.compareTo(i.getDateOfJourney())==0)
					amount=amount+i.getTicketFare();
			} 
			return amount;
		}
	}

}
