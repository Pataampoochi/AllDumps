package com.vistara.model;

import java.util.Date;

public class AirlineTicket {
	
	private String ticketId;
	private String airlineCode;
	private Date dateOfJourney;
	private String seatType;
	private String source;
	private String destination;
	private double ticketFare;
	
	public AirlineTicket() {
		
	}

	public AirlineTicket(String ticketId, String airlineCode, Date dateOfJourney, String seatType, String source,
			String destination, double ticketFare) {
		super();
		this.ticketId = ticketId;
		this.airlineCode = airlineCode;
		this.dateOfJourney = dateOfJourney;
		this.seatType = seatType;
		this.source = source;
		this.destination = destination;
		this.ticketFare = ticketFare;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getAirlineCode() {
		return airlineCode;
	}

	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	public Date getDateOfJourney() {
		return dateOfJourney;
	}

	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}

	public String getSeatType() {
		return seatType;
	}

	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public double getTicketFare() {
		return ticketFare;
	}

	public void setTicketFare(double ticketFare) {
		this.ticketFare = ticketFare;
	}

	@Override
	public String toString() {
		return "AirlineTicket [ticketId=" + ticketId + ", airlineCode=" + airlineCode + ", dateOfJourney="
				+ dateOfJourney + ", seatType=" + seatType + ", source=" + source + ", destination=" + destination
				+ ", ticketFare=" + ticketFare + "]";
	}
	
	

}