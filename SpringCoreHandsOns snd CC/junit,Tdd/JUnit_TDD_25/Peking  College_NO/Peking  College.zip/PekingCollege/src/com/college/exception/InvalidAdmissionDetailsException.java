package com.college.exception;

public class InvalidAdmissionDetailsException extends Exception{

	public InvalidAdmissionDetailsException(String msg) {
		super(msg);
	}
}
