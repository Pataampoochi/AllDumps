package com.college.model;

import java.util.Date;

public class AdmissionDetails {
	
	private String admissionId;
	private String studentId;
	private Date dateOfCounseling;
	private Date dateOfAdmission;
	private String courseName;
	private double totalFee;
	public AdmissionDetails() {
		
	}
	public AdmissionDetails(String admissionId, String studentId, Date dateOfCounseling, Date dateOfAdmission,
			String courseName, double totalFee) {
		super();
		this.admissionId = admissionId;
		this.studentId = studentId;
		this.dateOfCounseling = dateOfCounseling;
		this.dateOfAdmission = dateOfAdmission;
		this.courseName = courseName;
		this.totalFee = totalFee;
	}
	public String getAdmissionId() {
		return admissionId;
	}
	public void setAdmissionId(String admissionId) {
		this.admissionId = admissionId;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public Date getdateOfCounseling() {
		return dateOfCounseling;
	}
	public void setdateOfCounseling(Date dateOfCounseling) {
		this.dateOfCounseling = dateOfCounseling;
	}
	public Date getDateOfAdmission() {
		return dateOfAdmission;
	}
	public void setDateOfAdmission(Date dateOfAdmission) {
		this.dateOfAdmission = dateOfAdmission;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public double getTotalFee() {
		return totalFee;
	}
	public void setTotalFee(double totalFee) {
		this.totalFee = totalFee;
	}
	@Override
	public String toString() {
		return "AdmissionDetails [admissionId=" + admissionId + ", studentId=" + studentId + ", dateOfCounseling="
				+ dateOfCounseling + ", dateOfAdmission=" + dateOfAdmission + ", courseName=" + courseName
				+ ", totalFee=" + totalFee + "]";
	}

}
