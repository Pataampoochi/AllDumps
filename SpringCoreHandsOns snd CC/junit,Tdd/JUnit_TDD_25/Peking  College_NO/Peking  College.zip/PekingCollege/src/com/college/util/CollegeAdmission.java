package com.college.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.college.exception.InvalidAdmissionDetailsException;
import com.college.model.AdmissionDetails;

public class CollegeAdmission {
	
	AdmissionDetails admission=new AdmissionDetails();

	
	public boolean validateAdmissionId(String admissionId) throws InvalidAdmissionDetailsException {
		boolean status = false;
		int count =0;
		char[] ch=admissionId.toCharArray();
		for(int i=0;i<=3;i++){
			if(Character.isAlphabetic(ch[i]))
				count++;
		}
		for(int i=4;i<=7;i++){
			if(Character.isDigit(ch[i]))
				count++;
		}
		if (count==8 && ch[8]=='V' && ch[9]=='C' && ch.length==10) {
			status = true;
		} else {
			status = false;
			throw new InvalidAdmissionDetailsException("Valid Admission Id should be given");
		}

		return status;
	}

    public AdmissionDetails viewAdmissionDetailsByStudentId(List<AdmissionDetails> admissionList, String studentId) throws InvalidAdmissionDetailsException{
		
		if(admissionList.size()==0){
		    throw new InvalidAdmissionDetailsException("List is Empty");
	    }
	    else{
		    for(AdmissionDetails p : admissionList){
			    if(p.getStudentId().equals(studentId)){
				    return p;
			    }
		    }
		    throw new InvalidAdmissionDetailsException("Admission ID is invalid");
	    }
	}

	public List<AdmissionDetails> viewDetailsByDateOfCounseling(List<AdmissionDetails> admissionList, Date date) throws InvalidAdmissionDetailsException {
		
		List<AdmissionDetails> admissionDetails=new ArrayList<AdmissionDetails>();
		System.out.println(admissionList.size());
		if (admissionList.size() > 0) {
			for (AdmissionDetails i: admissionList) {
				try {
					if (validateAdmissionId(i.getAdmissionId())) {
						if (i.getdateOfCounseling().compareTo(date)==0) {
							admissionDetails.add(i);
						}
					}
				} catch (InvalidAdmissionDetailsException e) {
					
				}
			}
		} else {
			throw new InvalidAdmissionDetailsException("Invalid admission list..");
		}
		return admissionDetails;
	}


	public int countOfDetailsByCourseName(List<AdmissionDetails> admissionList, String courseName)
			throws InvalidAdmissionDetailsException, ParseException {
		int count=0;
		if (admissionList.size() == 0) {
			throw new InvalidAdmissionDetailsException("Admission list is empty");
		}
		else{
			for (AdmissionDetails i:admissionList) {
				if (i.getCourseName().equals(courseName)) {
					count++;;
				}
			}
		}
		return count; 
	}

	
	public Map<Date, List<AdmissionDetails>> viewDetailsByDateOfAdmission(List<AdmissionDetails> admissionList)throws InvalidAdmissionDetailsException {
		Map<Date,List<AdmissionDetails>> result = new LinkedHashMap<>();
		int count=0;
		if (admissionList.size() > 0) {
			
			for(AdmissionDetails t : admissionList){
				if(!result.containsKey(t.getDateOfAdmission())){
					result.put(t.getDateOfAdmission(),new ArrayList<AdmissionDetails>());
				}
				List<AdmissionDetails> temp=result.get(t.getDateOfAdmission());
				temp.add(t);
				result.put(t.getDateOfAdmission(), temp);			
			}
			
			}else {
			throw new InvalidAdmissionDetailsException("Invalid admission list..");
		}
		return result;
	}

	public double calculateAmountByDateOfAdmission(List<AdmissionDetails> admissionList, Date date) throws InvalidAdmissionDetailsException {
		double amount=0;
		if (admissionList.size() > 0) {

			for (AdmissionDetails i: admissionList) {
				if(i.getDateOfAdmission().compareTo(date)==0)
					amount=amount+i.getTotalFee();


			} }else {
				throw new InvalidAdmissionDetailsException("Invalid admission list..");
			}
		return amount;
	}


}
