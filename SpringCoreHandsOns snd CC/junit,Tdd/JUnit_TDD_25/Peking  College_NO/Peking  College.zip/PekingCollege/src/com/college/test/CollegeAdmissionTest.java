package com.college.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.college.exception.InvalidAdmissionDetailsException;
import com.college.model.AdmissionDetails;
import com.college.util.CollegeAdmission;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CollegeAdmissionTest {
	
	private static List<AdmissionDetails> admissionList = new ArrayList<AdmissionDetails>();
	private static CollegeAdmission admission =new CollegeAdmission();
	
	@BeforeClass
	public static void setUp() throws Exception {
		
		// Fill the code

	}
		
	// Test validateAdmissionId method with a valid Admission Id
	public void test11ValidateAdmissionIdForValidAdmissionId() {
		// Fill the code
	}
	
	// Test validateAdmissionId method with an invalid Admission Id
	public void test12ValidateAdmissionIdForInvalidAdmissionId() {
		// Fill the code
	}

	// Test validateAdmissionId method with an invalid Admission Id without the letters V and C
	public void test13ValidateAdmissionIdForInvalidAdmissionIdWithoutVC() {
		// Fill the code
	}
	
	// Test validateAdmissionId method with an invalid Admission Id with greater string length than mentioned
	public void test14ValidateAdmissionIdForInvalidAdmissionIdWithLengthGreaterThan10() {
		// Fill the code
	}
	
	// Test viewAdmissionDetailsByStudentId method with a valid Student Id
	public void test15ViewAdmissionDetailsByValidStudentId() {
		// Fill the code
	}
	
	// Test viewAdmissionDetailsByStudentId method with an invalid Student Id
	public void test16ViewAdmissionDetailsByInvalidStudentId() {
		// Fill the code
	}
	
	// Test viewDetailsByDateOfCounseling method
	public void test17ViewDetailsByDateOfCounseling() throws ParseException {
		// Fill the code
	}
	
	// Test viewDetailsByDateOfCounseling method for an empty list
	public void test18ViewDetailsByDateOfCounselingForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test countOfDetailsByCourseName method
	public void test19CountOfDetailsByCourseName() throws ParseException {
		// Fill the code
	}
	
	// Test countOfDetailsByCourseName method for an empty list
	public void test20CountOfDetailsByCourseNameForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test viewDetailsByDateOfAdmission method
	public void test21ViewDetailsByDateOfAdmission() throws ParseException {
		// Fill the code
	}
	
	// Test viewDetailsByDateOfAdmission method for an empty list
	public void test22ViewDetailsByDateOfAdmissionForEmptyList() throws ParseException {
		// Fill the code
	}
	
	// Test calculateAmountByDateOfAdmission method
	public void test23CalculateAmountByDateOfAdmission() throws ParseException {
		// Fill the code
	}

	// Test calculateAmountByDateOfAdmission method for an empty list
	public void test24CalculateAmountByDateOfAdmissionForEmptyList() throws ParseException {
		// Fill the code
	}
}
