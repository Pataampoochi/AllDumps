package com.luckychill.model;

import java.util.Date;

public class ACSpecifications {
	
	private String modelNumber;
	private String acType;
	private String brandName;
	private String acColour;
	private Date dateOfBooking;
	private double acCost;
	public ACSpecifications() {
		
	}
	public ACSpecifications(String modelNumber, String acType, String brandName, String acColour, Date dateOfBooking,
			double acCost) {
		super();
		this.modelNumber = modelNumber;
		this.acType = acType;
		this.brandName = brandName;
		this.acColour = acColour;
		this.dateOfBooking = dateOfBooking;
		this.acCost = acCost;
	}
	public String getModelNumber() {
		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}
	public String getAcType() {
		return acType;
	}
	public void setAcType(String acType) {
		this.acType = acType;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getAcColour() {
		return acColour;
	}
	public void setAcColour(String acColour) {
		this.acColour = acColour;
	}
	public Date getDateOfBooking() {
		return dateOfBooking;
	}
	public void setDateOfBooking(Date dateOfBooking) {
		this.dateOfBooking = dateOfBooking;
	}
	public double getAcCost() {
		return acCost;
	}
	public void setAcCost(double acCost) {
		this.acCost = acCost;
	}
	@Override
	public String toString() {
		return "ACSpecifications [modelNumber=" + modelNumber + ", acType=" + acType + ", brandName=" + brandName
				+ ", acColour=" + acColour + ", dateOfBooking=" + dateOfBooking + ", acCost=" + acCost + "]";
	}
	
	
}
