package com.luckychill.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import com.luckychill.model.ACSpecifications;
import com.luckychill.util.ACBooking;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ACBookingTest {

	private static List<ACSpecifications> acList = new ArrayList<ACSpecifications>();
	private static ACBooking bookingObj;
	
	@BeforeClass
	public static void setUp() throws Exception {

		bookingObj=new ACBooking();
		//Create few  objects for ACSpecifications class and add to acList
		//Use this list to test all the methods in ACBooking class that requires a list of ACSpecifications 		

	}

	// Test validateModelNumber method with a Valid model number
	public void test11ValidateModelNumber() {
		// Fill the code
	}

	// Test validateModelNumber method with input String without LUCH
	public void test12ValidateModelNumberWithoutStringLUCH() {
		// Fill the code
	}

	// Test validateModelNumber method with input String with more digits
	public void test13ValidateModelNumberWithMoreDigits() {
		// Fill the code
	}

	// Test validateModelNumber method with input String with less digits
	public void test14ValidateModelNumberWithLessDigits() {
		// Fill the code
	}

	// Test viewACByModelNumber method with a valid model number
	public void test15ViewACByValidModelNumber() {
		// Fill the code
    }

	// Test viewACByModelNumber method with an invalid model number
	public void test16ViewACByInvalidModelNumber() {
		// Fill the code
	}

	// Test viewACByItsType method
	public void test17ViewACByItsType() {
		// Fill the code
	}

	// Test viewACByItsType method for an empty list
	public void test18ViewACByItsTypeForEmptyList() {
		// Fill the code
	}

	// Test calculateTotalAmountByDateOfBooking method
	public void test19CalculateTotalAmountByDateOfBooking() throws ParseException {
		// Fill the code
	}

	// Test calculateTotalAmountByDateOfBooking method for an empty list
	public void test20CalculateTotalAmountByDateOfBookingForEmptyList() throws ParseException {
		// Fill the code
	}

	// Test viewACBrandNameWise method
	public void test21ViewACBrandNameWise() {
		// Fill the code

	}
	
	// Test viewACBrandNameWise method for an empty list
	public void test22ViewACBrandNameWiseForEmptyList() {
		// Fill the code
	}

	// Test countOfACsByACColour method
	public void test23CountOfACsByACColour() {
		// Fill the code
	}
	
	// Test countOfACsByACColour method for an empty list
	public void test24CountOfACsByACColourForEmptyList() {
		// Fill the code
	}

}
