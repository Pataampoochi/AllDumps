package com.luckychill.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.luckychill.exception.InvalidACSpecException;
import com.luckychill.model.ACSpecifications;

public class ACBooking {

	public boolean validateModelNumber(String modelNumber) throws InvalidACSpecException {
		
		if(modelNumber.length()==9){
			if(modelNumber.startsWith("LUCH"))
			{
				for(int i=4;i<modelNumber.length();i++){
					if(!Character.isDigit(modelNumber.charAt(i))){
						throw new InvalidACSpecException("Model Number is Invalid");
					}
				}
			}
			else{
				throw new InvalidACSpecException("Model Number is Invalid");
			}
		}
		else{
			throw new InvalidACSpecException("Model Number is Invalid");
		}
		return true;
		
	}

	public ACSpecifications viewACByModelNumber(List<ACSpecifications> acList, String modelNumber) throws InvalidACSpecException{

		if(acList.size()==0){
			throw new InvalidACSpecException("List is Empty");
		}
		else{
			for(ACSpecifications ac : acList){
				if(ac.getModelNumber().equals(modelNumber)){
					return ac;
				}
			}
			throw new InvalidACSpecException("Model number is invalid");
		}
	}

	public List<ACSpecifications> viewACByItsType(List<ACSpecifications> acList, String actype) throws InvalidACSpecException {

		if (acList.size() == 0) 
			throw new InvalidACSpecException("List is Empty");
		else{
			List<ACSpecifications> details=new ArrayList<ACSpecifications>();
			for (ACSpecifications i: acList) {
				if (i.getAcType().equals(actype)) {
					details.add(i);
				}
			}
			return details;
		} 
	}


	public double calculateTotalAmountByDateOfBooking(List<ACSpecifications> acList, Date dateOfBooking)
			throws InvalidACSpecException, ParseException {
		if (acList.size() == 0) {
			throw new InvalidACSpecException("List is Empty");
		}
		else{
			double sum=0;
			for (ACSpecifications i:acList) {
				if(i.getDateOfBooking().compareTo(dateOfBooking)==0){
					sum=sum+i.getAcCost();
				}
			}
			return sum; 
		}
	}


	public Map<String, List<ACSpecifications>> viewACBrandNameWise(List<ACSpecifications> acList)throws InvalidACSpecException {
		if (acList.size() == 0) {
			throw new InvalidACSpecException("List is Empty");
		}else{
			Map<String,List<ACSpecifications>> result = new LinkedHashMap<>();
			for(ACSpecifications t : acList){
				if(!result.containsKey(t.getBrandName())){
					result.put(t.getBrandName(),new ArrayList<ACSpecifications>());
				}
				List<ACSpecifications> temp=result.get(t.getBrandName());
				temp.add(t);
				result.put(t.getBrandName(), temp);			
			}
			return result;
		}
		
	}

	public int countOfACByACColour(List<ACSpecifications> acList, String colour) throws InvalidACSpecException {
		if (acList.size() == 0) {
			throw new InvalidACSpecException("List is Empty");
		}
		else{
			int count=0;			
			for (ACSpecifications i: acList) {
				if(i.getAcColour().equals(colour))
					count++;
			} 
			return count;
		}
	}

}