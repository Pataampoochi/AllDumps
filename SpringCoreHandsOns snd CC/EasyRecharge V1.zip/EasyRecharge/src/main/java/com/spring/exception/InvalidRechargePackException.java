package com.spring.exception;

public class InvalidRechargePackException extends Exception {
	public InvalidRechargePackException(String msg) {
	//fill the code
	super(msg);
	}
}
