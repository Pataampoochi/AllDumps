package com.spring.exception;

public class InvalidCouponCodeException extends Exception {

	public InvalidCouponCodeException(String msg) {
		// fill the code
		super(msg);
	}

}
