//make the required changes to this class so that InvalidConsumerNumberException is of type exception. 
public class InvalidConsumerNumberException 
{
    //fill the code
	
}