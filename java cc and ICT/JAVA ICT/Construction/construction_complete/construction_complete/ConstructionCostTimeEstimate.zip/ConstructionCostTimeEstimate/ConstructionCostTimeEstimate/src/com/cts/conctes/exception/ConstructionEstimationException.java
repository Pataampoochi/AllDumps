package com.cts.conctes.exception;

public class ConstructionEstimationException extends Exception{

	String strMsg1;
	Throwable strMsg2;


	public ConstructionEstimationException() {
		super();
	}


	
}