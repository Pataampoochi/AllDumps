
import java.io.*;
import java.sql.*;
import java.util.*;

public class DBHandler {

//write the required business logic methods as expected in the question description
public Connection establishConnection()  
{
    // fill your code here
   
}
}