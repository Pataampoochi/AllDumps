//make the required changes to this class so that InvalidPolicyIdException is of type exception. 
public class InvalidPolicyIdException 
{
	//fill your code here
	
}
