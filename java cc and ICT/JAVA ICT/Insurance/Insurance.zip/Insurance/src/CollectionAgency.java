import java.io.*;
import java.sql.*;
import java.util.*;

public class CollectionAgency 
{
	//write the required business logic methods as expected in the question description
	
	public List<Payment> generatePaymentAmount(String filePath)
	{
			// fill your code here	
	}
	
	public boolean validate(String policyId) throws InvalidPolicyIdException
	{
			// fill your code here
		
	}
	
	public void updatePolicyDetails(List <Payment> paymentList)
	{
	    // fill your code here
	}
}
