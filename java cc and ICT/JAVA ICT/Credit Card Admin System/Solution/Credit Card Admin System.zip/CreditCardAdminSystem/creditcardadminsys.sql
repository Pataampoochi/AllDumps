drop database creditcardadminsys;

create database creditcardadminsys;

use creditcardadminsys;

CREATE TABLE T_CREDIT_CARD_ACCOUNT (
    CREDIT_CARD_NUMBER BIGINT(20) PRIMARY KEY,
    CUSTOMER_NAME VARCHAR(100),
    CUSTOMER_EMAIL VARCHAR(50) NOT NULL,
    CUSTOMER_PHONE BIGINT(15),
    BILL_AMOUNT DOUBLE(10 , 2 ) NOT NULL,
    BILL_DUE_DATE DATE NOT NULL,
    BILL_PAID_DATE DATE 
);



