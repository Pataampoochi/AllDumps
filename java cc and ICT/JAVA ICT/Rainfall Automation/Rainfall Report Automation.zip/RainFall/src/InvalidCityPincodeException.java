
public class InvalidCityPincodeException extends Exception {
    public InvalidCityPincodeException(String g)
    {
        super(g);
    }

}
