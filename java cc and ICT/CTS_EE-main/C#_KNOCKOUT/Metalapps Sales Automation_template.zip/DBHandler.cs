using System;
using System.Configuration;
using System.Data.SqlClient;

namespace MetalappsAutomation  //DO NOT change the namespace name
{
    class DBHandler  //DO NOT change the class name
    {
       //Implement the methods as per the description
    }
}
