using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetalappsAutomation //DO NOT change the namespace name
{
	public  class Metalapps            //DO NOT change the class name
	{
			//Implement the property as per the description
			//Implement the methods as per the description
	}
}
