using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetalappsAutomation    //DO NOT change the namespace name
{
	public class SalesDetails   //DO NOT change the class name
    {
        //Implement the fields and properties as per description
    }
}	 	  	 	 	   	  	    	 	
