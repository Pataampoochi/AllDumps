using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Configuration;

namespace ADO_Net_App1
{
    public class TraineeDA
    {
        //Write your code here
        public string ConnectionString
            {
                get
                {
                    return DBConnection.connStr;
                }
            }
        
        
    
        public bool AddTraineeDetails(TraineeBO objBO)
        {
            
                
                try
            {
                OracleConnection con = new OracleConnection(ConnectionString);
                con.Open();
                string query = "insert into tblTrainee values(" + objBO.TraineeId + ",'" + objBO.TraineeName + "','" + objBO.BatchCode + "')";
                OracleCommand cmd = new OracleCommand(query, con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                    return true;
                else
                    return false;
            }
            catch(Exception e)
            {
                return false;
            }
        }
    }
}