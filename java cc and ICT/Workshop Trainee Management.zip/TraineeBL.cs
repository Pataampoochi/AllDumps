using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Net_App1
{
    public class TraineeBL
    {
        //Write your code here
        public bool SaveTraineeDetails(TraineeBO objBO)
        {
            TraineeDA tDA = new TraineeDA();
            bool res = tDA.AddTraineeDetails(objBO);
            if (res)
                return true;
            else
                return false;
        }
    }
}