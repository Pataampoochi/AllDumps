//This is for your reference. DO NOT make any changes here
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Net_App1
{
    public class DBConnection
    {
        public static String connStr = "User Id=admin;Password=admin;Data Source=localhost:1521/XE;";
    }
}
