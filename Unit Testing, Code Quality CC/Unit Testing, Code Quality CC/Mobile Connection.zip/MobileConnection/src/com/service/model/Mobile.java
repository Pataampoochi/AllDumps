package com.service.model;


public class Mobile {
	private String mobileNumber;
	private String ownerName;
	private  String serviceProvider;  
	private String connectionType;  //Can be prepaid, postpaid or DTH
	private String plan;    

	public Mobile(){
		
	}

	public Mobile(String mobileNumber, String ownerName, String serviceProvider, String connectionType, String plan) {
		super();
		this.mobileNumber = mobileNumber;
		this.ownerName = ownerName;
		this.serviceProvider = serviceProvider;
		this.connectionType = connectionType;
		this.plan = plan;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public String getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}	

}
