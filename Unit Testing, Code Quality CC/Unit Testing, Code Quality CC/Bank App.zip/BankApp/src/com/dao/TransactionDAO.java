package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.model.Transaction;

public class TransactionDAO {
	
	List<Transaction> transactionList = new  ArrayList<Transaction>();

	public List<Transaction> getTransactionList() {
		return transactionList;
	}

    public void addTransaction(Transaction obj){
    	transactionList.add(obj);
    }
	
    public void removeObj(int transactionId){
    	transactionList.remove(transactionId);
    }
}
