package com.cts.model;

import java.time.LocalDateTime;

public class DailyAttendance {
	
	private int employeeID;
	private String subjectExpert;
	private String topicsHandled;
	private String asPerSchedule;
	private LocalDateTime inDatetime;
	private LocalDateTime outDatetime;
	
	public DailyAttendance()
	{
		
	}
	
	public DailyAttendance(int employeeID, String subjectExpert, String topicsHandled, String asPerSchedule,
			LocalDateTime inDatetime, LocalDateTime outDatetime) {
		
		this.employeeID = employeeID;
		this.subjectExpert = subjectExpert;
		this.topicsHandled = topicsHandled;
		this.asPerSchedule = asPerSchedule;
		this.inDatetime = inDatetime;
		this.outDatetime = outDatetime;
	}


	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getSubjectExpert() {
		return subjectExpert;
	}
	public void setSubjectExpert(String subjectExpert) {
		this.subjectExpert = subjectExpert;
	}
	public String getTopicsHandled() {
		return topicsHandled;
	}
	public void setTopicsHandled(String topicsHandled) {
		this.topicsHandled = topicsHandled;
	}
	public String getAsPerSchedule() {
		return asPerSchedule;
	}
	public void setAsPerSchedule(String asPerSchedule) {
		this.asPerSchedule = asPerSchedule;
	}
	public LocalDateTime getInDatetime() {
		return inDatetime;
	}
	public void setInDatetime(LocalDateTime inDatetime) {
		this.inDatetime = inDatetime;
	}
	public LocalDateTime getOutDatetime() {
		return outDatetime;
	}
	public void setOutDatetime(LocalDateTime outDatetime) {
		this.outDatetime = outDatetime;
	}
	
	
	@Override
	public String toString() {
		return "DailyAttendance [employeeID=" + employeeID + ", subjectExpert=" + subjectExpert + ", topicsHandled="
				+ topicsHandled + ", asPerSchedule=" + asPerSchedule + ", inDatetime=" + inDatetime + ", outDatetime="
				+ outDatetime + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asPerSchedule == null) ? 0 : asPerSchedule.hashCode());
		result = prime * result + employeeID;
		result = prime * result + ((inDatetime == null) ? 0 : inDatetime.hashCode());
		result = prime * result + ((outDatetime == null) ? 0 : outDatetime.hashCode());
		result = prime * result + ((subjectExpert == null) ? 0 : subjectExpert.hashCode());
		result = prime * result + ((topicsHandled == null) ? 0 : topicsHandled.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DailyAttendance other = (DailyAttendance) obj;
		if (asPerSchedule == null) {
			if (other.asPerSchedule != null)
				return false;
		} else if (!asPerSchedule.equals(other.asPerSchedule))
			return false;
		if (employeeID != other.employeeID)
			return false;
		if (inDatetime == null) {
			if (other.inDatetime != null)
				return false;
		} else if (!inDatetime.equals(other.inDatetime))
			return false;
		if (outDatetime == null) {
			if (other.outDatetime != null)
				return false;
		} else if (!outDatetime.equals(other.outDatetime))
			return false;
		if (subjectExpert == null) {
			if (other.subjectExpert != null)
				return false;
		} else if (!subjectExpert.equals(other.subjectExpert))
			return false;
		if (topicsHandled == null) {
			if (other.topicsHandled != null)
				return false;
		} else if (!topicsHandled.equals(other.topicsHandled))
			return false;
		return true;
	}
	
	

}
