package com.cts.cdgallery.util;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cts.cdgallery.exception.InvalidCDInfoException;
import com.cts.cdgallery.model.CDInfo;

public class CDGallery {
	
	// validate cd working status
	public boolean validateCDWorkingStatus(String cdWorkingStatus) throws InvalidCDInfoException {
		boolean status = false;
		if (cdWorkingStatus.equalsIgnoreCase("Yes") || cdWorkingStatus.equalsIgnoreCase("No")) {
			status = true;
		} else {
			status = false;
			throw new InvalidCDInfoException("Valid Working Status For CD are - Yes / No");
		}

		return status;
	}

	// validate cd release year
	public boolean validateCDReleaseYear(long releaseYear) throws InvalidCDInfoException {
		boolean status = false;
		LocalDate currentDate = LocalDate.now();
		long currentYear = currentDate.getYear();

		if (releaseYear >= 1999 && releaseYear <= currentYear) {
			status = true;
		} else {
			status = false;
			throw new InvalidCDInfoException("Valid release year for CD is from 1999 till current year");
		}

		return status;
	}

	// count number of working cds
	public int countNoOfWorkingCDs(List<CDInfo> cdList) throws InvalidCDInfoException {
		int count = 0;
		if (cdList.size() > 0) {
			for (int i = 0; i < cdList.size(); i++) {
				try {
					if (validateCDWorkingStatus(cdList.get(i).getCdWorkingStatus())) {
						if (cdList.get(i).getCdWorkingStatus().equalsIgnoreCase("yes")) {
							count++;
						}
					}
				} catch (InvalidCDInfoException e) {
					// we skip count for invalid cdstatus.
				}
			}
		} else {
			throw new InvalidCDInfoException("Invalid cd list..");
		}
		return count;
	}

	// view cd info released between given years
	public List<CDInfo> viewCDInfoBetweenReleaseYear(List<CDInfo> cdList, long fromReleaseYear, long toReleaseYear)
			throws InvalidCDInfoException {
		List<CDInfo> cList = new ArrayList<CDInfo>();
		if (validateCDReleaseYear(fromReleaseYear) && validateCDReleaseYear(toReleaseYear)) {
			for (int i = 0; i < cdList.size(); i++) {
				long tempReleaseYear = cdList.get(i).getReleaseYear();
				if (tempReleaseYear >= fromReleaseYear && tempReleaseYear <= toReleaseYear) {
					cList.add(cdList.get(i));
				}
			}
			if (cList.isEmpty()) {
				throw new InvalidCDInfoException("No movies releases in given years");
			}
		}

		return cList; // return null;
	}

	// count number of CDs of producer
	public Map<String, Integer> countNoOfMoviesOfProducer(List<CDInfo> cdList) throws InvalidCDInfoException {
		Map<String, Integer> map = new HashMap<String, Integer>();
		if (cdList.size() > 0) {
			for (int i = 0; i < cdList.size(); i++) {
				String producerName = cdList.get(i).getProducerName();
				int count = 0;
				for (int c = 0; c < cdList.size(); c++) {

					if (cdList.get(c).getProducerName().equals(producerName)) {
						count++;
					}
				} // inner for
				map.put(producerName, count);
			}

		} else {
			throw new InvalidCDInfoException("Invalid cd list..");
		}
		return map;
	}

}
